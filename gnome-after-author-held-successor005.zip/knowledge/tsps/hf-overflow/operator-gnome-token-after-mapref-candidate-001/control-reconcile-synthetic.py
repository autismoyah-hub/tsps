import contextlib,hashlib,importlib.util,io,json,pathlib,sys,tempfile,types
source=pathlib.Path('/tmp/gnome-author-after-001/knowledge/tsps/hf-overflow/operator-gnome-token-after-mapref-candidate-001/reconcile-author-after.py');spec=importlib.util.spec_from_file_location('synthetic_reconcile',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
 d=pathlib.Path(td);plan={'source':m.SOURCE,'name':'synthetic','executionHold':False,'ownerSelection':{'owner':m.OWNER},'expectedInputsRef':{'sha256':'synthetic','count':1},'tests':['synthetic']};pr=json.dumps(plan).encode();(d/'plan').write_bytes(pr);selection={'source':m.SOURCE,'owner':m.OWNER,'action':'SELECT_ONCE','attempts':1,'planSHA256':hashlib.sha256(pr).hexdigest(),'manifestSHA256':'synthetic','count':1,'tests':['synthetic']};(d/'selection').write_text(json.dumps(selection));queries=[]
 for mode in ['clear','source','name','legacy']:
  class Fake:
   def whoami(self):return {'name':'Autismo-Yah'}
   def list_jobs(self,namespace,labels):
    assert namespace=='Autismo-Yah';queries.append(labels)
    if (mode=='source' and 'source' in labels) or (mode=='name' and 'name' in labels) or (mode=='legacy' and labels=={'project':'tsps'}):return [types.SimpleNamespace(id='synthetic',status=types.SimpleNamespace(stage='COMPLETED'),labels=labels,created_at=None,started_at=None,finished_at=None)]
    return []
  sys.modules['huggingface_hub']=types.SimpleNamespace(HfApi=Fake);sys.argv=['reconcile','--plan',str(d/'plan'),'--selection',str(d/'selection'),'--output',str(d/mode)]
  with contextlib.redirect_stdout(io.StringIO()):m.main()
  result=json.loads((d/mode).read_bytes());assert result['status']==('CLEAR' if mode=='clear' else 'HOLD') and result['noProviderWrite']
 assert len(queries)==12
 class WrongNamespace:
  def whoami(self):return {'name':'other'}
 sys.modules['huggingface_hub']=types.SimpleNamespace(HfApi=WrongNamespace);sys.argv=['reconcile','--plan',str(d/'plan'),'--selection',str(d/'selection'),'--output',str(d/'wrong-namespace')]
 try:
  with contextlib.redirect_stdout(io.StringIO()):m.main()
 except RuntimeError:pass
 else:raise AssertionError('wrong namespace accepted')
 bad=dict(selection);bad['action']='NOT_SELECTED';(d/'bad-selection').write_text(json.dumps(bad));sys.argv=['reconcile','--plan',str(d/'plan'),'--selection',str(d/'bad-selection'),'--output',str(d/'bad-out')]
 try:
  with contextlib.redirect_stdout(io.StringIO()):m.main()
 except RuntimeError:pass
 else:raise AssertionError('bad selection accepted')
 print(json.dumps({'stage':'SYNTHETIC_RECONCILIATION_CONTROLS','clear':'PASS','sourceMatch':'HOLD','nameMatch':'HOLD','legacyUnknown':'HOLD','wrongNamespace':'HOLD','badSelection':'HOLD','queries':12,'providerAction':False,'secretAccess':False}))
