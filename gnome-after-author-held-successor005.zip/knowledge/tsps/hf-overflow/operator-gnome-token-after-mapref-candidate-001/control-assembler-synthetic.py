import contextlib,datetime,hashlib,importlib.util,io,json,pathlib,sys,tempfile
source=pathlib.Path('/tmp/gnome-author-after-001/knowledge/tsps/hf-overflow/operator-gnome-token-after-mapref-candidate-001/assemble-reconciliation.py');spec=importlib.util.spec_from_file_location('assemble_synthetic',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
 ws=pathlib.Path(td);m.WS=ws;source_id=m.SOURCE;owner=m.OWNER;plan={'source':source_id,'name':'synthetic','executionHold':False,'ownerSelection':{'owner':owner},'expectedInputsRef':{'sha256':'synthetic','count':1},'tests':['synthetic']};pr=json.dumps(plan).encode();(ws/'plan').write_bytes(pr);ps=hashlib.sha256(pr).hexdigest();selection={'source':source_id,'owner':owner,'planSHA256':ps,'action':'SELECT_ONCE','attempts':1,'manifestSHA256':'synthetic','count':1,'tests':['synthetic']};sr=json.dumps(selection).encode();(ws/'selection').write_bytes(sr);ss=hashlib.sha256(sr).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat();common={'source':source_id,'owner':owner,'planSHA256':ps,'selectionSHA256':ss,'checkedUTC':now};provider={**common,'namespace':'Autismo-Yah','status':'CLEAR','sourceJobs':[],'nameJobs':[],'legacyUnresolved':[],'projectJobs':[],'sourceQuery':{'project':'tsps','source':source_id},'nameQuery':{'project':'tsps','name':'synthetic'},'projectQuery':{'project':'tsps'},'noProviderWrite':True};owned={**common,'scope':'owner session and workspace only','ownedMatchingToolCells':[],'pendingOrAmbiguousMatchingIntents':[],'submittedMatchingJobs':[]};(ws/'provider').write_text(json.dumps(provider));(ws/'owned').write_text(json.dumps(owned));sys.argv=['assemble','--plan',str(ws/'plan'),'--selection',str(ws/'selection'),'--provider',str(ws/'provider'),'--owned-tool-evidence',str(ws/'owned'),'--output',str(ws/'result')]
 with contextlib.redirect_stdout(io.StringIO()):m.main()
 result=json.loads((ws/'result').read_bytes());assert result['providerReconciliation']['status']=='CLEAR' and result['operator']==owner
 (ws/'result').unlink();owned['pendingOrAmbiguousMatchingIntents']=['synthetic'];(ws/'owned').write_text(json.dumps(owned))
 try:
  with contextlib.redirect_stdout(io.StringIO()):m.main()
  raise AssertionError('ambiguous intent accepted')
 except RuntimeError as e:assert 'not clear' in str(e)
 assert not (ws/'result').exists()
 print(json.dumps({'stage':'SYNTHETIC_ASSEMBLER_CONTROLS','boundSyntheticClear':'PASS','ambiguousIntent':'HOLD','providerAction':False,'secretAccess':False,'scope':'synthetic only'}))
