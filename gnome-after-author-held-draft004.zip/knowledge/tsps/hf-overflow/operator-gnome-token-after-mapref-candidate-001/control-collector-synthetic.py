"""Synthetic-only collector controls: subprocess/provider are doubles, no network."""
import contextlib,datetime,hashlib,importlib.util,io,json,pathlib,sys,tempfile,types
ROOT=pathlib.Path(__file__).resolve().parent;SOURCE=ROOT/'collect-author-after.py'
sha=lambda b:hashlib.sha256(b).hexdigest()

def exercise(mode):
 spec=importlib.util.spec_from_file_location('collect_synthetic',SOURCE);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 with tempfile.TemporaryDirectory() as td:
  hf=pathlib.Path(td)/'hf';root=hf/'case';sel=root/'selected';sel.mkdir(parents=True);m.ROOT=root;m.HF=hf
  manifest=b'synthetic-manifest';plan={'source':'synthetic','expectedInputsRef':{'bytes':len(manifest),'sha256':sha(manifest)}};pb=json.dumps(plan).encode();(sel/'pilot.json').write_bytes(pb);(root/'manifest').write_bytes(manifest)
  command=['node','-e','synthetic'];sub={'plan':plan,'namespace':'Autismo-Yah','job':{'id':'synthetic-job','command':command},'request':{'command':command}};rec={'planSHA256':sha(pb)}
  if mode=='bad-plan':sub['plan']={'source':'other'}
  if mode=='bad-namespace':sub['namespace']='other'
  if mode=='bad-job':sub['job']['id']='other'
  if mode=='bad-submitted-command':sub['job']['command']=['wrong']
  (sel/'submission.json').write_text(json.dumps(sub));bindings={'pilot':{'sha256':'fake'}};bb=json.dumps(bindings).encode();(root/'bindings').write_bytes(bb);rec.update(bindingsPath=str(root/'bindings'),bindingsSHA256=sha(bb));rb=json.dumps(rec).encode();(root/'prestart').write_bytes(rb)
  caller=types.SimpleNamespace(verify_runtime=lambda:None,OWNER='synthetic-owner',PYTHON=pathlib.Path('/usr/bin/python3.12'),SDK=root/'sdk',EXTRA_PINS={'authenticated-child-snapshot-command.py':'fake','hf-project-access-v4.py':'fake'});helper=types.SimpleNamespace(authenticated_pilot_command=lambda *args:['python','-c','synthetic']);m.load_snapshot=lambda p,h:helper if p.name.startswith('authenticated') else caller
  calls=[]; stages=iter(['RUNNING','COMPLETED'])
  def fake_run(argv,check):
   calls.append(argv)
   if '--collect' in argv:
    if mode=='child-exception':raise RuntimeError('synthetic child uncertain')
    stage='COMPLETED' if mode in ('bad-terminal-command','bad-terminal-job') else next(stages);stamp='20000101T00000'+str(len([x for x in calls if '--collect' in x]))+'Z';cmd=['wrong'] if mode=='bad-terminal-command' else command;job='wrong' if mode=='bad-terminal-job' else 'synthetic-job';(sel/('status-'+stamp+'.json')).write_text(json.dumps({'id':job,'status':{'stage':stage},'command':cmd}));(sel/('logs-'+stamp+'.txt')).write_text('synthetic '+stage)
   return types.SimpleNamespace(returncode=0)
  m.subprocess.run=fake_run
  sys.argv=['collect','--selected-dir',str(sel),'--plan-sha256',sha(pb),'--prestart',str(root/'prestart'),'--prestart-sha256',('bad' if mode=='bad-prestart' else sha(rb)),'--caller-sha256','fake','--job-id','synthetic-job','--manifest',str(root/'manifest')]
  if mode=='live-lock':(sel/'author-collector-active.lock').write_text('held')
  if mode=='wrong-owner':(sel/'author-collector-intent.json').write_text(json.dumps({'collector':'other'}))
  if mode=='same-second':
   stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');(sel/('status-'+stamp+'.json')).write_text('prior')
  if mode=='normal':
   with contextlib.redirect_stdout(io.StringIO()):m.main()
   assert len(calls)==1 and not any('retain-' in ' '.join(x) for x in calls)
   with contextlib.redirect_stdout(io.StringIO()):m.main()
   assert len([x for x in calls if '--collect' in x])==2 and sum('retain-job-result.py' in ' '.join(x) for x in calls)==1 and sum('retain-contiguous-inputs003.py' in ' '.join(x) for x in calls)==1
   assert any(x.read_text()=='synthetic RUNNING' for x in (sel/'snapshot-history').glob('*/logs-*'));assert not (sel/'author-collector-active.lock').exists();return 'PASS'
  try:
   with contextlib.redirect_stdout(io.StringIO()):m.main()
   raise AssertionError('expected HOLD for '+mode)
  except (RuntimeError,FileExistsError):pass
  assert not any('retain-' in ' '.join(x) for x in calls)
  if mode in ('child-exception','bad-terminal-command','bad-terminal-job'):assert (sel/'author-collector-active.lock').exists()
  if mode in ('bad-plan','bad-namespace','bad-job','bad-submitted-command','bad-prestart','live-lock','wrong-owner','same-second'):assert not calls
  return 'HOLD'
results={mode:exercise(mode) for mode in ['normal','bad-plan','bad-namespace','bad-job','bad-submitted-command','bad-prestart','live-lock','wrong-owner','same-second','child-exception','bad-terminal-command','bad-terminal-job']}
print(json.dumps({'stage':'SYNTHETIC_COLLECTOR_CONTROLS','results':results,'providerAction':False,'secretAccess':False,'subprocess':'fake'}))
