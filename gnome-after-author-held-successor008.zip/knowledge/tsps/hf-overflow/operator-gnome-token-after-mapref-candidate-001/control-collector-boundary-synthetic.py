"""Synthetic receipts through the real collector/binding/render boundary; no provider."""
import contextlib,hashlib,importlib.util,io,json,pathlib,shutil,subprocess,sys,tempfile
src=pathlib.Path(__file__).resolve().parents[4];rel=pathlib.Path('knowledge/tsps/hf-overflow/operator-gnome-token-after-mapref-candidate-001');sha=lambda b:hashlib.sha256(b).hexdigest()
with tempfile.TemporaryDirectory() as td:
 ws=pathlib.Path(td)/'workspace';shutil.copytree(src,ws,ignore=shutil.ignore_patterns('__pycache__','*.pyc'));root=ws/rel;hf=root.parent;selected=root/'selected-boundary';selected.mkdir();spec=importlib.util.spec_from_file_location('prestart_boundary',root/'prestart-colour-before-v1.py');pre=importlib.util.module_from_spec(spec);spec.loader.exec_module(pre)
 plan=json.loads((root/'held-001/pilot.json').read_bytes());plan['executionHold']=False;plan['ownerSelection']={'owner':pre.OWNER,'action':'SELECT_ONCE','provenance':'SYNTHETIC ONLY'};pb=(json.dumps(plan,indent=2)+'\n').encode();(selected/'pilot.json').write_bytes(pb);ps=sha(pb);selection={'owner':pre.OWNER,'source':plan['source'],'planSHA256':ps,'action':'SELECT_ONCE'};sr=json.dumps(selection).encode();(selected/'selection.json').write_bytes(sr);bindings=json.loads((root/'bindings.json').read_bytes());bb=(root/'bindings.json').read_bytes();caller_sha=sha((root/'prestart-colour-before-v1.py').read_bytes());subject=pre.build_authority_subject(plan,ps,bindings,sha(bb),sha(sr),caller_sha);rendered=json.loads(subprocess.check_output(['/usr/bin/python3.12','-B',str(hf/'pilot.py'),'--plan',str(selected/'pilot.json')]));command=rendered['request']['command'];sub={'plan':plan,'namespace':'Autismo-Yah','job':{'id':'synthetic-job','command':command},'request':rendered['request']};(selected/'submission.json').write_text(json.dumps(sub));base={'planSHA256':ps,'bindingsPath':str(root/'bindings.json'),'bindingsSHA256':sha(bb),'selectionPath':str(selected/'selection.json'),'selectionSHA256':sha(sr),'authoritySubject':subject,'programSHA256':sha(command[-1].encode())};(root/'manifest').write_bytes((root/'manifest-mirror.json').read_bytes());collector=root/'collect-author-after.py'
 results={}
 for mode in ['zero-program','consistent-wrong-command','input-helper-mutated']:
  rec=dict(base);submission=json.loads(json.dumps(sub));helper=root/'retain-contiguous-inputs003.py';original=helper.read_bytes()
  if mode=='zero-program':rec['programSHA256']='0'*64
  if mode=='consistent-wrong-command':submission['request']['command']=['node','-e','wrong'];submission['job']['command']=['node','-e','wrong']
  if mode=='input-helper-mutated':helper.write_bytes(original+b'\n# synthetic mutation\n')
  (selected/'submission.json').write_text(json.dumps(submission));rb=json.dumps(rec).encode();(root/'receipt').write_bytes(rb)
  sp=importlib.util.spec_from_file_location('collector_boundary',collector);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);calls=[]
  original_run=subprocess.run
  def never_provider(*args,**kwargs):
   if '--collect' in args[0]:calls.append(args);raise RuntimeError('SYNTHETIC_PROVIDER_CALL_FORBIDDEN')
   return original_run(*args,**kwargs)
  m.subprocess.run=never_provider
  sys.argv=['collect','--selected-dir',str(selected),'--plan-sha256',ps,'--prestart',str(root/'receipt'),'--prestart-sha256',sha(rb),'--caller-sha256',caller_sha,'--job-id','synthetic-job','--manifest',str(root/'manifest')]
  try:
   with contextlib.redirect_stdout(io.StringIO()):m.main()
  except (RuntimeError,AssertionError):pass
  else:raise AssertionError(mode+' accepted')
  subprocess.run=original_run
  assert not calls and not (selected/'author-collector-intent.json').exists();results[mode]='HOLD';helper.write_bytes(original)
 print(json.dumps({'stage':'SYNTHETIC_REAL_COLLECTOR_BOUNDARY','results':results,'real11Validator':True,'realInertPilotRender':True,'providerAction':False,'secretAccess':False}))
