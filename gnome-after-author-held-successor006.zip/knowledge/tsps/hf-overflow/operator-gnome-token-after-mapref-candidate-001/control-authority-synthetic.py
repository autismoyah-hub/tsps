"""Synthetic direct-review capture validation; no real reviewer evidence."""
import copy,hashlib,importlib.util,json,pathlib,tempfile
r=pathlib.Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('authority_control',r/'prestart-colour-before-v1.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as d:
 ws=pathlib.Path(d);m.WS=ws;capture=b'synthetic direct session capture';review=b'synthetic review artifact';(ws/'capture').write_bytes(capture);(ws/'review').write_bytes(review);subject={'synthetic':'subject'};record={'type':'EXECUTOR_CAPTURED_DIRECT_REVIEW_CONTRACT','issuer':m.REVIEWER,'owner':m.OWNER,'operator':m.OPERATOR,'verdict':'EXACT_INPUT_PROFILE_GO','subject':subject,'directSessionEvidence':{'session':m.REVIEWER,'origin':'EXECUTOR_OBSERVED_DIRECT_SESSION_MESSAGE','capturePath':'capture','captureSHA256':hashlib.sha256(capture).hexdigest()},'reviewArtifacts':[{'path':'review','sha256':hashlib.sha256(review).hexdigest(),'reviewer':m.REVIEWER,'stage':'EXACT_INPUT_PROFILE_GO'}]};m.validate_authority(record,subject);results={'syntheticBoundAuthority':'PASS'}
 for mode in ['wrong-reviewer','wrong-subject','bad-capture-hash']:
  row=copy.deepcopy(record)
  if mode=='wrong-reviewer':row['issuer']='other'
  if mode=='wrong-subject':row['subject']={'wrong':True}
  if mode=='bad-capture-hash':row['directSessionEvidence']['captureSHA256']='0'*64
  try:m.validate_authority(row,subject)
  except AssertionError:results[mode]='HOLD'
  else:raise AssertionError(mode+' accepted')
 print(json.dumps({'stage':'SYNTHETIC_AUTHORITY_CONTROLS','results':results,'actualReviewerCapture':False,'providerAction':False}))
