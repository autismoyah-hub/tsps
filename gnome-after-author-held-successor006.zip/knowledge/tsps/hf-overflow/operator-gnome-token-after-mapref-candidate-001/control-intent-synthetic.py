"""Synthetic workspace-only intent scan; no provider or game."""
import importlib.util,json,pathlib,tempfile
root=pathlib.Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('intent_control',root/'prestart-colour-before-v1.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as d:
 ws=pathlib.Path(d);m.WS=ws;current=ws/'case'/'selected-current';current.mkdir(parents=True);plan={'source':'synthetic','name':'synthetic','executionHold':False,'ownerSelection':{'owner':'synthetic'}};(current/'pilot.json').write_text(json.dumps(plan));m.scan_owned_intents(plan,current/'pilot.json')
 sibling=ws/'case'/'selected-sibling';sibling.mkdir();(sibling/'pilot.json').write_text(json.dumps(plan))
 try:m.scan_owned_intents(plan,current/'pilot.json')
 except RuntimeError:pass
 else:raise AssertionError('sibling selection accepted')
 (sibling/'pilot.json').write_text(json.dumps({**plan,'executionHold':True}));(sibling/'mapref-runtime-custody.json').write_text(json.dumps({'stage':'SUBMISSION_STARTING_INTENT_RECONCILIATION_REQUIRED','planSHA256':'synthetic'}))
 try:m.scan_owned_intents(plan,current/'pilot.json')
 except RuntimeError:pass
 else:raise AssertionError('ambiguous custody accepted')
 (sibling/'mapref-runtime-custody.json').write_text('{')
 try:m.scan_owned_intents(plan,current/'pilot.json')
 except RuntimeError:pass
 else:raise AssertionError('malformed custody accepted')
 print(json.dumps({'stage':'SYNTHETIC_INTENT_SCAN','currentOnly':'PASS','siblingSelected':'HOLD','ambiguousBeforeSubmission':'HOLD','malformedCustody':'HOLD','providerAction':False,'gameTest':False}))
