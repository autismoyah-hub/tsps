﻿// SOURCE CANDIDATE: immutable full SHA/Gitblob manifest; no submission logic.
async function resolveInputManifest(plan, fetcher = fetch) {
  if (!plan.expectedInputsRef) {
    if (!plan.expectedInputs || typeof plan.expectedInputs !== 'object') throw Error('Inline input map missing');
    return {expectedInputs:plan.expectedInputs, sourceBlobs:null, provenance:null};
  }
  const crypto = require('node:crypto');
  const fail = message => { throw Error(`Input manifest: ${message}`); };
  const spec = plan.expectedInputsRef;
  const exactKeys = (value, keys) => value && typeof value==='object' && !Array.isArray(value)
    && Object.keys(value).sort().join('\0')===keys.sort().join('\0');
  if (plan.expectedInputs || plan.sourceBlobs) fail('inline/reference ambiguity');
  if (!exactKeys(spec,['schema','repository','artifactCommit','path','sha256','bytes','source','count'])) fail('reference schema');
  if (spec.schema!==1 || spec.repository!==plan.repository || !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(spec.repository)) fail('repository/schema');
  if (!/^[a-f0-9]{40}$/.test(spec.artifactCommit) || !/^[a-f0-9]{64}$/.test(spec.sha256)
      || spec.source!==plan.source || !/^[a-f0-9]{40}$/.test(spec.source)) fail('immutable identity/source');
  if (!Number.isSafeInteger(spec.bytes) || spec.bytes<1 || spec.bytes>2*1024*1024
      || !Number.isSafeInteger(spec.count) || spec.count<1 || spec.count>10000) fail('bounds');
  const safe = file => typeof file==='string' && file.length>0 && !file.includes('\\') && !file.includes(':')
    && !file.includes('\0') && !file.startsWith('/') && file.split('/').every(x=>x && x!=='.' && x!=='..');
  if (!safe(spec.path) || !/^[A-Za-z0-9_./-]+\.json$/.test(spec.path)) fail('artifact path');
  const url=`https://raw.githubusercontent.com/${spec.repository}/${spec.artifactCommit}/${spec.path}`;
  const response=await fetcher(url,{redirect:'error',signal:AbortSignal.timeout(60000)});
  if (!response.ok) fail(`HTTP ${response.status}`);
  if (response.url && response.url!==url) fail('response URL differs');
  const chunks=[];let count=0;
  for await(const chunk of response.body) {
    count+=chunk.length;if(count>spec.bytes) fail('byte limit exceeded');chunks.push(Buffer.from(chunk));
  }
  const raw=Buffer.concat(chunks), digest=crypto.createHash('sha256').update(raw).digest('hex');
  if(raw.length!==spec.bytes || digest!==spec.sha256) fail('byte identity');
  let doc;try{doc=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw));}catch{fail('UTF8/JSON');}
  if(!exactKeys(doc,['schema','source','tests','expectedTestCounts','expectedInputs','sourceBlobs'])) fail('document schema');
  if(doc.schema!==1 || doc.source!==plan.source || JSON.stringify(doc.tests)!==JSON.stringify(plan.tests)
      || JSON.stringify(doc.expectedTestCounts)!==JSON.stringify(plan.expectedTestCounts??{})) fail('source/test binding');
  const keys=Object.keys(doc.expectedInputs??{}).sort(), blobKeys=Object.keys(doc.sourceBlobs??{}).sort();
  if(keys.length!==spec.count || keys.join('\0')!==blobKeys.join('\0')) fail('count/keyset');
  for(const file of keys) if(!safe(file) || !/^[a-f0-9]{64}$/.test(doc.expectedInputs[file])
      || !/^[a-f0-9]{40}$/.test(doc.sourceBlobs[file])) fail('path/SHA/blob row');
  for(const file of plan.tests??[]) if(!keys.includes(`server/tests/${file}`)) fail('selected test missing');
  return {expectedInputs:doc.expectedInputs,sourceBlobs:doc.sourceBlobs,
    provenance:{schema:1,url,artifactCommit:spec.artifactCommit,path:spec.path,sha256:digest,bytes:raw.length,source:doc.source,count:keys.length}};
}
module.exports={resolveInputManifest};
