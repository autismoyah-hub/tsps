"""Synthetic parent guard controls; all child/provider calls are fake."""
import contextlib,datetime,hashlib,importlib.util,io,json,pathlib,sys,tempfile,types
ROOT=pathlib.Path(__file__).resolve().parent;SRC=ROOT/'submit-colour-before-v1.py';sha=lambda x:hashlib.sha256(x).hexdigest()
def exercise(mode):
 spec=importlib.util.spec_from_file_location('submit_control',SRC);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 with tempfile.TemporaryDirectory() as td:
  ws=pathlib.Path(td);root=ws/'case';hf=ws/'hf';root.mkdir();hf.mkdir();selected=root/'selected';selected.mkdir();m.ROOT=root;m.WS=ws;m.HF=hf
  plan={'source':'synthetic','name':'synthetic','executionHold':False,'ownerSelection':{'owner':'owner'},'tests':['x'],'expectedInputsRef':{'sha256':sha(b'manifest'),'count':4894},'image':'img','flavor':'cpu','timeout':1800,'attempts':1,'expectedCacheFiles':{}};pr=json.dumps(plan).encode();(selected/'pilot.json').write_bytes(pr);ps=sha(pr);(root/'prestart-colour-before-v1.py').write_bytes(b'caller');(root/'submit-colour-before-v1.py').write_bytes(SRC.read_bytes());m.__file__=str(root/'submit-colour-before-v1.py')
  files={'originalPlan':b'{}','originalRequest':b'{"forkRef":"ref"}','profileBasis':json.dumps({k:plan[k] for k in ['image','flavor','timeout','attempts','expectedCacheFiles']}).encode(),'pilot':b'pilot','caller':b'caller','submitCaller':SRC.read_bytes()}
  b={}
  for k,v in files.items():p=ws/k;p.write_bytes(v);b[k]={'path':k,'sha256':sha(v)}
  (hf/'pilot.py').write_bytes(b'pilot');bb=json.dumps(b).encode();(root/'bindings').write_bytes(bb);selection={'action':'SELECT_ONCE','attempts':1,'owner':'owner','source':'synthetic','planSHA256':ps,'manifestSHA256':sha(b'manifest'),'count':4894,'tests':['x']};sr=json.dumps(selection).encode();(root/'selection').write_bytes(sr);authority={'subject':{'bound':'subject'}};ab=json.dumps(authority).encode();(root/'authority').write_bytes(ab);reconciliation=b'{}';(root/'reconciliation').write_bytes(reconciliation);(root/'downloaded-manifest.json').write_bytes(b'manifest')
  rec={'stage':'SELECTED_REFERENCE_PRESTART_CHECKED_NO_JOB_API','noJobAPI':True,'planSHA256':ps,'source':'synthetic','count':4894,'manifest':{'sha256':sha(b'manifest')},'localDuplicateScan':'CLEAR','createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prestartCallerSHA256':sha(b'caller'),'selectedPlanPath':str(selected/'pilot.json'),'bindingsPath':str(root/'bindings'),'bindingsSHA256':sha(bb),'bindings':b,'selectionPath':str(root/'selection'),'selectionSHA256':sha(sr),'authoritySHA256':sha(ab),'normalReconciliationSHA256':sha(reconciliation),'authoritySubject':{'bound':'subject'},'programSHA256':sha(b'program')};rb=json.dumps(rec).encode();(root/'receipt').write_bytes(rb)
  if mode=='wrong-subject':rec['authoritySubject']={'wrong':True};rb=json.dumps(rec).encode();(root/'receipt').write_bytes(rb)
  if mode=='existing-intent':(selected/'submission.json').write_text('{}')
  fake=types.SimpleNamespace(OWNER='owner',OPERATOR='owner',ORIGINAL_PLAN=sha(files['originalPlan']),ORIGINAL_REQUEST=sha(files['originalRequest']),PROFILE_BASIS=sha(files['profileBasis']),COLOUR_REF='ref',PYTHON=pathlib.Path('/usr/bin/python3.12'),SDK=ws/'sdk',EXTRA_PINS={'authenticated-child-snapshot-command.py':'fake','hf-project-access-v4.py':'fake'},verify_runtime=lambda:None,bound=lambda p,h:p.read_bytes() if sha(p.read_bytes())==h else (_ for _ in ()).throw(RuntimeError('pin mismatch')),build_authority_subject=lambda *a:{'bound':'subject'},validate_authority=lambda *a:None,validate_reconciliation=lambda *a:None,resolve_bytes=lambda *a:{},validate_lineage=lambda *a:None,scan_owned_intents=lambda *a:None)
  def pair(expected,receipt,authority):
   if expected!=receipt or expected!=authority:raise RuntimeError('subject mismatch')
  fake.verify_subject_pair=pair;helper=types.SimpleNamespace(authenticated_pilot_command=lambda *a:['python','-c','fake']);m.load_verified_caller=lambda path,digest:helper if path.name.startswith('authenticated') else fake
  preview={'request':{'command':['node','-e','wrong' if mode=='wrong-render' else 'program']}};m.subprocess.check_output=lambda *a:json.dumps(preview).encode();calls=[]
  def fake_run(*a,**kw):calls.append(a);raise RuntimeError('synthetic uncertain child')
  m.subprocess.run=fake_run;sys.argv=['submit','--receipt',str(root/'receipt'),'--authority',str(root/'authority'),'--reconciliation',str(root/'reconciliation'),'--receipt-sha256',sha(rb),'--submit-once']
  try:
   with contextlib.redirect_stdout(io.StringIO()):m.main()
  except (RuntimeError,AssertionError):pass
  else:raise AssertionError('expected hold')
  custody=selected/'mapref-runtime-custody.json'
  if mode=='child-uncertain':assert len(calls)==1 and custody.exists() and json.loads(custody.read_bytes())['stage']=='SUBMISSION_STARTING_INTENT_RECONCILIATION_REQUIRED'
  else:assert not calls and not custody.exists()
  return 'HOLD'
results={x:exercise(x) for x in ['wrong-subject','existing-intent','wrong-render','child-uncertain']};print(json.dumps({'stage':'SYNTHETIC_SUBMIT_CONTROLS','results':results,'providerAction':False,'secretAccess':False,'subprocess':'fake'}))
