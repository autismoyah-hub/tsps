"""Synthetic-only validator controls; no actual provider or session evidence."""
import copy,datetime,hashlib,importlib.util,json,pathlib,tempfile
r=pathlib.Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('validation_control',r/'prestart-colour-before-v1.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
 ws=pathlib.Path(td);m.WS=ws;now=datetime.datetime.now(datetime.timezone.utc).isoformat();plan_sha='a'*64;selection_sha='b'*64;name='synthetic';common={'source':m.COLOUR_SOURCE,'owner':m.OWNER,'planSHA256':plan_sha,'selectionSHA256':selection_sha,'checkedUTC':now};owned={**common,'scope':'owner session and workspace only','ownedMatchingToolCells':[],'pendingOrAmbiguousMatchingIntents':[],'submittedMatchingJobs':[]};provider={**common,'namespace':'Autismo-Yah','status':'CLEAR','sourceJobs':[],'nameJobs':[],'legacyUnresolved':[],'projectJobs':[],'sourceQuery':{'project':'tsps','source':m.COLOUR_SOURCE},'nameQuery':{'project':'tsps','name':name},'projectQuery':{'project':'tsps'},'noProviderWrite':True}
 def ref(n,value):
  raw=json.dumps(value).encode();(ws/n).write_bytes(raw);return {'path':n,'sha256':hashlib.sha256(raw).hexdigest()}
 record={'operator':m.OPERATOR,'source':m.COLOUR_SOURCE,'planSHA256':plan_sha,'selectionSHA256':selection_sha,'checkedUTC':now,'ownedMatchingToolCells':[],'pendingOrAmbiguousMatchingIntents':[],'submittedMatchingJobs':[],'ownedToolEvidence':ref('owned',owned),'providerReconciliation':{'status':'CLEAR','scope':'same selected source/name; executor reconciliation, not global census','evidence':[ref('provider',provider)]}}
 m.validate_reconciliation(record,plan_sha,selection_sha,name);results={'syntheticClear':'PASS'}
 for mode in ['stale','wrong-namespace','partial','unnamed-legacy','wrong-name-query','owned-ambiguous']:
  row=copy.deepcopy(record);proof=copy.deepcopy(provider);own=copy.deepcopy(owned)
  if mode=='stale':proof['checkedUTC']='2000-01-01T00:00:00+00:00'
  if mode=='wrong-namespace':proof['namespace']='wrong'
  if mode=='partial':del proof['projectJobs']
  if mode=='unnamed-legacy':proof['projectJobs']=[{'jobId':'x','stage':'COMPLETED','labels':{'project':'tsps'}}]
  if mode=='wrong-name-query':proof['nameQuery']['name']='wrong'
  if mode=='owned-ambiguous':own['pendingOrAmbiguousMatchingIntents']=['synthetic']
  row['ownedToolEvidence']=ref('owned',own);row['providerReconciliation']['evidence']=[ref('provider',proof)]
  try:m.validate_reconciliation(row,plan_sha,selection_sha,name)
  except (AssertionError,KeyError):results[mode]='HOLD'
  else:raise AssertionError(mode+' accepted')
 print(json.dumps({'stage':'SYNTHETIC_RECONCILIATION_VALIDATOR','results':results,'providerAction':False,'secretAccess':False}))
