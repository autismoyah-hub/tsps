"""Synthetic mutation of an owned copy; does not run provider or game."""
import importlib.util,json,pathlib,shutil,tempfile
source=pathlib.Path(__file__).resolve().parents[4]
with tempfile.TemporaryDirectory() as d:
 dest=pathlib.Path(d)/'workspace';shutil.copytree(source,dest,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 r=dest/'knowledge/tsps/hf-overflow/operator-gnome-token-after-mapref-candidate-001';spec=importlib.util.spec_from_file_location('synthetic_bindings',r/'prestart-colour-before-v1.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);plan=json.loads((r/'held-001/pilot.json').read_bytes());bindings=json.loads((r/'bindings.json').read_bytes());m.validate_binding_bundle(bindings,plan,r/'held-001');p=r/'retain-contiguous-inputs003.py';p.write_bytes(p.read_bytes()+b'\n# synthetic mutation\n')
 try:m.validate_binding_bundle(bindings,plan,r/'held-001')
 except AssertionError:pass
 else:raise AssertionError('mutated input collector accepted')
 print(json.dumps({'stage':'SYNTHETIC_BINDING_MUTATION','original11':'PASS','changedInputCollector':'HOLD','providerAction':False,'gameTest':False}))
