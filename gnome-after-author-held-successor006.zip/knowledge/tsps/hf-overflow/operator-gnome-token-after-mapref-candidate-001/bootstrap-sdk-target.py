"""Create a private SDK target without venv/ensurepip or OS/global changes.

Ordinary dependency preparation only. No secret access or HF provider requests.
Requires Python 3.10+, TLS and HTTPS access to the normal PyPI package route.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import urllib.request

URL = 'https://files.pythonhosted.org/packages/44/3c/d717024885424591d5376220b5e836c2d5293ce2011523c9de23ff7bf068/pip-25.3-py3-none-any.whl'
SHA = '9655943313a94722b7774661c21049070f6bbb0a1516bf02f7c8d5d9201514cd'
SIZE = 1778622


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        raise RuntimeError('Python 3.10+ required')
    root = args.root.resolve()
    root.mkdir(parents=True, exist_ok=False)  # Failed attempts remain immutable.
    started = time.monotonic()
    with urllib.request.urlopen(URL, timeout=60) as response:
        if response.url != URL:
            raise RuntimeError('Unexpected package redirect')
        wheel = response.read(SIZE + 1)
    if len(wheel) != SIZE or hashlib.sha256(wheel).hexdigest() != SHA:
        raise RuntimeError('Pinned pip wheel identity mismatch')
    path = root / 'pip-25.3-py3-none-any.whl'
    path.write_bytes(wheel)
    downloaded = time.monotonic()
    target = root / 'site-packages'
    target.mkdir()
    code = "import runpy,sys;sys.path.insert(0,sys.argv.pop(1));runpy.run_module('pip',run_name='__main__')"
    subprocess.run([sys.executable, '-I', '-c', code, str(path), 'install',
                    '--disable-pip-version-check', '--no-cache-dir',
                    '--index-url', 'https://pypi.org/simple', '--target', str(target),
                    'huggingface_hub==2.4.0'], check=True, timeout=600)
    installed = time.monotonic()
    verify = "import sys,importlib.metadata as m;sys.path.insert(0,sys.argv[1]);import huggingface_hub;assert m.version('huggingface_hub')=='2.4.0';print(m.version('huggingface_hub'))"
    subprocess.run([sys.executable, '-I', '-c', verify, str(target)], check=True, timeout=30)
    launcher = root / 'python-with-hf.py'
    launcher.write_text("import runpy,sys\nfrom pathlib import Path\nsys.path.insert(0,str(Path(__file__).resolve().parent/'site-packages'))\nentry=Path(sys.argv.pop(1)).resolve()\nsys.path.insert(0,str(entry.parent))\nsys.argv[0]=str(entry)\nrunpy.run_path(str(entry),run_name='__main__')\n", encoding='utf-8')
    receipt = dict(pipWheelSHA256=SHA, SDK='2.4.0', python=sys.version,
                   downloadSeconds=downloaded-started, installSeconds=installed-downloaded,
                   totalSeconds=time.monotonic()-started, providerAction=False,
                   globalMutation=False, secretAccess=False)
    (root / 'setup-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(receipt))


if __name__ == '__main__':
    main()
