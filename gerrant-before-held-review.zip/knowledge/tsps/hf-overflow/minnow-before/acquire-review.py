"""Retain a matching actual Cuttle reviewer-session turn, not a signature."""
import argparse,datetime,hashlib,importlib.util,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
if not sys.dont_write_bytecode: raise RuntimeError('Invoke Python with -B')
p=argparse.ArgumentParser();p.add_argument('--subject',type=pathlib.Path,required=True);p.add_argument('--receipt',type=pathlib.Path,required=True);p.add_argument('--reviewer-receipt-sha256',required=True);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
subject=json.loads(a.subject.read_bytes());receipt=a.receipt.read_bytes()
if hashlib.sha256(receipt).hexdigest()!=a.reviewer_receipt_sha256:raise ValueError('reviewer receipt pin mismatch')
adapter_file=root/'review-capture.py'
if hashlib.sha256(adapter_file.read_bytes()).hexdigest()!='19bafa90c132f6cd476e8534bff9ba3f59f93cb9b93893168c4d7d22c8bcbb20':raise ValueError('capture adapter mismatch')
spec=importlib.util.spec_from_file_location('capture',adapter_file);adapter=importlib.util.module_from_spec(spec);spec.loader.exec_module(adapter)
raw,turn=adapter.acquire(subject,a.reviewer_receipt_sha256)
a.output.mkdir(parents=True,exist_ok=False)
(a.output/'reviewer-transcript.json').write_bytes(raw)
metadata={'session':adapter.REVIEWER,'command':list(adapter.COMMAND),'acquiredUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selectedTurn':turn,'captureSHA256':hashlib.sha256(raw).hexdigest(),'receiptSHA256':a.reviewer_receipt_sha256}
(a.output/'capture-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'stage':'REVIEW_CAPTURE_RETAINED','captureSHA256':metadata['captureSHA256']}))
