"""DRAFT: bind actual provider and owner-captured tool-cell evidence, never fabricate CLEAR."""
from pathlib import Path
import argparse, datetime, hashlib, json, sys
ROOT=Path(__file__).resolve().parent
WS=ROOT.parents[3]
OWNER='2db7d476-4556-4b73-b9cf-543d86a32863'
SOURCE='96aec4f3602d388b072349df1e94c02760acb360'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def fresh(value):
    age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(value)).total_seconds()
    if not 0<=age<=300: raise RuntimeError('Evidence is stale')
def main():
    if not sys.dont_write_bytecode: raise RuntimeError('Invoke Python with -B')
    p=argparse.ArgumentParser()
    for name in ('plan','selection','provider','owned-tool-evidence','output'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();plan_raw=a.plan.read_bytes();selection_raw=a.selection.read_bytes();plan=json.loads(plan_raw);selection=json.loads(selection_raw)
    ps=sha(plan_raw);ss=sha(selection_raw)
    if plan['source']!=SOURCE or selection['source']!=SOURCE or selection['owner']!=OWNER or selection['planSHA256']!=ps or selection['action']!='SELECT_ONCE' or selection['attempts']!=1:raise RuntimeError('Selection mismatch')
    provider_raw=a.provider.read_bytes();provider=json.loads(provider_raw);owned_raw=a.owned_tool_evidence.read_bytes();owned=json.loads(owned_raw)
    for row in (provider,owned):
        if row['source']!=SOURCE or row['owner']!=OWNER or row['planSHA256']!=ps or row['selectionSHA256']!=ss:raise RuntimeError('Evidence binding mismatch')
        fresh(row['checkedUTC'])
    if provider['namespace']!='Autismo-Yah' or provider['status']!='CLEAR' or provider['sourceJobs'] or provider['nameJobs'] or provider['noProviderWrite'] is not True:raise RuntimeError('Provider match or invalid evidence')
    if owned['scope']!='owner session and workspace only' or owned['ownedMatchingToolCells'] or owned['pendingOrAmbiguousMatchingIntents'] or owned['submittedMatchingJobs']:raise RuntimeError('Owner work or intent not clear')
    # Scan all known retained intents in the owner workspace; unreadable data fails closed.
    for file in WS.rglob('submission.json'):
        old=json.loads(file.read_bytes()).get('plan',{})
        if old.get('source')==SOURCE or old.get('name')==plan['name']:raise RuntimeError('Owned submission already exists')
    for file in WS.rglob('mapref-runtime-custody.json'):
        old=json.loads(file.read_bytes())
        if old.get('planSHA256')==ps:raise RuntimeError('Existing owned custody requires reconciliation')
    def ref(path,raw): return {'path':str(path.resolve().relative_to(WS)), 'sha256':sha(raw)}
    record={'operator':OWNER,'source':SOURCE,'planSHA256':ps,'selectionSHA256':ss,
            'checkedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'ownedMatchingToolCells':[],'pendingOrAmbiguousMatchingIntents':[],'submittedMatchingJobs':[],
            'ownedToolEvidence':ref(a.owned_tool_evidence,owned_raw),
            'providerReconciliation':{'status':'CLEAR','scope':'same selected source/name; normal sole-operator reconciliation, not global census','evidence':[ref(a.provider,provider_raw)]}}
    with a.output.open('x',encoding='utf-8') as out: json.dump(record,out,indent=2)
    print(json.dumps({'stage':'OWNED_RECONCILIATION_ASSEMBLED','scope':'owner workspace and exact provider source/name; not atomic global lease'}))
if __name__=='__main__':main()
