"""SOURCE CANDIDATE ONLY; no main/submission invocation in source tests.
One unchanged-pilot submission, followed by MANUAL same-job collection owned by
sole author 2db7d476. A job remains owned even if returned-command/binding write fails.
"""
from pathlib import Path
import sys
import argparse,datetime,hashlib,json,subprocess,types
ROOT=Path(__file__).resolve().parent;WS=ROOT.parents[3];HF=ROOT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def load_verified_caller(file,digest,read_bytes=None):
 raw=(read_bytes or (lambda path:Path(path).read_bytes()))(file)
 assert sha(raw)==digest,'Caller bytes differ BEFORE execution'
 module=types.ModuleType('mapref_verified_prestart');module.__file__=str(file)
 exec(compile(raw,str(file),'exec'),module.__dict__)
 return module

def validate_receipt(receipt,plan,plan_sha):
 assert receipt['stage']=='SELECTED_REFERENCE_PRESTART_CHECKED_NO_JOB_API' and receipt['noJobAPI'] is True
 assert receipt['planSHA256']==plan_sha and receipt['source']==plan['source'] and receipt['count']==4894
 assert receipt['manifest']['sha256']==plan['expectedInputsRef']['sha256'] and receipt['localDuplicateScan']=='CLEAR'
 age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(receipt['createdUTC'])).total_seconds()
 assert 0<=age<=300,'Prestart expired; no submission performed'
 assert not plan.get('executionHold')

def current_review_subject(module,receipt,plan,plan_sha,bindings,bindings_sha,selection,caller_sha):
 assert selection['action']=='SELECT_ONCE' and selection['attempts']==1 and selection['owner']==module.OWNER
 assert selection['source']==plan['source'] and selection['planSHA256']==plan_sha
 assert selection['manifestSHA256']==plan['expectedInputsRef']['sha256'] and selection['count']==4894 and selection['tests']==plan['tests']
 return module.build_authority_subject(plan,plan_sha,bindings,bindings_sha,receipt['selectionSHA256'],caller_sha)

def main():
 if not sys.dont_write_bytecode: raise RuntimeError('Invoke Python with -B')
 p=argparse.ArgumentParser(description=__doc__)
 for key in ['receipt','authority','reconciliation']:p.add_argument('--'+key,type=Path,required=True)
 p.add_argument('--receipt-sha256',required=True);p.add_argument('--submit-once',action='store_true',required=True)
 a=p.parse_args();raw=a.receipt.read_bytes();assert sha(raw)==a.receipt_sha256;receipt=json.loads(raw)
 caller=ROOT/'prestart-colour-before-v1.py'
 # Never import/execute candidate bytes ahead of their exact pin check.
 module=load_verified_caller(caller,receipt['prestartCallerSHA256'])
 module.verify_runtime()
 plan_path=Path(receipt['selectedPlanPath']);raw_plan=plan_path.read_bytes();plan=json.loads(raw_plan);plan_sha=sha(raw_plan)
 validate_receipt(receipt,plan,plan_sha)
 bindings_raw=module.bound(Path(receipt['bindingsPath']),receipt['bindingsSHA256']);bindings=json.loads(bindings_raw)
 assert bindings==receipt['bindings'],'Current binding bundle differs'
 assert sha(Path(__file__).read_bytes())==bindings['submitCaller']['sha256']
 for entry in bindings.values():module.bound(WS/entry['path'],entry['sha256'])
 assert bindings['caller']['sha256']==sha(caller.read_bytes())
 assert bindings['originalPlan']['sha256']==module.ORIGINAL_PLAN and bindings['originalRequest']['sha256']==module.ORIGINAL_REQUEST and bindings['profileBasis']['sha256']==module.PROFILE_BASIS
 original=json.loads(module.bound(WS/bindings['originalPlan']['path'],module.ORIGINAL_PLAN))
 request=json.loads(module.bound(WS/bindings['originalRequest']['path'],module.ORIGINAL_REQUEST));assert request['forkRef']==module.COLOUR_REF
 selection_raw=module.bound(Path(receipt['selectionPath']),receipt['selectionSHA256']);selection=json.loads(selection_raw)
 expected=current_review_subject(module,receipt,plan,plan_sha,bindings,sha(bindings_raw),selection,sha(caller.read_bytes()))
 authority=json.loads(module.bound(a.authority,receipt['authoritySHA256']))
 # Compare BOTH supplied subjects against the independently reconstructed current one.
 module.verify_subject_pair(expected,receipt['authoritySubject'],authority['subject'])
 module.validate_authority(authority,expected)
 reconciliation=json.loads(module.bound(a.reconciliation,receipt['normalReconciliationSHA256']));module.validate_reconciliation(reconciliation,plan_sha,receipt['selectionSHA256'],plan['name'])
 downloaded=a.receipt.parent/'downloaded-manifest.json';manifest_raw=module.bound(downloaded,plan['expectedInputsRef']['sha256'])
 resolved=module.resolve_bytes(plan,manifest_raw);module.validate_lineage(plan,resolved,original,module.COLOUR_REF)
 basis=json.loads(module.bound(WS/bindings['profileBasis']['path'],module.PROFILE_BASIS))
 for key in ['image','flavor','timeout','attempts','expectedCacheFiles']:assert plan[key]==basis[key]
 assert not (plan_path.parent/'submission.json').exists(),'Existing intent: reconcile, never resubmit'
 for file in WS.rglob('submission.json'):
  old=json.loads(file.read_bytes()).get('plan',{});assert not(old.get('source')==plan['source'] or old.get('name')==plan['name'])
 preview_command=[str(module.PYTHON),'-B',str(HF/'pilot.py'),'--plan',str(plan_path)]
 rendered=json.loads(subprocess.check_output(preview_command));program=rendered['request']['command'][-1]
 helper_path=ROOT/'authenticated-child-snapshot-command.py'
 helper=load_verified_caller(helper_path,module.EXTRA_PINS[helper_path.name])
 command=helper.authenticated_pilot_command(str(module.PYTHON),ROOT/'hf-project-access-v4.py',module.EXTRA_PINS['hf-project-access-v4.py'],HF/'pilot.py',bindings['pilot']['sha256'],plan_path,module.SDK)
 command.insert(1,'-B')
 assert sha(program.encode())==receipt['programSHA256'] and all(len(x.encode())+1<131072 for x in rendered['request']['command'])
 custody_path=plan_path.parent/'mapref-runtime-custody.json'
 custody={'stage':'SUBMISSION_STARTING_INTENT_RECONCILIATION_REQUIRED','owner':module.OPERATOR,'planSHA256':plan_sha,'prestartReceiptSHA256':a.receipt_sha256,'noAutomaticRetry':True,'collection':'MANUAL same-job via unchanged pilot.py; not automatic','jobId':None}
 with custody_path.open('x') as stream:json.dump(custody,stream,indent=2)
 try:
  subprocess.run(command+['--submit'],check=True)
 finally:
  intent=plan_path.parent/'submission.json'
  if intent.exists():
   retained=json.loads(intent.read_bytes());custody['jobId']=retained.get('job',{}).get('id')
   custody['stage']='ADMITTED_BINDING_PENDING_MANUAL_COLLECTION_OWNED' if custody['jobId'] else 'AMBIGUOUS_INTENT_OWNED_RECONCILIATION_REQUIRED'
  custody_path.write_text(json.dumps(custody,indent=2)+'\n')
 submitted=json.loads((plan_path.parent/'submission.json').read_bytes())
 assert submitted['plan']==plan and submitted['request']==rendered['request'] and submitted['job']['command']==rendered['request']['command']
 binding={'jobId':submitted['job']['id'],'prestartReceiptPath':str(a.receipt),'prestartReceiptSHA256':a.receipt_sha256,'planSHA256':plan_sha,'programSHA256':receipt['programSHA256'],'renderedEqualsSubmittedEqualsReturned':True,'noAutomaticRetry':True,'collector':'MANUAL sole-owner authenticated unchanged pilot.py --plan SAME_PLAN --collect; retain-job-result.py only after separate formal terminal. This wrapper does NOT collect or classify.'}
 with (plan_path.parent/'mapref-submission-binding.json').open('x') as stream:json.dump(binding,stream,indent=2)
 custody['stage']='ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED';custody_path.write_text(json.dumps(custody,indent=2)+'\n')
 print(json.dumps(binding))
if __name__=='__main__':main()
