"""DRAFT: same-owner, same-job manual collection; no submission and no retry."""
from pathlib import Path
import sys
import argparse, datetime, hashlib, json, shutil, subprocess, types, uuid
ROOT = Path(__file__).resolve().parent
HF = ROOT.parent

def digest(raw): return hashlib.sha256(raw).hexdigest()
def load_snapshot(path, expected):
    raw = path.read_bytes()
    if digest(raw) != expected: raise RuntimeError('Reviewed source changed')
    mod = types.ModuleType('pinned_collect_component'); mod.__file__ = str(path)
    exec(compile(raw, str(path), 'exec'), mod.__dict__)
    return mod

def main():
    if not sys.dont_write_bytecode: raise RuntimeError('Invoke Python with -B')
    p = argparse.ArgumentParser()
    p.add_argument('--selected-dir', type=Path, required=True)
    p.add_argument('--plan-sha256', required=True)
    p.add_argument('--prestart', type=Path, required=True)
    p.add_argument('--prestart-sha256', required=True)
    p.add_argument('--caller-sha256', required=True)
    p.add_argument('--job-id', required=True)
    p.add_argument('--manifest', type=Path, required=True)
    a = p.parse_args()
    caller = load_snapshot(ROOT / 'prestart-colour-before-v1.py', a.caller_sha256)
    caller.verify_runtime()
    selected = a.selected_dir.resolve(strict=True)
    if selected.parent != ROOT: raise RuntimeError('Selected directory outside owned case')
    plan_bytes = (selected / 'pilot.json').read_bytes()
    if digest(plan_bytes) != a.plan_sha256: raise RuntimeError('Selected plan changed')
    plan = json.loads(plan_bytes)
    sub = json.loads((selected / 'submission.json').read_bytes())
    prestart = a.prestart.read_bytes()
    if digest(prestart) != a.prestart_sha256: raise RuntimeError('Prestart changed')
    rec = json.loads(prestart)
    if rec['planSHA256'] != a.plan_sha256 or sub['plan'] != plan or sub['job']['id'] != a.job_id:
        raise RuntimeError('Plan or job binding mismatch')
    if sub['namespace'] != 'Autismo-Yah' or sub['request']['command'] != sub['job']['command']:
        raise RuntimeError('Namespace or returned command mismatch')
    helper = load_snapshot(ROOT / 'authenticated-child-snapshot-command.py', caller.EXTRA_PINS['authenticated-child-snapshot-command.py'])
    pilot = HF / 'pilot.py'
    bindings = json.loads(Path(rec['bindingsPath']).read_bytes())
    if digest(Path(rec['bindingsPath']).read_bytes()) != rec['bindingsSHA256']: raise RuntimeError('Bindings changed')
    command = helper.authenticated_pilot_command(str(caller.PYTHON), ROOT / 'hf-project-access-v4.py', caller.EXTRA_PINS['hf-project-access-v4.py'], pilot, bindings['pilot']['sha256'], selected / 'pilot.json', caller.SDK)
    command.insert(1, '-B')
    marker = selected / 'author-collector-intent.json'
    claim = {'jobId': a.job_id, 'planSHA256': a.plan_sha256, 'collector': caller.OWNER, 'automaticRetry': False}
    if marker.exists():
        if json.loads(marker.read_bytes()) != claim: raise RuntimeError('Different collector claim')
    else:
        with marker.open('x') as f: json.dump(claim, f, indent=2)
    lock = selected / 'author-collector-active.lock'
    with lock.open('x') as f: json.dump(claim, f)
    try:
        before = {p.name for p in selected.glob('status-*.json')}
        # Retain previously captured raw snapshots even if the pilot clock moves backwards.
        previous = list(selected.glob('status-*.json')) + list(selected.glob('logs-*.txt')) + list(selected.glob('decoded-*'))
        if previous:
            archive = selected / 'snapshot-history' / uuid.uuid4().hex
            archive.mkdir(parents=True, exist_ok=False)
            for old in previous:
                if old.is_dir(): shutil.copytree(old, archive / old.name)
                elif old.is_file(): shutil.copy2(old, archive / old.name)
                else: raise RuntimeError('Unexpected snapshot type')
        # Unchanged pilot uses UTC second names; fail closed rather than overwrite a prior snapshot.
        stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        if (selected / ('status-' + stamp + '.json')).exists() or (selected / ('logs-' + stamp + '.txt')).exists():
            raise RuntimeError('Snapshot second already used; same collector must wait for a later second')
        subprocess.run(command + ['--collect'], check=True)
        added = [p for p in selected.glob('status-*.json') if p.name not in before]
        if len(added) != 1: raise RuntimeError('Expected one new status snapshot')
        status_path = added[0]; status = json.loads(status_path.read_bytes())
        if status['id'] != a.job_id or status['command'] != sub['request']['command']:
            raise RuntimeError('Terminal job or command mismatch')
        stage = status['status']['stage']
        if stage not in ('COMPLETED','ERROR','CANCELED','CANCELLED'):
            print(json.dumps({'stage':'SAME_JOB_PENDING','jobId':a.job_id,'providerStage':stage}))
            return
        manifest = a.manifest.read_bytes(); spec = plan['expectedInputsRef']
        if len(manifest) != spec['bytes'] or digest(manifest) != spec['sha256']:
            raise RuntimeError('Manifest changed')
        relative = selected.relative_to(HF)
        subprocess.run([str(caller.PYTHON), '-B', str(HF / 'retain-job-result.py'), str(relative)], check=True)
        log = selected / ('logs-' + status_path.stem.removeprefix('status-') + '.txt')
        subprocess.run([str(caller.PYTHON), '-B', str(ROOT / 'retain-contiguous-inputs003.py'),
            '--raw', str(log), '--manifest', str(a.manifest), '--submission', str(selected / 'submission.json'),
            '--terminal-status', str(status_path), '--out', str(selected / 'actual-inputs')], check=True)
        print(json.dumps({'stage':'SAME_JOB_TERMINAL_RETAINED','jobId':a.job_id,'providerStage':stage,
                          'scope':'process-group evidence only; no PID1 or escaped-descendant claim'}))
    finally:
        lock.unlink()

if __name__ == '__main__': main()
