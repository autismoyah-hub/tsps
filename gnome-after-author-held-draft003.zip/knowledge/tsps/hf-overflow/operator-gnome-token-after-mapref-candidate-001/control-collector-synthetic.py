import contextlib, datetime, hashlib, importlib.util, io, json, pathlib, sys, tempfile, types
source=pathlib.Path('/tmp/gnome-author-after-001/knowledge/tsps/hf-overflow/operator-gnome-token-after-mapref-candidate-001/collect-author-after.py')
spec=importlib.util.spec_from_file_location('collect_synthetic',source);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
sha=lambda b:hashlib.sha256(b).hexdigest()
with tempfile.TemporaryDirectory() as td:
 hf=pathlib.Path(td)/'hf';root=hf/'case';selected=root/'selected';selected.mkdir(parents=True);m.ROOT=root;m.HF=hf
 plan={'source':'synthetic','expectedInputsRef':{}};manifest=b'synthetic-manifest';plan['expectedInputsRef']={'bytes':len(manifest),'sha256':sha(manifest)};pb=json.dumps(plan).encode();(selected/'pilot.json').write_bytes(pb);(root/'manifest').write_bytes(manifest)
 command=['node','-e','synthetic'];submission={'plan':plan,'namespace':'Autismo-Yah','job':{'id':'synthetic-job','command':command},'request':{'command':command}};(selected/'submission.json').write_text(json.dumps(submission))
 bindings={'pilot':{'sha256':'fake'}};bb=json.dumps(bindings).encode();(root/'bindings').write_bytes(bb);receipt={'planSHA256':sha(pb),'bindingsPath':str(root/'bindings'),'bindingsSHA256':sha(bb)};rb=json.dumps(receipt).encode();(root/'prestart').write_bytes(rb)
 caller=types.SimpleNamespace(verify_runtime=lambda:None,OWNER='synthetic-owner',PYTHON=pathlib.Path('/usr/bin/python3.12'),SDK=root/'sdk',EXTRA_PINS={'authenticated-child-snapshot-command.py':'fake','hf-project-access-v4.py':'fake'})
 helper=types.SimpleNamespace(authenticated_pilot_command=lambda *args:['python','-c','synthetic']);m.load_snapshot=lambda p,h: helper if p.name.startswith('authenticated') else caller
 stages=iter(['RUNNING','COMPLETED']);calls=[]
 def fake_run(argv,check):
  calls.append(argv)
  if '--collect' in argv:
   stage=next(stages);stamp='20000101T00000'+str(len([x for x in calls if '--collect' in x]))+'Z';(selected/('status-'+stamp+'.json')).write_text(json.dumps({'id':'synthetic-job','status':{'stage':stage},'command':command}));(selected/('logs-'+stamp+'.txt')).write_text('synthetic '+stage)
  return types.SimpleNamespace(returncode=0)
 m.subprocess.run=fake_run
 sys.argv=['collect','--selected-dir',str(selected),'--plan-sha256',sha(pb),'--prestart',str(root/'prestart'),'--prestart-sha256',sha(rb),'--caller-sha256','fake','--job-id','synthetic-job','--manifest',str(root/'manifest')]
 with contextlib.redirect_stdout(io.StringIO()):m.main();m.main()
 assert len([x for x in calls if '--collect' in x])==2
 assert len([x for x in calls if 'retain-job-result.py' in ' '.join(x)])==1
 assert len([x for x in calls if 'retain-contiguous-inputs003.py' in ' '.join(x)])==1
 history=list((selected/'snapshot-history').glob('*/logs-*'));assert any(p.read_text()=='synthetic RUNNING' for p in history)
 assert json.loads((selected/'author-collector-intent.json').read_bytes())['jobId']=='synthetic-job'
 assert not (selected/'author-collector-active.lock').exists()
 # Conflicting ownership and a live lock both fail before collection.
 lock=selected/'author-collector-active.lock';lock.write_text('held')
 try:
  with contextlib.redirect_stdout(io.StringIO()):m.main()
  raise AssertionError('concurrent lock accepted')
 except FileExistsError:pass
 lock.unlink();claim=selected/'author-collector-intent.json';value=json.loads(claim.read_bytes());value['collector']='other';claim.write_text(json.dumps(value))
 try:
  with contextlib.redirect_stdout(io.StringIO()):m.main()
  raise AssertionError('conflicting collector accepted')
 except RuntimeError as e:assert 'Different collector' in str(e)
 value['collector']='synthetic-owner';claim.write_text(json.dumps(value))
 stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');collision=selected/('status-'+stamp+'.json');collision.write_text('synthetic prior snapshot');count=len(calls)
 try:
  with contextlib.redirect_stdout(io.StringIO()):m.main()
  raise AssertionError('timestamp collision accepted')
 except RuntimeError as e:assert 'Snapshot second already used' in str(e)
 assert len(calls)==count and collision.read_text()=='synthetic prior snapshot' and not lock.exists()
 print(json.dumps({'stage':'SYNTHETIC_COLLECTOR_CONTROLS','sameJobSequentialPolling':'PASS','pendingSnapshotArchived':'PASS','terminalOnlyOfflineHelpers':'PASS','concurrentLock':'HOLD','conflictingCollector':'HOLD','sameSecondCollision':'HOLD','fakeSubprocess':True,'providerAction':False,'secretAccess':False}))
