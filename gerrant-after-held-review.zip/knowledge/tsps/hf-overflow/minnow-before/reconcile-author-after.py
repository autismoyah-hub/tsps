"""DRAFT, read-only: record same-source Jobs evidence; never submits or retries."""
from pathlib import Path
import sys
import argparse, datetime, hashlib, json

SOURCE = '1a2a73d65a5d7f2b9c727ff57f57e684e69d1c43'
OWNER = '5a967b7b-d32d-47c6-a4ad-b5871c8ef12d'
NAMESPACE = 'Autismo-Yah'

def sha(raw): return hashlib.sha256(raw).hexdigest()

def main():
    if not sys.dont_write_bytecode: raise RuntimeError('Invoke Python with -B')
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--selection', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    plan_raw = args.plan.read_bytes(); selection_raw = args.selection.read_bytes()
    plan = json.loads(plan_raw); selection = json.loads(selection_raw)
    if plan['source'] != SOURCE or selection['source'] != SOURCE or selection['owner'] != OWNER:
        raise RuntimeError('Case source or owner mismatch')
    if plan.get('executionHold') is not False or (plan.get('ownerSelection') or {}).get('owner') != OWNER:
        raise RuntimeError('Plan is not owner-selected')
    if selection.get('manifestSHA256') != plan['expectedInputsRef']['sha256'] or selection.get('count') != plan['expectedInputsRef']['count'] or selection.get('tests') != plan['tests']:
        raise RuntimeError('Selection inputs mismatch')
    if selection['action'] != 'SELECT_ONCE' or selection['attempts'] != 1 or selection['planSHA256'] != sha(plan_raw):
        raise RuntimeError('Selection mismatch')
    # The reviewed explicit-auth adapter supplies token to every HfApi call.
    from huggingface_hub import HfApi
    api = HfApi()
    if api.whoami()['name'] != NAMESPACE: raise RuntimeError('Unexpected namespace')
    def collect(labels):
        rows = []
        for job in api.list_jobs(namespace=NAMESPACE, labels=labels):
            stage = getattr(getattr(job.status, 'stage', None), 'value', getattr(job.status, 'stage', None))
            if not job.id or not stage: raise RuntimeError('Incomplete job metadata')
            actual_labels = job.labels or {}
            row = {'jobId': str(job.id), 'stage': str(stage),
                   'labels': {key: str(actual_labels[key]) for key in ('project','source','name') if key in actual_labels}}
            for field in ('created_at','started_at','finished_at'):
                value = getattr(job, field, None)
                if value is not None: row[field] = value.isoformat() if hasattr(value, 'isoformat') else str(value)
            rows.append(row)
        return rows
    source_jobs = collect({'project':'tsps','source':SOURCE})
    name_jobs = collect({'project':'tsps','name':plan['name']})
    project_jobs = collect({'project':'tsps'})
    # A row lacking source cannot establish source nonoverlap, even if it has a different name.
    legacy_unresolved = [row for row in project_jobs if not row['labels'].get('source')]
    # Any match remains a HOLD, including terminal jobs; no automatic ownership transfer.
    result = {'source':SOURCE,'owner':OWNER,'namespace':NAMESPACE,'planSHA256':sha(plan_raw),
              'selectionSHA256':sha(selection_raw),'checkedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'sourceQuery':{'project':'tsps','source':SOURCE},'sourceJobs':source_jobs,
              'nameQuery':{'project':'tsps','name':plan['name']},'nameJobs':name_jobs,
              'projectQuery':{'project':'tsps'},'projectJobs':project_jobs,'legacyUnresolved':legacy_unresolved,
              'status':'HOLD' if source_jobs or name_jobs or legacy_unresolved or any(not (row.get('jobId') == '6af0c74ce6320c66fad779c5' and row.get('stage') == 'ERROR' and row['labels'].get('source') == 'a9b0f948c901ce73fb40d87247b1eda19954c117') and (row['labels'].get('source') in {'1a2a73d65a5d7f2b9c727ff57f57e684e69d1c43','a9b0f948c901ce73fb40d87247b1eda19954c117'} or row['labels'].get('name') in {'gerrant-trade-after-held','gerrant-trade-before-held'}) for row in project_jobs) else 'CLEAR',
              'scope':'same source or name labels; not atomic global lease','noProviderWrite':True}
    with args.output.open('x', encoding='utf-8') as out: json.dump(result, out, indent=2)
    print(json.dumps({'stage':'READ_ONLY_RECONCILIATION', 'status':result['status'], 'sourceCount':len(source_jobs), 'nameCount':len(name_jobs), 'legacyUnresolvedCount':len(legacy_unresolved)}))

if __name__ == '__main__': main()
