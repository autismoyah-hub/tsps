"""Offline controls for changed BEFORE bindings and workspace scanner only."""
import importlib.util,json,pathlib,tempfile
root=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('case_prestart',root/'prestart-colour-before-v1.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
plan=json.loads((root/'held-001/pilot.json').read_text());bindings=json.loads((root/'bindings.json').read_text());m.validate_binding_bundle(bindings,plan,root/'held-001')
orig=json.loads((root/'original-case-full-plan.json').read_text());resolved={'expectedInputs':orig['expectedInputs'],'sourceBlobs':orig['sourceBlobs']};m.validate_lineage(plan,resolved,orig,m.COLOUR_REF)
with tempfile.TemporaryDirectory() as d:
 m.WS=pathlib.Path(d);current=m.WS/'current'/'pilot.json';current.parent.mkdir();current.write_text(json.dumps(plan));m.scan_owned_intents(plan,current)
 for source,name in [('85f2568b5dba4e2e7968adb099b0bf8e66e1aae7','other'),('2a58cab282b120dca88f8e3eb005df88d8beac6c','other'),('unrelated','minnow-capacity-after-held')]:
  sibling=m.WS/'selected-other'/'pilot.json';sibling.parent.mkdir(exist_ok=True);sibling.write_text(json.dumps({'source':source,'name':name,'ownerSelection':{'owner':'other'},'executionHold':False}))
  try:m.scan_owned_intents(plan,current)
  except RuntimeError:pass
  else:raise AssertionError('conflicting selected sibling was admitted')
  sibling.unlink()
 sibling=m.WS/'selected-other'/'pilot.json';sibling.write_text('{broken')
 try:m.scan_owned_intents(plan,current)
 except RuntimeError:pass
 else:raise AssertionError('malformed selected sibling was admitted')
print('BEFORE_CONTROLS_PASS 11-key binding, lineage, empty workspace and 4 sibling refusals; synthetic only')
