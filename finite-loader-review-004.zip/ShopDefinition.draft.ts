export type ShopCurrency = "COINS" | "BLOOD_MONEY" | "POINTS" | string;

export type ShopBuySource =
    | { kind: "absent" }
    | { kind: "present"; raw: string }
    | { kind: "unknown"; raw?: string };

export interface ShopSalesPolicy {
    generalStore?: boolean;
    sellMultiplier?: number;
    priceChangePer?: number;
    /** DRAFT: only explicitly attested unique same-currency rows can be absent. */
    specialistRowBuyPolicies?: Readonly<Record<number, "absent" | "unknown">>;
}

export interface ShopStockDefinition {
    id: number;
    amount: number;
    restockTicks: number | null;
    price: number | null;
    buySource?: ShopBuySource;
    buySourceCurrencyMatches?: boolean;
}

export class ShopDefinition {
    private static definitions = new Map<number, ShopDefinition>();

    constructor(
        private readonly id: number,
        private readonly name: string,
        private readonly currency: ShopCurrency,
        private readonly originalStock: ShopStockDefinition[],
        private readonly defaultRestockTicks: number,
        private readonly defaultDestockTicks: number,
        private readonly soldItemDestockTicks: number,
        private readonly source: string,
        private readonly salesPolicy: ShopSalesPolicy = {}
    ) {}

    public static replace(definitions: ShopDefinition[]): void {
        this.definitions.clear();
        for (const definition of definitions) {
            this.definitions.set(definition.getId(), definition);
        }
    }

    /** Adds one definition without replacing the rest (a plugin's shop for one player, see ShopManager.registerShop). */
    public static register(definition: ShopDefinition): void {
        this.definitions.set(definition.getId(), definition);
    }

    public static unregister(id: number): void {
        this.definitions.delete(id);
    }

    public static forId(id: number): ShopDefinition | undefined {
        return this.definitions.get(id);
    }

    public static all(): readonly ShopDefinition[] {
        return Array.from(this.definitions.values());
    }

    public getId(): number {
        return this.id;
    }

    public getName(): string {
        return this.name;
    }

    public getCurrency(): ShopCurrency {
        return this.currency;
    }

    public getOriginalStock(): readonly ShopStockDefinition[] {
        return this.originalStock;
    }

    public getDefaultRestockTicks(): number {
        return this.defaultRestockTicks;
    }

    public getDefaultDestockTicks(): number {
        return this.defaultDestockTicks;
    }

    public getSoldItemDestockTicks(): number {
        return this.soldItemDestockTicks;
    }

    public getSource(): string {
        return this.source;
    }

    public getSalesPolicy(): Readonly<ShopSalesPolicy> {
        return this.salesPolicy;
    }
}
