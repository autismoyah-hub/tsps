// ISOLATED SOURCE DRAFT, unrun. Requires a build of the reviewed loader candidate.
const assert = require('node:assert/strict');
const {test} = require('node:test');
const {ShopDefinitionLoader} = require('../dist/game/definition/loader/impl/ShopDefinitionLoader');
const loader = new ShopDefinitionLoader();
function definition(currency, generalStore, rows, sellMultiplier = 600, priceChangePer = 20, extra = {}) {
  return loader.toDefinition({id:999991,name:'Synthetic specialist',currency,generalStore,
    sellMultiplier,priceChangePer,originalStock:rows,...extra}, 'test');
}
function row(id, buySource, currencyMatch = true) {
  return {id,amount:1,buySource,buySourceCurrencyMatches:currencyMatch};
}
test('real loader only attests unique exact absent same-currency rows', () => {
  const shop = definition('COINS', false, [
    row(1353,{kind:'absent'}),
    row(1354,{kind:'present',raw:''}),
    row(1355,{kind:'present',raw:' 0 '}),
    row(1356,{kind:'present',raw:'N/A'}),
    row(1357,{kind:'present',raw:'{{formatnum:1|R}}'}),
    row(1358,undefined),
    row(1359,{kind:'absent',extra:true}),
    row(1360,{kind:'absent'},false),
    row(1361,{kind:'absent'}), row(1361,{kind:'absent'}),
  ]);
  assert.ok(shop);
  assert.deepEqual(shop.getSalesPolicy().specialistRowBuyPolicies, {
    1353:'absent',1354:'unknown',1355:'unknown',1356:'unknown',1357:'unknown',
    1358:'unknown',1359:'unknown',1360:'unknown',1361:'unknown',
  });
  const stock = shop.getOriginalStock();
  assert.deepEqual(stock.find(x=>x.id===1354).buySource,{kind:'present',raw:''});
  assert.deepEqual(stock.find(x=>x.id===1355).buySource,{kind:'present',raw:' 0 '});
  assert.deepEqual(stock.find(x=>x.id===1356).buySource,{kind:'present',raw:'N/A'});
  assert.deepEqual(stock.find(x=>x.id===1357).buySource,{kind:'present',raw:'{{formatnum:1|R}}'});
  assert.deepEqual(stock.find(x=>x.id===1359).buySource,{kind:'unknown'});
  assert.equal(stock.find(x=>x.id===1360).buySourceCurrencyMatches,false);
});
test('general and noncoin shops do not receive specialist attestations', () => {
  for (const [currency,general] of [['COINS',true],['STARDUST',false],['COINS',undefined]]) {
    const shop = definition(currency,general,[row(1353,{kind:'absent'})]);
    assert.equal(shop.getSalesPolicy().specialistRowBuyPolicies,undefined);
  }
});

// A malformed duplicate is removed from stock but must still taint the source ID.
test('raw duplicate IDs cannot become eligible after invalid stock is discarded', () => {
  const shop = definition('COINS',false,[row(1353,{kind:'absent'}),
    {id:1353,amount:-1,buySource:{kind:'present',raw:'N/A'},buySourceCurrencyMatches:true}]);
  assert.equal(shop.getOriginalStock().length,1);
  assert.equal(shop.getSalesPolicy().specialistRowBuyPolicies[1353],'unknown');
});
test('preset currency conversions and mixed legacy items never create coin attestations', () => {
  const cases = [
    definition('STARDUST',false,[row(1353,{kind:'absent'})],600,20,{requiresPresets:true}),
    definition('COINS',false,[row(1353,{kind:'absent'})],600,20,{requiresPresets:true}),
    definition('COINS',false,[row(1353,{kind:'absent'})],600,20,{items:[1353]}),
  ];
  for (const shop of cases) assert.equal(shop.getSalesPolicy().specialistRowBuyPolicies,undefined);
});

test('full loader reads synthetic files and registers qualified and refused provenance', t => {
  const fs = require('node:fs'), os = require('node:os'), path = require('node:path');
  const {GameConstants} = require('../dist/game/GameConstants');
  const {ShopDefinition} = require('../dist/game/definition/ShopDefinition');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'shop-loader-provenance-'));
  const prior = [...ShopDefinition.all()];
  const descriptor = Object.getOwnPropertyDescriptor(GameConstants, 'DEFINITIONS_DIRECTORY');
  assert.ok(descriptor);
  // Only the test's temporary synthetic files use this data path; restored even on failure.
  t.after(() => {
    ShopDefinition.replace(prior);
    Object.defineProperty(GameConstants, 'DEFINITIONS_DIRECTORY', descriptor);
    fs.rmSync(dir, {recursive:true,force:true});
  });
  Object.defineProperty(GameConstants, 'DEFINITIONS_DIRECTORY', {...descriptor,value:dir + path.sep});
  const specialist = {id:999991,name:'Synthetic specialist',currency:'COINS',generalStore:false,
    sellMultiplier:600,priceChangePer:20,originalStock:[
      row(1353,{kind:'absent'}),row(1354,{kind:'present',raw:'N/A'}),row(1355,undefined),
      row(1356,{kind:'absent'}),{id:1356,amount:-1,buySource:{kind:'present',raw:'0'},buySourceCurrencyMatches:true},
    ]};
  const general = {id:999992,name:'Synthetic general',currency:'COINS',generalStore:true,
    sellMultiplier:400,priceChangePer:30,originalStock:[row(1931,{kind:'absent'})]};
  const reward = {id:999993,name:'Synthetic reward',currency:'STARDUST',generalStore:false,
    sellMultiplier:800,priceChangePer:10,originalStock:[row(25537,{kind:'absent'})]};
  fs.writeFileSync(path.join(dir,'shops.json'),JSON.stringify([specialist,general,reward]));
  fs.writeFileSync(path.join(dir,'custom-shops.json'),'[]');
  assert.equal(new ShopDefinitionLoader().load(),true);
  const loaded = ShopDefinition.forId(999991); assert.ok(loaded);
  assert.deepEqual(loaded.getSalesPolicy().specialistRowBuyPolicies,
    {1353:'absent',1354:'unknown',1355:'unknown',1356:'unknown'});
  assert.deepEqual(loaded.getOriginalStock().find(x=>x.id===1354).buySource,{kind:'present',raw:'N/A'});
  assert.equal(ShopDefinition.forId(999992).getSalesPolicy().specialistRowBuyPolicies,undefined);
  assert.equal(ShopDefinition.forId(999993).getSalesPolicy().specialistRowBuyPolicies,undefined);
});

// Runtime currency defaults must not be used as source provenance.
test('missing, blank and malformed source currency cannot attest coin pricing', () => {
  for (const currency of [undefined, null, '', '   ', 995, 'coin']) {
    const shop = definition(currency, false, [row(1353,{kind:'absent'})]);
    assert.equal(shop.getSalesPolicy().specialistRowBuyPolicies, undefined);
  }
  for (const currency of ['COINS', ' coins ']) {
    const shop = definition(currency, false, [row(1353,{kind:'absent'})]);
    assert.equal(shop.getSalesPolicy().specialistRowBuyPolicies[1353], 'absent');
  }
});
