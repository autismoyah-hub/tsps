import * as fs from "fs";
import { GameConstants } from "../../../GameConstants";
import { CacheDefinitions } from "../../../cache/CacheDefinitions";
import {
    ShopDefinition,
    ShopStockDefinition,
} from "../../ShopDefinition";
import { DefinitionLoader, LoadedDefinitionSource } from "../DefinitionLoader";
import { PluginManager } from "../../../../plugins/PluginManager";

interface RawShopStockDefinition {
    id?: unknown;
    amount?: unknown;
    restockTicks?: unknown;
    restockTime?: unknown;
    restock?: unknown;
    price?: unknown;
}

interface RawShopDefinition {
    generalStore?: unknown;
    sellMultiplier?: unknown;
    priceChangePer?: unknown;
    id?: unknown;
    name?: unknown;
    currency?: unknown;
    originalStock?: unknown;
    items?: unknown;
    prices?: unknown;
    requiresPresets?: unknown;
    stockAmount?: unknown;
    defaultRestockTicks?: unknown;
    restockTicks?: unknown;
    defaultDestockTicks?: unknown;
    soldItemDestockTicks?: unknown;
}

let presetShopPricesEnabled = false;

export function setPresetShopPricesEnabled(enabled: boolean): void {
    presetShopPricesEnabled = enabled === true;
}

export class ShopDefinitionLoader extends DefinitionLoader {
    public static readonly DEFINITION_TYPE = "shops";
    public static readonly CORE_SOURCE = "core";
    public static readonly DEFAULT_STOCK_CHANGE_TICKS = 4;
    public static readonly GENERAL_STORE_SOLD_ITEM_DESTOCK_TICKS = 100;
    private itemIdsByName?: Map<string, number>;
    private unresolvedItemNames = new Set<string>();

    public load(): boolean {
        this.unresolvedItemNames.clear();
        const contributed = this.loadSources<RawShopDefinition>(
            ShopDefinitionLoader.DEFINITION_TYPE
        );
        const sources: LoadedDefinitionSource<RawShopDefinition>[] = [
            {
                name: ShopDefinitionLoader.CORE_SOURCE,
                owner: ShopDefinitionLoader.CORE_SOURCE,
                priority: 0,
                definitions: this.readCoreDefinitions(),
            },
            ...contributed.sources,
        ].sort((a, b) => {
            const priorityDifference = a.priority - b.priority;
            return priorityDifference !== 0
                ? priorityDifference
                : a.name.localeCompare(b.name);
        });

        const definitionsById = new Map<number, ShopDefinition>();
        let candidates = 0;
        let invalid = 0;
        for (const source of sources) {
            candidates += source.definitions.length;
            for (const raw of source.definitions) {
                const definition = this.toDefinition(raw, source.name);
                if (!definition) {
                    invalid++;
                    continue;
                }
                definitionsById.set(definition.getId(), definition);
            }
        }

        const definitions = Array.from(definitionsById.values());
        ShopDefinition.replace(definitions);
        (invalid > 0 || this.unresolvedItemNames.size > 0 ? console.warn : console.debug)(
            `[shops] Loaded ${definitions.length} definitions from ` +
            `${sources.map((source) => source.name).join("+")} ` +
            `(candidates=${candidates}, invalid=${invalid}, unresolvedStock=${this.unresolvedItemNames.size})`
        );
        return contributed.failures === 0;
    }

    public file(): string {
        return GameConstants.DEFINITIONS_DIRECTORY + "shops.json";
    }

    private readCoreDefinitions(): RawShopDefinition[] {
        const files = [this.file(), GameConstants.DEFINITIONS_DIRECTORY + "custom-shops.json"];
        const definitions: RawShopDefinition[] = [];
        for (const file of files) {
            const parsed: unknown = JSON.parse(fs.readFileSync(file, "utf8"));
            if (!Array.isArray(parsed)) {
                throw new Error(`${file} must contain an array`);
            }
            definitions.push(...parsed as RawShopDefinition[]);
        }
        return definitions;
    }

    private toDefinition(raw: RawShopDefinition, source: string): ShopDefinition | null {
        const id = Number(raw?.id);
        if (!Number.isInteger(id) || id < 0) {
            return null;
        }

        const defaultRestockTicks =
            this.parseTicks(raw.defaultRestockTicks) ??
            this.parseTicks(raw.restockTicks) ??
            ShopDefinitionLoader.DEFAULT_STOCK_CHANGE_TICKS;
        const defaultDestockTicks =
            this.parseTicks(raw.defaultDestockTicks) ?? defaultRestockTicks;
        const soldItemDestockTicks =
            this.parseTicks(raw.soldItemDestockTicks) ??
            ShopDefinitionLoader.GENERAL_STORE_SOLD_ITEM_DESTOCK_TICKS;

        const usePresetPrices = raw.requiresPresets === true && presetShopPricesEnabled;
        const prices = raw.requiresPresets === true && !usePresetPrices
            ? new Map<number, number>()
            : this.itemPrices(raw.prices);
        // The host editor's default stack size also fills originalStock rows that omit an
        // amount; imported shops leave stockAmount out, so their rows still default to one.
        const stockAmount = this.normalizeAmount(raw.stockAmount ?? 1);
        const stock: ShopStockDefinition[] = [];
        if (Array.isArray(raw.originalStock)) {
            for (const entry of raw.originalStock as RawShopStockDefinition[]) {
                const itemId = Number(entry?.id);
                const rawAmount = entry?.amount ?? stockAmount;
                const amount = this.normalizeAmount(rawAmount);
                // A listed stock of 0 is real: specialist shops (Gerrant's raw fish) show and
                // buy items they start with none of. The resolved amount counts, so a shop-wide
                // stockAmount of 0 keeps rows that omit their own amount.
                const listedEmpty = Number(rawAmount) === 0;
                if (!Number.isInteger(itemId) || itemId <= 0 || (amount <= 0 && !listedEmpty)) {
                    continue;
                }
                const price = prices.get(itemId) ?? Number(entry?.price);
                stock.push({
                    id: itemId,
                    amount,
                    restockTicks:
                        this.parseTicks(entry.restockTicks) ??
                        this.parseTicks(entry.restockTime) ??
                        this.parseTicks(entry.restock),
                    price: Number.isFinite(price) && price > 0
                        ? Math.floor(price)
                        : null,
                });
            }
        }
        for (const item of this.items(raw.items)) {
            const itemId = typeof item === "number" ? item : this.itemIdForName(item);
            if (itemId === null || stockAmount <= 0) {
                if (typeof item === "string") {
                    this.unresolvedItemNames.add(item);
                }
                continue;
            }
            stock.push({
                id: itemId,
                amount: stockAmount,
                restockTicks: null,
                price: prices.get(itemId) ?? null,
            });
        }

        // Plugins can drop stock entries (e.g. members items on a free-to-play world).
        const allowedStock = stock.filter((entry) => PluginManager.emitCanStockItem(id, entry.id) !== false);

        const name = typeof raw.name === "string" && raw.name.trim()
            ? raw.name.trim()
            : "Shop";
        const configuredCurrency = typeof raw.currency === "string" && raw.currency.trim()
            ? raw.currency.trim().toUpperCase().replace(/\s+/g, " ")
            : "COINS";
        // Blood money is the one currency key with an underscore; accept the Wiki's spaced name too.
        const currencyKey = configuredCurrency === "BLOOD MONEY" ? "BLOOD_MONEY" : configuredCurrency;
        const currency = raw.requiresPresets === true && !usePresetPrices
            ? "COINS"
            : currencyKey;
        return new ShopDefinition(
            id,
            name,
            currency,
            allowedStock,
            defaultRestockTicks,
            defaultDestockTicks,
            soldItemDestockTicks,
            source,
            {
                generalStore: typeof raw.generalStore === "boolean" ? raw.generalStore : undefined,
                sellMultiplier: Number.isSafeInteger(raw.sellMultiplier) && Number(raw.sellMultiplier) >= 0 ? Number(raw.sellMultiplier) : undefined,
                priceChangePer: Number.isSafeInteger(raw.priceChangePer) && Number(raw.priceChangePer) >= 0 ? Number(raw.priceChangePer) : undefined,
            }
        );
    }

    private normalizeAmount(value: unknown): number {
        const amount = Number(value);
        return Number.isFinite(amount) ? Math.max(0, Math.floor(amount)) : 0;
    }

    private items(value: unknown): Array<string | number> {
        const items: Array<string | number> = [];
        for (const item of Array.isArray(value) ? value : [value]) {
            if (typeof item === "number" && Number.isInteger(item) && item > 0) {
                items.push(item);
            } else if (typeof item === "string") {
                items.push(...item.split(",").map((name) => name.trim()).filter(Boolean));
            }
        }
        return items;
    }

    private itemPrices(value: unknown): Map<number, number> {
        const prices = new Map<number, number>();
        if (!value || typeof value !== "object" || Array.isArray(value)) {
            return prices;
        }
        for (const [item, rawPrice] of Object.entries(value as Record<string, unknown>)) {
            const itemId = Number.isInteger(Number(item))
                ? Number(item)
                : this.itemIdForName(item);
            const price = Number(rawPrice);
            if (itemId !== null && itemId > 0 && Number.isFinite(price) && price > 0) {
                prices.set(itemId, Math.floor(price));
            }
        }
        return prices;
    }

    private itemIdForName(name: string): number | null {
        if (!this.itemIdsByName) {
            this.itemIdsByName = new Map<string, number>();
            const count = CacheDefinitions.getCounts().items;
            for (let itemId = 0; itemId < count; itemId++) {
                const itemName = CacheDefinitions.getItem(itemId).name;
                if (itemName && !this.itemIdsByName.has(this.normalizeItemName(itemName))) {
                    this.itemIdsByName.set(this.normalizeItemName(itemName), itemId);
                }
            }
            for (const item of CacheDefinitions.getCustomItems()) {
                const itemName = item.objType?.name;
                if (typeof itemName === "string" && itemName && !this.itemIdsByName.has(this.normalizeItemName(itemName))) {
                    this.itemIdsByName.set(this.normalizeItemName(itemName), item.id);
                }
            }
        }
        return this.itemIdsByName.get(this.normalizeItemName(name)) ?? null;
    }

    private normalizeItemName(name: string): string {
        return name
            .toLowerCase()
            .replace(/[’']/g, "")
            .replace(/\b([a-z]+)s\b/g, "$1")
            .replace(/[^a-z0-9+]+/g, "");
    }

    private parseTicks(value: unknown): number | null {
        if (Number.isFinite(value)) {
            const ticks = Math.floor(Number(value));
            return ticks > 0 ? ticks : null;
        }
        if (typeof value !== "string" || !value.trim()) {
            return null;
        }

        const tickMatch = value.trim().match(/(\d+)\s*t\b/i);
        if (tickMatch) {
            const ticks = Number.parseInt(tickMatch[1], 10);
            return Number.isFinite(ticks) && ticks > 0 ? ticks : null;
        }
        const minuteMatch = value.trim().match(/(\d+(?:\.\d+)?)\s*m(?:in(?:ute)?s?)?\b/i);
        if (minuteMatch) {
            const minutes = Number.parseFloat(minuteMatch[1]);
            return Number.isFinite(minutes) && minutes > 0
                ? Math.max(1, Math.round((minutes * 60) / 0.6))
                : null;
        }
        const secondMatch = value.trim().match(/(\d+(?:\.\d+)?)\s*s(?:ec(?:ond)?s?)?\b/i);
        if (secondMatch) {
            const seconds = Number.parseFloat(secondMatch[1]);
            return Number.isFinite(seconds) && seconds > 0
                ? Math.max(1, Math.round(seconds / 0.6))
                : null;
        }
        return null;
    }
}
