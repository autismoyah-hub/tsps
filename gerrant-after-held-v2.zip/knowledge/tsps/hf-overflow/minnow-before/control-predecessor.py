"""Offline mutations of the retained predecessor and actual scanner; no provider calls."""
import importlib.util, pathlib, tempfile, shutil, json
root=pathlib.Path(__file__).resolve().parent
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
g=load('guard',root/'baseline-guard.py');caller=load('caller',root/'prestart-colour-before-v1.py');plan=json.loads((root/'held-001/pilot.json').read_bytes())
with tempfile.TemporaryDirectory() as d:
 t=pathlib.Path(d);before=t/'before/knowledge/tsps/hf-overflow/minnow-before/selected-001';after=t/'after';before.mkdir(parents=True);after.mkdir()
 shutil.copytree(g.BASELINE,after/'baseline'); shutil.copytree(g.LIVE,before,dirs_exist_ok=True,ignore=shutil.ignore_patterns('review-capture','snapshot-history','actual-inputs'))
 g.BASELINE=after/'baseline';g.LIVE=before;caller.WS=after;caller.load_baseline=lambda:(g.validate() and g)
 current=after/'selected-current/pilot.json';current.parent.mkdir();current.write_text(json.dumps(plan))
 caller.scan_owned_intents(plan,current)
 def rejected(fn):
  try:fn()
  except (AssertionError,RuntimeError,KeyError,ValueError):return
  raise AssertionError('mutation unexpectedly accepted')
 for n in ('feedback-causal-before.json','terminal-packet.zip','selection.json','submission.json'):
  f=g.BASELINE/n;data=f.read_bytes();f.write_bytes(data+b' ');rejected(lambda:caller.scan_owned_intents(plan,current));f.write_bytes(data)
 lock=g.LIVE/'author-collector-active.lock';lock.write_text('{}');rejected(lambda:caller.scan_owned_intents(plan,current));lock.unlink()
 row={'jobId':g.JOB,'stage':'ERROR','labels':{'project':'tsps','source':g.SOURCE}}
 assert g.known_provider(row)
 for changed in ({**row,'jobId':'other'}, {**row,'stage':'RUNNING'}, {**row,'labels':{'project':'tsps','source':'other'}}, {**row,'labels':{'project':'tsps','source':g.SOURCE,'name':'contradictory'}}):assert not g.known_provider(changed)
 extra=after/'selected-other/pilot.json';extra.parent.mkdir();extra.write_text(json.dumps({'source':g.SOURCE,'name':'other','ownerSelection':{'owner':'other'},'executionHold':False}));rejected(lambda:caller.scan_owned_intents(plan,current));extra.unlink()
 print('PREDECESSOR_CONTROLS_PASS exact retained predecessor, receipt/packet/selection/submission mutations, active lock, other selected sibling and provider job/stage/source/name refusals; offline only')
