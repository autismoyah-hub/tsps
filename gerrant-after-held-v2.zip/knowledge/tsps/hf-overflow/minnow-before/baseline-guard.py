"""Bind the one reviewed, terminal predecessor before allowing its records."""
import hashlib, json
from pathlib import Path
ROOT = Path(__file__).resolve().parent
BASELINE = ROOT / 'baseline'
LIVE = Path('/tmp/gerrant-review/knowledge/tsps/hf-overflow/minnow-before/selected-001')
JOB = '6af0c74ce6320c66fad779c5'
SOURCE = 'a9b0f948c901ce73fb40d87247b1eda19954c117'
PINS = {
 'feedback-causal-before.json':'f2f50644929671d977eec6b762edd68ace04ff348698056a61fdb3b236695ee9',
 'terminal-packet.zip':'6b62e58c5db87c54a4e1aed84a53155d7527a9eb1cf45dc0c979dc2e0ea07be3',
 'pilot.json':'f85b494a7f6b97d76916caa1df4fec792a07752a1d7a90c5f413da4e969f68a9',
 'selection.json':'4444bcd1ea6abbdd37afbe1c7017566bfe10b67195c4257247784aecabfb58aa',
 'submission.json':'929d18bc81a303a02b448fa99d7ef436da27f8df9d047a22a2b59e3f4ab67541',
 'prestart/prestart-readback.json':'d48aa95906d90496bb643bc3d657f27a470dd724849c0778fc7f374fdd0a013c',
 'mapref-runtime-custody.json':'2ceac9dafe2d572ee8438b7ab3917a41667c1cde84f84efd39cb4d7e2bd576e2',
 'mapref-submission-binding.json':'5b82f7756b8fdae3339ffd57309bd6cae55f95281093839da239eb1dac946e9f',
 'status-20261108T190456Z.json':'ada73dbef0aa6743fd29791e3e9bc5465b50071e97ba12ac38a059e190e8dbe7',
 'result.json':'3d95bd53432b4b8276f81c1dfe9d857debba891b728cc2c38f6026630fcc3ed4',
 'logs-20261108T190456Z.txt':'81b1ab8fe6d7910948136b79c507336cdd0eb92a18f659551d2410a14378e132',
 'author-collector-intent.json':'6e8745be3eebe54e916c7a9aaea9c1eb8b4e7cddcd2233541849b7cc90108ca0',
}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def validate():
 for name,digest in PINS.items():
  assert sha(BASELINE/name)==digest, name
  if name not in ('feedback-causal-before.json','terminal-packet.zip'):
   assert sha(LIVE/name)==digest, 'live predecessor '+name
 assert not (LIVE/'author-collector-active.lock').exists(), 'predecessor collector active or ambiguous'
 load=lambda n:json.loads((BASELINE/n).read_bytes())
 review=load('feedback-causal-before.json');sub=load('submission.json');status=load('status-20261108T190456Z.json');result=load('result.json');binding=load('mapref-submission-binding.json');custody=load('mapref-runtime-custody.json');sel=load('selection.json');plan=load('pilot.json');pre=load('prestart/prestart-readback.json');intent=load('author-collector-intent.json')
 assert review['verdict']=='SCOPED_CAUSAL_BEFORE_ACCEPTED' and review['classification']=='CAUSAL_BEHAVIOR_FAILURE' and review['jobId']==JOB and review['source']==SOURCE and review['namespace']=='Autismo-Yah' and review['terminalStage']=='ERROR' and review['packetSHA256']==PINS['terminal-packet.zip']
 assert all(review['packetMembersSHA256'][n]==PINS[n] for n in ('submission.json','result.json','status-20261108T190456Z.json','logs-20261108T190456Z.txt','mapref-submission-binding.json'))
 assert sub['namespace']=='Autismo-Yah' and sub['job']['id']==JOB and sub['plan']==plan and sub['request']['command']==sub['job']['command']==status['command'] and status['id']==JOB and status['status']['stage']=='ERROR' and result['jobId']==JOB and result['platformStatus']['stage']=='ERROR'
 assert sel['source']==SOURCE and sel['planSHA256']==PINS['pilot.json'] and sel['action']=='SELECT_ONCE' and sel['attempts']==1 and pre['planSHA256']==PINS['pilot.json'] and pre['selectionSHA256']==PINS['selection.json']
 assert binding['jobId']==JOB and binding['planSHA256']==PINS['pilot.json'] and binding['prestartReceiptSHA256']==PINS['prestart/prestart-readback.json'] and binding['programSHA256']==pre['programSHA256'] and binding['renderedEqualsSubmittedEqualsReturned'] is True
 assert custody['jobId']==JOB and custody['owner']==sel['owner'] and custody['planSHA256']==PINS['pilot.json'] and custody['noAutomaticRetry'] is True and intent=={'jobId':JOB,'planSHA256':PINS['pilot.json'],'collector':sel['owner'],'automaticRetry':False}
 return True

def known_provider(row):
 return row.get('jobId')==JOB and row.get('stage')=='ERROR' and row.get('labels',{}).get('project')=='tsps' and row['labels'].get('source')==SOURCE and row['labels'].get('name') in (None,'gerrant-trade-before-held')
