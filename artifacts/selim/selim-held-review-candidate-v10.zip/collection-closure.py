"""Conservative local custody/closure primitives; no provider operation."""
from pathlib import Path
import os,json,hashlib,datetime,uuid

TERMINAL={'COMPLETED','CANCELED','ERROR'}
def check_terminal(observation,job_id,expected_command_sha256):
    if observation.get('namespace')!='Autismo-Yah' or observation.get('jobId')!=job_id or observation.get('stage') not in TERMINAL or observation.get('commandSHA256')!=expected_command_sha256:raise ValueError('terminal observation absent, unknown or wrong job')
    try:age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(observation['observedUTC'])).total_seconds()
    except (KeyError,TypeError,ValueError):raise ValueError('terminal observation time')
    if not 0<=age<=300:raise ValueError('terminal observation stale')
    return True

def create_exclusive_intent(path,job_id,plan_sha,operator,observation_path,observation_sha256,expected_command_sha256):
    if operator!='433a743a-eb04-4066-8251-791c89e978e3' or not job_id or len(plan_sha)!=64:raise ValueError('intent identity')
    observation_path=Path(observation_path);observation_raw=observation_path.read_bytes()
    if hashlib.sha256(observation_raw).hexdigest()!=observation_sha256:raise ValueError('terminal capture drift')
    check_terminal(json.loads(observation_raw),job_id,expected_command_sha256)
    data={'terminalObservationPath':str(observation_path),'terminalObservationSHA256':hashlib.sha256(observation_raw).hexdigest(),'commandSHA256':expected_command_sha256,'stage':'COLLECTION_OWNED_PENDING','jobId':job_id,'planSHA256':plan_sha,'operator':operator,'noAutomaticRetry':True}
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return data

def retain_inspection(case,stdout,stderr,outcome):
    case=Path(case);capture_id=uuid.uuid4().hex
    def store(suffix,value):
        path=case/('terminal-inspection-'+capture_id+suffix)
        data=value if isinstance(value,bytes) else (value or '').encode()
        with path.open('xb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        return path,hashlib.sha256(data).hexdigest()
    out,out_sha=store('.stdout',stdout);err,err_sha=store('.stderr',stderr)
    meta=case/('terminal-inspection-'+capture_id+'.json')
    with meta.open('x') as f:json.dump({'outcome':outcome,'stdout':out.name,'stdoutSHA256':out_sha,'stderr':err.name,'stderrSHA256':err_sha},f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return out,meta

def snapshot_names(case):
    case=Path(case)
    return {p.name for pattern in ('status-*.json','logs-*.txt','decoded-*') for p in case.glob(pattern)}

def identify_collected(case,before,job_id):
    case=Path(case);after=snapshot_names(case);new=after-before
    statuses=sorted(x for x in new if x.startswith('status-') and x.endswith('.json'))
    if len(statuses)!=1 or sorted(case.glob('status-*.json'))[-1].name!=statuses[0]:raise ValueError('ambiguous status set')
    status_path=case/statuses[0];status=json.loads(status_path.read_bytes());stage=status.get('status',{}).get('stage')
    if status.get('id')!=job_id or stage not in TERMINAL:raise ValueError('wrong job or nonterminal collected status')
    stamp=statuses[0][7:-5];log=case/('logs-'+stamp+'.txt');decoded=case/('decoded-'+stamp)
    if log.name not in new or not log.is_file():raise ValueError('missing new matching log')
    def info(p):
        b=p.read_bytes();return {'path':p.relative_to(case).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    result={'jobId':job_id,'stage':stage,'status':info(status_path),'log':info(log),'newEntries':sorted(new),'decodedManifest':None}
    if decoded.name in new:
        manifest=decoded/'manifest.json'
        if not manifest.is_file():raise ValueError('incomplete decoded transport')
        result['decodedManifest']=info(manifest)
    return result
