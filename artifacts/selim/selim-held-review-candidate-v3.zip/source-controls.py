import pathlib,importlib.util,hashlib,tempfile,json,sys
R=pathlib.Path(__file__).resolve().parent
for name in ('nested-custody-scan','authenticated-child-snapshot-command'):
 path=R/(name+'.py');spec=importlib.util.spec_from_file_location(name.replace('-','_'),path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 if name.startswith('nested'):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t); (root/'a'/'b').mkdir(parents=True);(root/'a'/'b'/'submission.json').write_text('{}'); result=m.scan([root]);assert len(result['found'])==1 and not result['errors'] and not result['skippedSymlinkDirectories']
   (root/'linked').symlink_to(root/'a',target_is_directory=True);assert m.scan([root])['skippedSymlinkDirectories']
  print('nested scan: nested intent found; skipped symlink disclosed')
 else:
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); access=R/'hf-project-access-v4.py'; pilot=R/'pilot.py';plan=R/'before'/'pilot.json';cmd=m.authenticated_pilot_command(sys.executable,access,sha(access),pilot,sha(pilot),plan,'/workspace/selim-notes/author-sdk/site-packages');assert cmd[-3:]==['--','--plan',str(plan)] and all(len(a.encode())+1<131072 for a in cmd)
  try:m.authenticated_pilot_command(sys.executable,access,'0'*64,pilot,sha(pilot),plan)
  except RuntimeError:pass
  else:raise AssertionError('bad auth digest accepted')
  print('auth child argv: pinned sources accepted, changed digest rejected; child not executed')
for phase in ('before','after'):
 for name in ('prestart-selim.py','submit-selim.py'):
  src=(R/phase/name).read_text();compile(src,str(R/phase/name),'exec');assert "raise RuntimeError('HELD:" in src
print('candidate callers compile; held guards present; no main invoked')
