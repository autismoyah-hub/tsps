"""Pure validation of capture CONTENT only; these functions do not authenticate transport.
Live Cuttle/provider acquisition must be bound separately; callers remain unconditionally HELD.
"""
from datetime import datetime, timezone
import json
import hashlib
import shlex

PROJECT='tsps'; NAMESPACE='Autismo-Yah'

def correlate_direct_message(parent,owner,parent_transcript,owner_transcript,outgoing_text,sender_file=None,sender_name=None):
    parent_turns=parent_transcript.get('turns');owner_turns=owner_transcript.get('turns')
    if not isinstance(parent_turns,list) or not isinstance(owner_turns,list):raise ValueError('transcript')
    sent=[]
    for turn in parent_turns:
        if turn.get('role')!='assistant' or turn.get('kind')!='tool':continue
        tool=turn.get('tool') or {}
        commands=[]
        try: commands.append(json.loads(tool['input'])['command'])
        except (KeyError,TypeError,ValueError): pass
        if isinstance(tool.get('name'),str):commands.append(tool['name'])
        matched=False
        for command in commands:
            try: argv=shlex.split(command)
            except (TypeError,ValueError):continue
            direct=['cuttle','--json','sessions','send',owner,outgoing_text]
            file_send=['cuttle','--json','sessions','send',owner,'--file',sender_file] if sender_file else None
            if argv==direct or (file_send is not None and argv==file_send):matched=True
        if matched and isinstance(tool.get('id'),str):sent.append(turn)
    received=[]
    for turn in owner_turns:
        text=turn.get('text','');head,sep,body=text.partition('\n') if isinstance(text,str) else ('','','')
        expected_header='[From Cuttle session "'+sender_name+'" · '+parent+']' if sender_name else None
        if turn.get('role')=='user' and sep and head.startswith('[From Cuttle session "') and head.endswith(' · '+parent+']') and (expected_header is None or head==expected_header) and body==outgoing_text:received.append(turn)
    if len(sent)!=1 or len(received)!=1:raise ValueError('send tool or recipient turn mismatch')
    ident=sent[0]['tool']['id'];results=[t for t in parent_turns if t.get('role')=='user' and t.get('kind')=='tool_result' and (t.get('tool') or {}).get('id')==ident and (t.get('tool') or {}).get('ok') is True]
    if len(results)!=1:raise ValueError('send tool result')
    try:
        stamps=[datetime.fromisoformat(t['ts'].replace('Z','+00:00')) for t in (sent[0],received[0],results[0])]
        if any(t.tzinfo is None for t in stamps) or stamps[1]<stamps[0] or stamps[2]<stamps[0]:raise ValueError('message chronology')
    except (KeyError,TypeError,AttributeError):raise ValueError('message timestamp')
    return {'sent':stamps[0],'received':stamps[1],'result':stamps[2],'toolId':ident}

def validate_review_content(expected_subject, parent_identity, parent_transcript, owner_identity, owner_transcript, send_response, outgoing_text, nonce):
    if not isinstance(nonce,str) or len(nonce)<32: raise ValueError('bad nonce')
    parent='d750bb0b-a1e2-42b2-833b-1598278fc31b';owner='433a743a-eb04-4066-8251-791c89e978e3'
    if parent_identity.get('id')!=parent or owner_identity.get('id')!=owner: raise ValueError('identity')
    if send_response != {'ok':True,'sessionId':owner}: raise ValueError('send response')
    expected={'nonce':nonce,'verdict':'EXACT_INPUT_PROFILE_GO','subject':expected_subject}
    try:body=json.loads(outgoing_text)
    except (TypeError,ValueError):raise ValueError('outgoing JSON')
    if body!=expected:raise ValueError('outgoing subject or verdict')
    correlate_direct_message(parent,owner,parent_transcript,owner_transcript,outgoing_text)
    return True

def validate_attested_review(expected_subject,parent_identity,parent_transcript,owner_identity,owner_transcript,response_bytes,outgoing_bytes,ack_bytes,nonce):
    try:
        response=json.loads(response_bytes);outgoing=outgoing_bytes.decode('utf-8');ack=ack_bytes.decode('utf-8');attestation=json.loads(ack)
    except (TypeError,ValueError,UnicodeError):raise ValueError('invalid retained review bytes')
    validate_review_content(expected_subject,parent_identity,parent_transcript,owner_identity,owner_transcript,response,outgoing,nonce)
    expected={'nonce':nonce,'type':'REVIEW_SEND_RECEIPT_ATTESTATION','outgoingSHA256':hashlib.sha256(outgoing_bytes).hexdigest(),'responseSHA256':hashlib.sha256(response_bytes).hexdigest()}
    if attestation!=expected:raise ValueError('receipt attestation mismatch')
    parent=parent_identity['id'];owner=owner_identity['id']
    first=correlate_direct_message(parent,owner,parent_transcript,owner_transcript,outgoing)
    second=correlate_direct_message(parent,owner,parent_transcript,owner_transcript,ack)
    if second['sent']<first['received']:raise ValueError('attestation precedes verdict receipt')
    return True

def validate_provider_content(capture,source,name,now=None):
    now=now or datetime.now(timezone.utc)
    if capture.get('namespace')!=NAMESPACE or capture.get('project')!=PROJECT or capture.get('complete') is not True:raise ValueError('scope or incomplete listing')
    try: age=(now-datetime.fromisoformat(capture['finishedUTC'])).total_seconds()
    except (KeyError,ValueError,TypeError):raise ValueError('bad timestamp')
    if not 0<=age<=300:raise ValueError('stale listing')
    queries=capture.get('queries'); expected={'project':{'project':PROJECT},'source':{'project':PROJECT,'source':source},'name':{'project':PROJECT,'name':name}}
    if not isinstance(queries,dict) or set(queries)!=set(expected):raise ValueError('query set')
    def parse(key):
        q=queries[key]
        if not isinstance(q,dict) or q.get('labels')!=expected[key] or q.get('complete') is not True or not isinstance(q.get('rows'),list):raise ValueError('partial query')
        result={}
        for row in q['rows']:
            if not isinstance(row,dict) or not isinstance(row.get('id'),str) or not row['id'] or row['id'] in result:raise ValueError('row identity')
            labels=row.get('labels');stage=row.get('stage');owner=row.get('owner')
            if not isinstance(labels,dict) or any(not isinstance(labels.get(k),str) or not labels[k] for k in ('project','source','name')) or labels['project']!=PROJECT or stage not in {'COMPLETED','CANCELED','ERROR','DELETED','SCHEDULING','RUNNING'} or owner!=NAMESPACE:raise ValueError('partial row')
            result[row['id']]=row
        return result
    project,by_source,by_name=(parse(k) for k in ('project','source','name'))
    exact_source={k:v for k,v in project.items() if v['labels']['source']==source};exact_name={k:v for k,v in project.items() if v['labels']['name']==name}
    if by_source!=exact_source or by_name!=exact_name:raise ValueError('listing mismatch')
    if by_source or by_name:raise ValueError('existing source/name job; reconcile custody')
    return True
