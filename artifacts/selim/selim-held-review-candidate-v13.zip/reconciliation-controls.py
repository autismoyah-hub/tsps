"""Synthetic bounded ownership and local-conflict checks; no provider/Cuttle calls."""
from pathlib import Path
import importlib.util,json,datetime,types,copy
R=Path(__file__).resolve().parent
for phase in ('before','after'):
 spec=importlib.util.spec_from_file_location('candidate_'+phase,R/phase/'prestart-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 plan=json.loads((R/phase/'pilot.json').read_bytes());now=datetime.datetime.now(datetime.timezone.utc);ps='a'*64;ss='b'*64;record={'type':'BOUNDED_SAME_CASE_RECONCILIATION','operator':m.OPERATOR,'source':plan['source'],'name':plan['name'],'planSHA256':ps,'selectionSHA256':ss,'checkedUTC':now.isoformat(),'knownCaseSessions':[m.OWNER],'peerEvidence':{}}
 discovery={'scope':'synthetic only','sessions':[{'id':m.OWNER,'name':'Selim owner','status':'running'}]};oldload=m.load_guard_component;oldscan=m.scan_case_custody
 def load(file,digest):
  if file=='case-sessions.py':return types.SimpleNamespace(discover=lambda:discovery)
  return oldload(file,digest)
 m.load_guard_component=load;m.scan_case_custody=lambda:{'roots':['synthetic'],'found':[],'errors':[],'skippedSymlinkDirectories':[]}
 try:
  assert m.validate_reconciliation(record,ps,ss,plan)['localScan']['found']==[]
  for mode in ('wrong_source','stale','unknown_session','duplicate','missing_peer','local_conflict'):
   bad=copy.deepcopy(record);backup=copy.deepcopy(discovery)
   if mode=='wrong_source':bad['source']='wrong'
   if mode=='stale':bad['checkedUTC']=(now-datetime.timedelta(seconds=301)).isoformat()
   if mode=='unknown_session':discovery['sessions'].append({'id':'99999999-9999-4999-8999-999999999999','status':'running'})
   if mode=='duplicate':bad['knownCaseSessions'].append(m.OWNER)
   if mode=='missing_peer':bad['knownCaseSessions'].append('99999999-9999-4999-8999-999999999999')
   if mode=='local_conflict':m.scan_case_custody=lambda:(_ for _ in ()).throw(AssertionError('actual local conflict'))
   try:m.validate_reconciliation(bad,ps,ss,plan)
   except (ValueError,AssertionError):pass
   else:raise AssertionError('accepted '+mode)
   discovery.clear();discovery.update(backup);m.scan_case_custody=lambda:{'roots':['synthetic'],'found':[],'errors':[],'skippedSymlinkDirectories':[]}
 finally:m.load_guard_component=oldload;m.scan_case_custody=oldscan
 print(phase,'synthetic bounded reconciliation positive and six scope/freshness/conflict negatives; no Cuttle/provider/main')
# Actual case-name discovery parser rejects a capped list and malformed/duplicate sessions.
spec=importlib.util.spec_from_file_location('cases',R/'case-sessions.py');cases=importlib.util.module_from_spec(spec);spec.loader.exec_module(cases)
class Response:
 def __init__(self,data):self.stdout=json.dumps(data).encode()
def run_with(rows):return lambda *args,**kwargs:Response({'results':rows})
row={'id':'433a743a-eb04-4066-8251-791c89e978e3','projectId':cases.PROJECT,'name':'Selim owner','status':'running'}
assert len(cases.discover(run_with([row]))['sessions'])==1
for rows in ([row,row],[{'id':'x','projectId':cases.PROJECT,'name':'wrong'}],[row]*100):
 try:cases.discover(run_with(rows))
 except ValueError:pass
 else:raise AssertionError('bad discovery accepted')
print('synthetic name-search parser rejects duplicates, malformed names and 100-result cap')
