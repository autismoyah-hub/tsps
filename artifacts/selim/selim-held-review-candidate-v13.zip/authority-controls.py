"""Synthetic authenticated-context composition; no real Cuttle/provider/main calls."""
from pathlib import Path
import importlib.util,tempfile,json,hashlib,datetime,shlex,copy,os,urllib.request
R=Path(__file__).resolve().parent
for phase in ('before','after'):
 spec=importlib.util.spec_from_file_location('candidate_'+phase,R/phase/'prestart-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 owner=m.OWNER;reviewer=m.REVIEWER;subject={'source':m.OTTO_SOURCE,'planSHA256':'a'*64};message='SELIM_SELECTED_EXACT_INPUT_PROFILE_GO '+json.dumps(subject,sort_keys=True,separators=(',',':'));fname='reviewer-selected-message.txt';now=datetime.datetime.now(datetime.timezone.utc).isoformat();tool='synthetic-send-tool';command=shlex.join(['cuttle','--json','sessions','send',owner,'--file',fname]);session={'id':reviewer,'name':'reviewer'};parent={'turns':[{'role':'assistant','kind':'tool','ts':now,'tool':{'id':tool,'input':json.dumps({'command':command})}},{'role':'user','kind':'tool_result','ts':now,'tool':{'id':tool,'ok':True}}]};child={'turns':[{'role':'user','ts':now,'text':'[From Cuttle session "reviewer" · '+reviewer+']\n'+message}]}
 with tempfile.TemporaryDirectory(dir=R) as tmp:
  root=Path(tmp);idx=[0]
  def file(data):
   p=root/str(idx[0]);idx[0]+=1;raw=data if isinstance(data,bytes) else json.dumps(data).encode();p.write_bytes(raw);return {'path':str(p.relative_to(R)),'sha256':hashlib.sha256(raw).hexdigest()}
  def capture(data,method,route):return {**file(data),'method':method,'route':route,'status':200,'observedUTC':now}
  evidence={'reviewerSession':capture(session,'GET','/api/sessions/'+reviewer),'reviewerTranscript':capture(parent,'GET','/api/sessions/'+reviewer+'/transcript'),'ownerTranscript':capture(child,'GET','/api/sessions/'+owner+'/transcript')}
  evidence['sendRequest']={**file(message.encode()),'sourceFile':fname};evidence['sendResponse']={**file({'ok':True,'sessionId':owner}),'source':'SUPPORTED_CUTTLE_CLI','sourceFile':fname,'exitCode':0,'argv':['cuttle','--json','sessions','send',owner,'--file',fname],'observedUTC':now}
  artifact={**file(b'synthetic reviewer artifact'),'reviewer':reviewer,'stage':'SOURCE_GO'};record={'type':'AUTHENTICATED_DIRECT_REVIEW_CAPTURE','issuer':reviewer,'owner':owner,'operator':owner,'verdict':'SELIM_SELECTED_EXACT_INPUT_PROFILE_GO','subject':subject,'directSessionEvidence':evidence,'reviewArtifacts':[artifact]}
  live={'/api/sessions/'+reviewer:session,'/api/sessions/'+reviewer+'/transcript?limit=300':parent,'/api/sessions/'+owner:{'id':owner},'/api/sessions/'+owner+'/transcript?limit=300':child}
  class Response:
   status=200
   def __init__(self,url,data):self.url=url;self.data=json.dumps(data).encode()
   def __enter__(self):return self
   def __exit__(self,*args):pass
   def geturl(self):return self.url
   def read(self,n):return self.data
  class Opener:
   def open(self,request,timeout):
    url=request.full_url;path=url.removeprefix(os.environ['CCC_BASE_URL'].rstrip('/'));return Response(url,live[path])
  old=urllib.request.build_opener;urllib.request.build_opener=lambda *a:Opener()
  try:
   result=m.validate_authority(record,subject);assert result['toolId']==tool
   for mode in ('wrong_subject','bad_response','truncated','wrong_tool','missing_artifact','bad_pin'):
    bad=copy.deepcopy(record);saved=copy.deepcopy(live)
    if mode=='wrong_subject':bad['subject']={'source':'wrong'}
    if mode=='bad_response':bad['directSessionEvidence']['sendResponse']['exitCode']=1
    if mode=='truncated':live['/api/sessions/'+owner+'/transcript?limit=300']={'turns':[]}
    if mode=='wrong_tool':live['/api/sessions/'+reviewer+'/transcript?limit=300']['turns'][1]['tool']['id']='other'
    if mode=='missing_artifact':bad['reviewArtifacts']=[]
    if mode=='bad_pin':bad['directSessionEvidence']['sendResponse']['sha256']='0'*64
    try:m.validate_authority(bad,subject)
    except (ValueError,AssertionError):pass
    else:raise AssertionError('accepted '+mode)
    live.clear();live.update(saved)
  finally:urllib.request.build_opener=old
 print(phase,'synthetic authenticated-context authority composition and six negatives passed; no real Cuttle/provider/main')
