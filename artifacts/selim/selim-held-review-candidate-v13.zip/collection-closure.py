"""Conservative local custody/closure primitives; no provider operation."""
from pathlib import Path
import os,json,hashlib,datetime,uuid,subprocess

TERMINAL={'COMPLETED','CANCELED','ERROR'}
def check_terminal(observation,job_id,expected_command_sha256):
    if observation.get('namespace')!='Autismo-Yah' or observation.get('jobId')!=job_id or observation.get('stage') not in TERMINAL or observation.get('commandSHA256')!=expected_command_sha256:raise ValueError('terminal observation absent, unknown or wrong job')
    try:age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(observation['observedUTC'])).total_seconds()
    except (KeyError,TypeError,ValueError):raise ValueError('terminal observation time')
    if not 0<=age<=300:raise ValueError('terminal observation stale')
    return True

def create_exclusive_intent(path,job_id,plan_sha,operator,observation_path,observation_sha256,expected_command_sha256):
    if operator!='433a743a-eb04-4066-8251-791c89e978e3' or not job_id or len(plan_sha)!=64:raise ValueError('intent identity')
    observation_path=Path(observation_path);observation_raw=observation_path.read_bytes()
    if hashlib.sha256(observation_raw).hexdigest()!=observation_sha256:raise ValueError('terminal capture drift')
    check_terminal(json.loads(observation_raw),job_id,expected_command_sha256)
    data={'terminalObservationPath':str(observation_path),'terminalObservationSHA256':hashlib.sha256(observation_raw).hexdigest(),'commandSHA256':expected_command_sha256,'stage':'COLLECTION_OWNED_PENDING','jobId':job_id,'planSHA256':plan_sha,'operator':operator,'noAutomaticRetry':True}
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return data

def retain_output(case,prefix,stdout,stderr,outcome):
    if prefix not in {'terminal-inspection','collection-child'}:raise ValueError('capture prefix')
    case=Path(case);capture_id=uuid.uuid4().hex
    def store(suffix,value):
        path=case/(prefix+'-'+capture_id+suffix)
        data=value if isinstance(value,bytes) else (value or '').encode()
        fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
        return path,hashlib.sha256(data).hexdigest()
    out,out_sha=store('.stdout',stdout);err,err_sha=store('.stderr',stderr)
    meta=case/(prefix+'-'+capture_id+'.json')
    fd=os.open(meta,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump({'outcome':outcome,'stdout':out.name,'stdoutSHA256':out_sha,'stderr':err.name,'stderrSHA256':err_sha},f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return out,meta

def retain_inspection(case,stdout,stderr,outcome):
    return retain_output(case,'terminal-inspection',stdout,stderr,outcome)

def run_collection_child(case,command,run=None):
    run=run or subprocess.run
    try:
        result=run(command,capture_output=True,timeout=600)
    except subprocess.TimeoutExpired as exc:
        out,meta=retain_output(case,'collection-child',exc.stdout,exc.stderr,'TIMEOUT')
        return {'outcome':'TIMEOUT','stdout':str(out),'metadata':str(meta)}
    except OSError as exc:
        out,meta=retain_output(case,'collection-child',b'',b'',type(exc).__name__)
        return {'outcome':'START_ERROR','stdout':str(out),'metadata':str(meta)}
    out,meta=retain_output(case,'collection-child',result.stdout,result.stderr,'EXIT_'+str(result.returncode))
    return {'outcome':'EXIT_'+str(result.returncode),'stdout':str(out),'metadata':str(meta)}

def snapshot_names(case):
    case=Path(case)
    return {p.name for pattern in ('status-*.json','logs-*.txt','decoded-*') for p in case.glob(pattern)}

def inspect_decoded(decoded):
    decoded=Path(decoded)
    if decoded.is_symlink() or not decoded.is_dir():raise ValueError('decoded directory invalid')
    manifest=decoded/'manifest.json'
    if manifest.is_symlink() or not manifest.is_file():raise ValueError('missing decoded manifest')
    raw=manifest.read_bytes();document=json.loads(raw)
    if not isinstance(document,dict) or document.get('version')!=1 or type(document.get('complete')) is not bool or not isinstance(document.get('streams'),list) or not isinstance(document.get('errors'),list):raise ValueError('invalid decoded manifest')
    rows=document['streams'];seen=set();checked=[]
    for row in rows:
        if not isinstance(row,dict) or not isinstance(row.get('file'),str) or not row['file'] or Path(row['file']).name!=row['file'] or row['file'] in seen:raise ValueError('unsafe or duplicate decoded stream')
        seen.add(row['file']);f=decoded/row['file']
        if f.is_symlink() or not f.is_file():raise ValueError('missing decoded stream')
        data=f.read_bytes();digest=hashlib.sha256(data).hexdigest()
        if type(row.get('bytes')) is not int or row['bytes']!=len(data) or row.get('sha256')!=digest or type(row.get('complete')) is not bool:raise ValueError('decoded stream mismatch')
        checked.append({'file':row['file'],'bytes':len(data),'sha256':digest,'complete':row['complete']})
    if document['complete'] and (not rows or document['errors'] or not all(row['complete'] for row in checked)):raise ValueError('inconsistent decoded completeness')
    return {'path':(decoded.name+'/manifest.json'),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'state':'COMPLETE' if document['complete'] else 'INCOMPLETE','streams':checked,'scope':'postcollection file hashes only; independent raw-frame and runtime review required'}

def identify_collected(case,before,job_id):
    case=Path(case);after=snapshot_names(case);new=after-before
    statuses=sorted(x for x in new if x.startswith('status-') and x.endswith('.json'))
    if len(statuses)!=1 or sorted(case.glob('status-*.json'))[-1].name!=statuses[0]:raise ValueError('ambiguous status set')
    status_path=case/statuses[0];status=json.loads(status_path.read_bytes());stage=status.get('status',{}).get('stage')
    if status.get('id')!=job_id or stage not in TERMINAL:raise ValueError('wrong job or nonterminal collected status')
    stamp=statuses[0][7:-5];log=case/('logs-'+stamp+'.txt');decoded=case/('decoded-'+stamp)
    if log.name not in new or not log.is_file():raise ValueError('missing new matching log')
    def info(p):
        b=p.read_bytes();return {'path':p.relative_to(case).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    result={'jobId':job_id,'stage':stage,'status':info(status_path),'log':info(log),'newEntries':sorted(new),'decodedManifest':None}
    if decoded.name in new:
        try:result['decodedManifest']=inspect_decoded(decoded)
        except (OSError,ValueError,TypeError,KeyError,json.JSONDecodeError) as exc:result['decodedManifest']={'state':'INVALID','reason':type(exc).__name__,'scope':'raw log retained; independent review required'}
    return result
