"""Bounded live same-name case discovery; not a global intent registry."""
import subprocess,json
PROJECT='4cbb8d38-9dae-47c7-9736-c0020aea1c2a'

def discover(run=subprocess.run):
    cmd=['cuttle','--json','sessions','search','--project',PROJECT,'--scope','name','--limit','100','Selim']
    response=run(cmd,capture_output=True,check=True,timeout=30)
    if len(response.stdout)>8*1024*1024:raise ValueError('case search too large')
    doc=json.loads(response.stdout);rows=doc.get('results')
    if not isinstance(rows,list) or len(rows)>=100:raise ValueError('case search incomplete or capped')
    seen={}
    for row in rows:
        if not isinstance(row,dict) or row.get('projectId')!=PROJECT or not isinstance(row.get('id'),str) or not isinstance(row.get('name'),str) or 'selim' not in row['name'].lower():raise ValueError('case search malformed')
        if row['id'] in seen:raise ValueError('duplicate session')
        seen[row['id']]={'id':row['id'],'name':row['name'],'status':row.get('status')}
    return {'scope':'project session name contains Selim; no global absence claim','sessions':sorted(seen.values(),key=lambda r:r['id'])}
