"""Synthetic same-job lineage verification; no Cuttle, provider, main or collection."""
from pathlib import Path
import importlib.util,tempfile,json,hashlib,types,copy
R=Path(__file__).resolve().parent
def load(n,p):s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
g=load('provenance',R/'collector-provenance.py');contract=load('contract',R/'collection-contract.py');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();owner='433a743a-eb04-4066-8251-791c89e978e3';reviewer='d750bb0b-a1e2-42b2-833b-1598278fc31b';source='a'*40
with tempfile.TemporaryDirectory(dir=R) as t:
 root=Path(t)
 def put(name,obj):p=root/name;p.write_text(json.dumps(obj));return p
 plan={'source':source,'name':'synthetic','payloadFile':'payload','executionHold':None,'ownerSelection':{'owner':owner},'expectedInputsRef':{'sha256':'m'*64,'count':4893},'tests':['test.test.cjs']};p=put('plan.json',plan);ps=sha(p)
 selection={'action':'SELECT_ONCE','attempts':1,'owner':owner,'source':source,'planSHA256':ps,'manifestSHA256':'m'*64,'count':4893,'tests':plan['tests']};sel=put('selection.json',selection);bindings=put('bindings.json',{'synthetic':True});subject={'collectionContractSHA256':sha(R/'collection-contract.py'),'callerSHA256':'d'*64};authority=put('authority.json',{'subject':subject});receipt={'stage':'SELECTED_REFERENCE_PRESTART_CHECKED_NO_JOB_API','noJobAPI':True,'source':source,'planSHA256':ps,'selectedPlanPath':str(p),'selectionPath':str(sel),'selectionSHA256':sha(sel),'bindingsPath':str(bindings),'bindingsSHA256':sha(bindings),'prestartCallerSHA256':'d'*64,'authoritySubject':subject,'authorityPath':str(authority),'authoritySHA256':sha(authority),'programSHA256':'e'*64};pre=put('prestart.json',receipt);cmd=['node','-e','synthetic'];submission={'stage':'SUBMITTED','namespace':'Autismo-Yah','plan':plan,'request':{'command':cmd},'job':{'id':'job','command':cmd}};sub=put('submission.json',submission);binding={'jobId':'job','prestartReceiptSHA256':sha(pre),'prestartReceiptPath':str(pre),'planSHA256':ps,'programSHA256':'e'*64,'renderedEqualsSubmittedEqualsReturned':True};jb=put('binding.json',binding)
 def pair(a,b,c):
  if a!=b or a!=c:raise ValueError('subject')
 phase=types.SimpleNamespace(OWNER=owner,REVIEWER=reviewer,OPERATOR=owner,validate_binding_bundle=lambda *x:None,build_authority_subject=lambda *x:subject,verify_subject_pair=pair,load_guard_component=lambda *x:contract)
 review=types.SimpleNamespace(validate=lambda *a,**kw:{'synthetic':True});args=[R,phase,p,ps,sub,sha(sub),pre,sha(pre),jb,sha(jb),None,None,review]
 assert g.verify(*args)['jobId']=='job'
 for index in (3,5,7,9):
  bad=list(args);bad[index]='0'*64
  try:g.verify(*bad)
  except ValueError:pass
  else:raise AssertionError('bad pin accepted')
print('synthetic selected/prestart/submission/job-binding lineage and four changed-pin negatives; no Cuttle/provider/main')
