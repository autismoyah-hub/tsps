"""Verify same-job file/selected-review lineage; does not itself prove provider state."""
from pathlib import Path
import hashlib,json

def verify(workspace,phase,plan_path,plan_sha,submission_path,submission_sha,prestart_path,prestart_sha,job_binding_path,job_binding_sha,producer,validator,review):
    root=Path(workspace).resolve()
    def bounded(path,digest):
        path=Path(path).resolve(strict=True)
        if not path.is_relative_to(root) or not path.is_file():raise ValueError('PROVENANCE_PATH')
        raw=path.read_bytes()
        if len(raw)>32*1024*1024 or hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('PROVENANCE_HASH')
        return raw
    plan_path=Path(plan_path).resolve();plan_raw=bounded(plan_path,plan_sha);plan=json.loads(plan_raw)
    if plan.get('executionHold') or not isinstance(plan.get('ownerSelection'),dict) or plan['ownerSelection'].get('owner')!=phase.OWNER:raise ValueError('PLAN_NOT_SELECTED')
    receipt=json.loads(bounded(prestart_path,prestart_sha));submission=json.loads(bounded(submission_path,submission_sha));job_binding=json.loads(bounded(job_binding_path,job_binding_sha))
    if receipt.get('stage')!='SELECTED_REFERENCE_PRESTART_CHECKED_NO_JOB_API' or receipt.get('noJobAPI') is not True or receipt.get('source')!=plan['source'] or receipt.get('planSHA256')!=plan_sha or Path(receipt['selectedPlanPath']).resolve()!=plan_path:raise ValueError('PRESTART_IDENTITY')
    if job_binding.get('prestartReceiptSHA256')!=prestart_sha or Path(job_binding['prestartReceiptPath']).resolve()!=Path(prestart_path).resolve() or job_binding.get('planSHA256')!=plan_sha or job_binding.get('programSHA256')!=receipt.get('programSHA256') or job_binding.get('renderedEqualsSubmittedEqualsReturned') is not True:raise ValueError('JOB_BINDING')
    selection=json.loads(bounded(receipt['selectionPath'],receipt['selectionSHA256']));bindings=json.loads(bounded(receipt['bindingsPath'],receipt['bindingsSHA256']))
    if selection.get('action')!='SELECT_ONCE' or selection.get('attempts')!=1 or selection.get('owner')!=phase.OWNER or selection.get('source')!=plan['source'] or selection.get('planSHA256')!=plan_sha or selection.get('manifestSHA256')!=plan['expectedInputsRef']['sha256'] or selection.get('count')!=plan['expectedInputsRef']['count'] or selection.get('tests')!=plan['tests']:raise ValueError('SELECTION_IDENTITY')
    phase.validate_binding_bundle(bindings,plan,plan_path.parent)
    expected=phase.build_authority_subject(plan,plan_sha,bindings,receipt['bindingsSHA256'],receipt['selectionSHA256'],receipt['prestartCallerSHA256'])
    authority=json.loads(bounded(receipt['authorityPath'],receipt['authoritySHA256']))
    phase.verify_subject_pair(expected,receipt['authoritySubject'],authority['subject'])
    # Original reviewer capture is historical after a running job; re-query live transcripts and require exact original bytes and reviewer capture.
    authority_check=review.validate(authority,expected,phase.REVIEWER,phase.OWNER,phase.OPERATOR,'SELIM_SELECTED_EXACT_INPUT_PROFILE_GO',root,producer,validator,True,historical=True)
    contract=phase.load_guard_component('collection-contract.py',expected['collectionContractSHA256'])
    job_id=contract.validate_collection(submission,receipt,job_binding,plan,plan_raw,phase.OWNER)
    return {'plan':plan,'receipt':receipt,'submission':submission,'jobBinding':job_binding,'selection':selection,'authorityCheck':authority_check,'jobId':job_id}
