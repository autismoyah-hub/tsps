"""Validate actual direct Cuttle capture against fresh authenticated context; no provider action."""
from pathlib import Path
import datetime,json,re,hashlib

def validate(record,subject,sender,owner,operator,marker,workspace,producer,validator,require_artifacts,historical=False):
    if (record.get('type')!='AUTHENTICATED_DIRECT_REVIEW_CAPTURE' or record.get('issuer')!=sender
        or record.get('owner')!=owner or record.get('operator')!=operator
        or record.get('verdict')!=marker or record.get('subject')!=subject):raise ValueError('REVIEW_IDENTITY_OR_SUBJECT')
    live=producer.authentic_direct_context(sender);evidence=record['directSessionEvidence'];workspace=Path(workspace).resolve()
    def timestamp(value):
        parsed=datetime.datetime.fromisoformat(value.replace('Z','+00:00'))
        if parsed.utcoffset() is None:raise ValueError('CAPTURE_TIME_ZONE')
        return parsed
    def captured_file(row):
        path=(workspace/row['path']).resolve(strict=True)
        if not path.is_relative_to(workspace) or not path.is_file():raise ValueError('CAPTURE_PATH')
        import hashlib
        raw=path.read_bytes()
        if len(raw)>16*1024*1024 or hashlib.sha256(raw).hexdigest()!=row['sha256']:raise ValueError('CAPTURE_IDENTITY')
        return raw
    def observation(row):
        observed=timestamp(row['observedUTC']);age=(datetime.datetime.now(datetime.timezone.utc)-observed).total_seconds()
        if age<0 or (not historical and age>300):raise ValueError('CAPTURE_OBSERVATION_STALE_OR_FUTURE')
        return observed
    def capture(key,method,route):
        row=evidence[key]
        if row.get('method')!=method or row.get('route')!=route or row.get('status')!=200:raise ValueError('CAPTURE_ROUTE:'+key)
        observation(row);return json.loads(captured_file(row))
    session=capture('reviewerSession','GET','/api/sessions/'+sender)
    if session.get('id')!=sender or not isinstance(session.get('name'),str) or not session['name']:raise ValueError('REVIEWER_SESSION')
    if live['reviewerSession'].get('id')!=sender or live['reviewerSession'].get('name')!=session['name'] or live['ownerSession'].get('id')!=owner:raise ValueError('LIVE_SESSION_IDENTITY')
    outgoing=capture('reviewerTranscript','GET','/api/sessions/'+sender+'/transcript')
    incoming=capture('ownerTranscript','GET','/api/sessions/'+owner+'/transcript')
    message=marker+' '+json.dumps(subject,sort_keys=True,separators=(',',':'))
    sent=evidence['sendResponse'];sent_at=observation(sent);filename=sent.get('sourceFile')
    if sent.get('source')!='SUPPORTED_CUTTLE_CLI' or not isinstance(filename,str) or not filename or type(sent.get('exitCode')) is not int or sent['exitCode']!=0 or sent.get('argv')!=['cuttle','--json','sessions','send',owner,'--file',filename]:raise ValueError('CLI_SEND_COMMAND')
    request=evidence['sendRequest']
    if request.get('sourceFile')!=filename or captured_file(request)!=message.encode('utf-8'):raise ValueError('CLI_WIRE_BYTES')
    response=json.loads(captured_file(sent))
    if response!={'ok':True,'sessionId':owner}:raise ValueError('SEND_RESULT')
    captured=validator.correlate_direct_message(sender,owner,outgoing,incoming,message,filename,session['name'])
    current=validator.correlate_direct_message(sender,owner,live['reviewerTranscript'],live['ownerTranscript'],message,filename,session['name'])
    if captured!=current:raise ValueError('LIVE_CAPTURE_TURN_MISMATCH')
    if not (captured['sent']<=sent_at<=timestamp(evidence['ownerTranscript']['observedUTC']) and captured['received']<=timestamp(evidence['ownerTranscript']['observedUTC']) and captured['result']<=timestamp(evidence['reviewerTranscript']['observedUTC'])):raise ValueError('DIRECT_TIMES')
    prefix=marker.rsplit('_',1)[0]+'_'
    for turn in outgoing.get('turns',[])+incoming.get('turns',[])+live['reviewerTranscript'].get('turns',[])+live['ownerTranscript'].get('turns',[]):
        text=turn.get('text','')
        if not isinstance(text,str) or prefix not in text:continue
        found=re.search(re.escape(prefix)+r'([A-Z_]+) (\{[^\n]*\})',text)
        if found:
            try:other=json.loads(found.group(2))
            except ValueError:
                if subject.get('planSHA256','') and subject['planSHA256'] in text:raise ValueError('AMBIGUOUS_VERDICT')
                continue
            if other==subject and prefix+found.group(1)!=marker:raise ValueError('CONFLICTING_EXACT_SUBJECT_VERDICT')
        elif subject.get('planSHA256','') and subject['planSHA256'] in text:raise ValueError('AMBIGUOUS_VERDICT')
    # Actual sender-owned capture and source identity require independent review; this is not a signature.
    artifacts=record.get('reviewArtifacts')
    if require_artifacts and (not isinstance(artifacts,list) or not artifacts):raise ValueError('REVIEW_ARTIFACTS')
    for row in artifacts or []:
        if row.get('reviewer')!=sender or row.get('stage') not in ('SOURCE_GO','EXACT_INPUT_PROFILE_GO','CUSTODY_DISPOSITION'):raise ValueError('REVIEW_ARTIFACT_IDENTITY')
        captured_file(row)
    live_hashes={key:hashlib.sha256(json.dumps(live[key],sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest() for key in ('reviewerSession','reviewerTranscript','ownerSession','ownerTranscript')}
    return {'sender':sender,'toolId':captured['toolId'],'sendResponseSHA256':sent['sha256'],'sentUTC':captured['sent'].isoformat(),'subject':subject,'liveCanonicalDocumentSHA256':live_hashes}

