"""Synthetic collector custody evidence; no real Cuttle, provider or collection."""
from pathlib import Path
import importlib.util,tempfile,json,hashlib,datetime,types,copy
R=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('guard',R/'collector-custody.py');guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
owner='433a743a-eb04-4066-8251-791c89e978e3';plan={'source':'a'*40,'name':'synthetic'};ps='b'*64;ss='c'*64;job='synthetic-job';now=datetime.datetime.now(datetime.timezone.utc);record={'type':'BOUNDED_SAME_JOB_COLLECTOR_RECONCILIATION','operator':owner,'source':plan['source'],'name':plan['name'],'planSHA256':ps,'selectionSHA256':ss,'jobId':job,'checkedUTC':now.isoformat(),'knownCaseSessions':[owner],'peerEvidence':{}}
with tempfile.TemporaryDirectory() as t:
 root=Path(t);submission=root/'submission.json';submission.write_text('{}');runtime=root/'mapref-runtime-custody.json';runtime.write_text(json.dumps({'jobId':job,'planSHA256':ps,'owner':owner,'stage':'ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED'}));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();local={'errors':[],'skippedSymlinkDirectories':[],'found':[{'path':str(submission),'sha256':sha(submission)},{'path':str(runtime),'sha256':sha(runtime)}]};discovery=types.SimpleNamespace(discover=lambda:{'sessions':[{'id':owner,'status':'running'}]});scanner=types.SimpleNamespace(scan=lambda roots:local)
 assert guard.validate(record,plan,ps,ss,job,owner,root,submission,None,None,None,discovery,scanner)['localScan']==local
 for mode in ('stale','wrong_job','missing_runtime','foreign_intent','bad_digest','unknown_case'):
  bad=copy.deepcopy(record);saved=copy.deepcopy(local);disc=discovery
  if mode=='stale':bad['checkedUTC']=(now-datetime.timedelta(seconds=301)).isoformat()
  if mode=='wrong_job':bad['jobId']='wrong'
  if mode=='missing_runtime':local['found']=local['found'][:1]
  if mode=='foreign_intent':local['found'].append({'path':str(root/'collection-custody.json'),'sha256':'0'*64})
  if mode=='bad_digest':local['found'][0]['sha256']='0'*64
  if mode=='unknown_case':disc=types.SimpleNamespace(discover=lambda:{'sessions':[{'id':owner,'status':'running'},{'id':'unaccounted','status':'running'}]})
  try:guard.validate(bad,plan,ps,ss,job,owner,root,submission,None,None,None,disc,scanner)
  except (ValueError,FileNotFoundError):pass
  else:raise AssertionError('accepted '+mode)
  local.clear();local.update(saved)
print('synthetic bounded collector custody positive and six stale/conflict/identity negatives; no Cuttle/provider/main')
