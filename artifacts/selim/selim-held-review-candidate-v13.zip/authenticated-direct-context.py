"""Authenticated read-only Cuttle context adapted from reviewed Otto v4 capture producer."""
from pathlib import Path
import os,json,re,urllib.request
REVIEWER='d750bb0b-a1e2-42b2-833b-1598278fc31b'
OWNER='433a743a-eb04-4066-8251-791c89e978e3'

def authentic_direct_context(reviewer=REVIEWER):
    if not isinstance(reviewer,str) or not re.fullmatch(r'[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}',reviewer):raise ValueError('INVALID_REVIEWER_ID')
    base=os.environ.get('CCC_BASE_URL','').rstrip('/')
    token=os.environ.get('CCC_TOKEN') or os.environ.get('CCC_PAT')
    if not token and os.environ.get('CCC_TOKEN_FILE'):token=Path(os.environ['CCC_TOKEN_FILE']).read_text().strip()
    if not base or not token:raise ValueError('OWN_CUTTLE_AUTH_REQUIRED')
    headers=({'Authorization':'Bearer '+token} if token.startswith('ccc_pat_') else {'X-CCC-Control-Token':token})
    class RefuseRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self,*args,**kwargs):raise ValueError('CUTTLE_CAPTURE_REDIRECT')
    opener=urllib.request.build_opener(RefuseRedirect())
    routes={'reviewerSession':'/api/sessions/'+reviewer,'reviewerTranscript':'/api/sessions/'+reviewer+'/transcript?limit=300','ownerSession':'/api/sessions/'+OWNER,'ownerTranscript':'/api/sessions/'+OWNER+'/transcript?limit=300'}
    result={}
    for key,route in routes.items():
        try:
            with opener.open(urllib.request.Request(base+route,headers=headers),timeout=30) as response:
                raw=response.read(16*1024*1024+1)
                if response.status!=200 or len(raw)>16*1024*1024 or response.geturl()!=base+route:raise ValueError('CUTTLE_CAPTURE_RESPONSE')
            value=json.loads(raw)
            if not isinstance(value,dict):raise ValueError('CUTTLE_CAPTURE_SHAPE')
            result[key]=value
        except Exception as exc:raise ValueError('CUTTLE_CAPTURE_FAILED:'+type(exc).__name__) from None
    return result
