"""Future auth004 child: inspect one already admitted same job, no logs or writes."""
import argparse,json,datetime,hashlib
from pathlib import Path

def inspect(api,namespace,job_id,expected_command_sha256):
    job=api.inspect_job(job_id=job_id,namespace=namespace)
    stage=getattr(getattr(job,'status',None),'stage',None);stage=getattr(stage,'value',stage)
    owner=getattr(getattr(job,'owner',None),'name',None)
    if getattr(job,'id',None)!=job_id or owner!=namespace:raise ValueError('job identity mismatch')
    if stage not in {'COMPLETED','CANCELED','ERROR','DELETED','SCHEDULING','RUNNING'}:raise ValueError('unknown stage')
    command=getattr(job,'command',None)
    if not isinstance(command,list) or not command or not all(isinstance(x,str) for x in command):raise ValueError('actual command unavailable')
    digest=hashlib.sha256(json.dumps(command,ensure_ascii=True,separators=(',',':')).encode()).hexdigest()
    if digest!=expected_command_sha256:raise ValueError('actual command mismatch')
    return {'namespace':namespace,'jobId':job_id,'stage':stage,'commandSHA256':digest,'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}

def main():
    p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--job-id',required=True);p.add_argument('--command-sha256',required=True);a=p.parse_args()
    # Exact plan data is supplied by the verified auth child snapshot mechanism.
    json.loads(a.plan.read_bytes())
    from huggingface_hub import HfApi
    print(json.dumps(inspect(HfApi(),'Autismo-Yah',a.job_id,a.command_sha256)))

if __name__=='__main__':main()
