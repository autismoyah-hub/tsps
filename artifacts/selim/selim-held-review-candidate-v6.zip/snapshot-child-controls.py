"""Actual OS child controls on private synthetic files; no held main/provider."""
import pathlib,tempfile,py_compile,os,sys,hashlib,importlib.util,subprocess
R=pathlib.Path(__file__).resolve().parent

def load(name,file):
 spec=importlib.util.spec_from_file_location(name,file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
snap=load('snapshot_child',R/'snapshot-child.py');helper=load('auth_helper',R/'authenticated-child-snapshot-command.py');sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();python=str(pathlib.Path(sys.executable).resolve())
with tempfile.TemporaryDirectory() as t:
 root=pathlib.Path(t);sdk=root/'sdk';sdk.mkdir();mod=sdk/'sentinel.py';bad="VALUE='BAD' \n";good="VALUE='GOOD'\n";assert len(bad)==len(good)
 mod.write_text(bad);stamp=mod.stat().st_mtime_ns;py_compile.compile(str(mod),doraise=True);mod.write_text(good);os.utime(mod,ns=(stamp,stamp));pyc=list((sdk/'__pycache__').iterdir());assert len(pyc)==1;old=pyc[0].read_bytes()
 pilot=root/'fake-pilot.py';pilot.write_text("import sentinel,sys,json\nprint(json.dumps({'value':sentinel.VALUE,'argv':sys.argv[1:],'file':__file__,'name':__name__}))\n");plan=root/'plan.json';plan.write_text('{}');pilot_hash=sha(pilot)
 cmd=snap.preview_command(python,sha(python),pilot,pilot_hash,plan,sdk);assert cmd[1:6]==['-I','-B','-X','pycache_prefix=/dev/null','-c'];pilot.write_text("raise RuntimeError('mutated pilot executed')\n")
 result=subprocess.run(cmd,capture_output=True,text=True,check=True);import json;x=json.loads(result.stdout);assert x['value']=='GOOD' and x['argv']==['--plan',str(plan)] and x['file']==str(pilot) and x['name']=='__main__' and pyc[0].read_bytes()==old
 try:snap.preview_command(python,'0'*64,pilot,sha(pilot),plan,sdk)
 except ValueError:pass
 else:raise AssertionError('interpreter hash')
 access=root/'fake-access.py';access.write_text("import sentinel\nprint('AUTH-'+sentinel.VALUE)\n");access_hash=sha(access);dummy=root/'dummy-entry.py';dummy.write_text('pass\n');base=helper.authenticated_pilot_command(python,access,access_hash,dummy,sha(dummy),plan,sdk);auth=snap.protect_auth_command(base,helper.CHILD_BOOTSTRAP);assert auth[1:6]==['-I','-B','-X','pycache_prefix=/dev/null','-c'];access.write_text("raise RuntimeError('mutated access executed')\n")
 response=subprocess.run(auth,capture_output=True,text=True,check=True);assert response.stdout.strip()=='AUTH-GOOD' and pyc[0].read_bytes()==old
 try:snap.protect_auth_command([python,'-c','bad'],helper.CHILD_BOOTSTRAP)
 except ValueError:pass
 else:raise AssertionError('changed bootstrap')
 orphan=sdk/'orphan.py';orphan.write_text("VALUE='BYTECODE_ONLY'\n");py_compile.compile(str(orphan),cfile=str(sdk/'orphan.pyc'),doraise=True);orphan.unlink()
 orphan_pilot=root/'orphan-pilot.py';orphan_pilot.write_text('import orphan\n');orphan_cmd=snap.preview_command(python,sha(python),orphan_pilot,sha(orphan_pilot),plan,sdk);orphan_run=subprocess.run(orphan_cmd,capture_output=True,text=True);assert orphan_run.returncode!=0 and 'sourceless bytecode imports disabled' in orphan_run.stderr
 print('actual synthetic OS children: snapshots survive pathname mutation; malicious fresh pyc ignored; sourceless import refused; argv/file/name correct; no provider or held main')
