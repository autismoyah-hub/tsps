"""Construct verified script-snapshot child commands; no job or provider action."""
from pathlib import Path
import hashlib,base64

NO_BYTECODE = '''import sys,importlib.machinery
sys.dont_write_bytecode=True
def _source_only_get_code(self,fullname):
 path=self.get_filename(fullname)
 return self.source_to_code(self.get_data(path),path)
def _deny_sourceless(self,fullname):
 raise ImportError('sourceless bytecode imports disabled')
importlib.machinery.SourceFileLoader.get_code=_source_only_get_code
importlib.machinery.SourcelessFileLoader.get_code=_deny_sourceless
'''
PREVIEW = '''import sys,base64,hashlib,types
from pathlib import Path
snapshot=base64.b64decode(sys.argv.pop(1),validate=True)
digest=sys.argv.pop(1)
filename=sys.argv.pop(1)
sdk_target=sys.argv.pop(1)
if hashlib.sha256(snapshot).hexdigest()!=digest:raise SystemExit(1)
if sdk_target:sys.path.insert(0,sdk_target)
sys.path.insert(0,str(Path(filename).parent))
sys.argv[0]=filename
module=types.ModuleType('__main__')
module.__dict__.update(__file__=filename,__name__='__main__',__package__='',__spec__=None,__cached__=None)
sys.modules['__main__']=module
exec(compile(snapshot,filename,'exec'),module.__dict__)
'''

def preview_command(python,python_sha256,pilot_file,pilot_sha256,plan_path,sdk_target):
    executable=Path(python).resolve();raw=executable.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=python_sha256:raise ValueError('interpreter pin')
    pilot_file=Path(pilot_file).resolve();snapshot=pilot_file.read_bytes()
    if hashlib.sha256(snapshot).hexdigest()!=pilot_sha256:raise ValueError('pilot pin')
    cmd=[str(executable),'-I','-B','-X','pycache_prefix=/dev/null','-c',NO_BYTECODE+PREVIEW,base64.b64encode(snapshot).decode(),pilot_sha256,str(pilot_file),str(Path(sdk_target).resolve()),'--plan',str(Path(plan_path).resolve())]
    if any('\0' in a or len(a.encode())+1>=131072 for a in cmd):raise ValueError('argv bound')
    return cmd

def protect_auth_command(command,expected_bootstrap):
    if len(command)<3 or command[1]!='-c' or command[2]!=expected_bootstrap:raise ValueError('unexpected auth helper command')
    cmd=[command[0],'-I','-B','-X','pycache_prefix=/dev/null','-c',NO_BYTECODE+expected_bootstrap,*command[3:]]
    if any('\0' in a or len(a.encode())+1>=131072 for a in cmd):raise ValueError('argv bound')
    return cmd
