"""Pure validation of capture CONTENT only; these functions do not authenticate transport.
Live Cuttle/provider acquisition must be bound separately; callers remain unconditionally HELD.
"""
from datetime import datetime, timezone
import json

PROJECT='tsps'; NAMESPACE='Autismo-Yah'

def validate_review_content(expected_subject, parent_identity, parent_transcript, owner_identity, owner_transcript, send_response, nonce):
    if not isinstance(nonce,str) or len(nonce)<32: raise ValueError('bad nonce')
    parent='d750bb0b-a1e2-42b2-833b-1598278fc31b';owner='433a743a-eb04-4066-8251-791c89e978e3'
    if parent_identity.get('id')!=parent or owner_identity.get('id')!=owner: raise ValueError('identity')
    # This checks observed response shape, not origin or native signature.
    if send_response != {'ok':True,'sessionId':owner}: raise ValueError('send response')
    expected={'nonce':nonce,'verdict':'EXACT_INPUT_PROFILE_GO','subject':expected_subject}
    def payload(text):
        try:return json.loads(text)
        except (TypeError,ValueError):return None
    parent_turns=parent_transcript.get('turns');owner_turns=owner_transcript.get('turns')
    if not isinstance(parent_turns,list) or not isinstance(owner_turns,list):raise ValueError('transcript')
    # A sender-authored exact verdict must occur in the fetched sender transcript.
    sent=[t for t in parent_turns if t.get('role')=='assistant' and payload(t.get('text'))==expected]
    received=[]
    for t in owner_turns:
        text=t.get('text','');head,sep,body=text.partition('\n') if isinstance(text,str) else ('','','')
        if t.get('role')=='user' and sep and head.startswith('[From Cuttle session "') and head.endswith(' · '+parent+']') and payload(body)==expected and isinstance(t.get('ts'),str):received.append(t)
    if len(sent)!=1 or len(received)!=1:raise ValueError('verdict/transcript mismatch')
    return True

def validate_provider_content(capture,source,name,now=None):
    now=now or datetime.now(timezone.utc)
    if capture.get('namespace')!=NAMESPACE or capture.get('project')!=PROJECT or capture.get('complete') is not True:raise ValueError('scope or incomplete listing')
    try: age=(now-datetime.fromisoformat(capture['finishedUTC'])).total_seconds()
    except (KeyError,ValueError,TypeError):raise ValueError('bad timestamp')
    if not 0<=age<=300:raise ValueError('stale listing')
    queries=capture.get('queries'); expected={'project':{'project':PROJECT},'source':{'project':PROJECT,'source':source},'name':{'project':PROJECT,'name':name}}
    if not isinstance(queries,dict) or set(queries)!=set(expected):raise ValueError('query set')
    def parse(key):
        q=queries[key]
        if not isinstance(q,dict) or q.get('labels')!=expected[key] or q.get('complete') is not True or not isinstance(q.get('rows'),list):raise ValueError('partial query')
        result={}
        for row in q['rows']:
            if not isinstance(row,dict) or not isinstance(row.get('id'),str) or not row['id'] or row['id'] in result:raise ValueError('row identity')
            labels=row.get('labels');stage=row.get('stage');owner=row.get('owner')
            if not isinstance(labels,dict) or any(not isinstance(labels.get(k),str) or not labels[k] for k in ('project','source','name')) or labels['project']!=PROJECT or not isinstance(stage,str) or not stage or owner!=NAMESPACE:raise ValueError('partial row')
            result[row['id']]=row
        return result
    project,by_source,by_name=(parse(k) for k in ('project','source','name'))
    exact_source={k:v for k,v in project.items() if v['labels']['source']==source};exact_name={k:v for k,v in project.items() if v['labels']['name']==name}
    if by_source!=exact_source or by_name!=exact_name:raise ValueError('listing mismatch')
    if by_source or by_name:raise ValueError('existing source/name job; reconcile custody')
    return True
