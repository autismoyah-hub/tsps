"""HELD author-owned same-job collection candidate; no automatic collection."""
from pathlib import Path
import hashlib,importlib.util,json,sys,subprocess
ROOT=Path(__file__).resolve().parent
EXPECTED_COMPONENTS={'collectionContract': 'f38306f3da67d45e7469876abbded1c6c144d3b1656dbf3e455682ec47736394', 'sdkVerifier': 'e47594c5e8c9858111312b194c3659ba98d927672968eba56e44cccedaa717be', 'sdkManifest': '8d40023673b396fc7f507e3ff39fdcef1f7e416aa649ece34c92949d56b297d6', 'authChild': '00ff45d75be1eae3bc8f04995cfb8bcbe2bc5adc28c1162b843cfe88c87024f9', 'snapshotChild': '1aa6b38fa85b95993851f45a524fec2fd8aebb0e192e050fbd8bfd8e899dba11', 'authAccess': 'fab4bc92dc8601143ce61e910f8121774c22a0d19be6d2617bba9449f7131326', 'pilot': '2d7c5e44bb37f3043311962f8c05deee90e83ab6fa5ee5e3b499df238ed98200', 'payload': '220ef3554ec1bf8951c22dc8e50b849feeeaaa5b0b0b06f664ea7b393cb1dde4', 'inspector': '95b40fe612f95e29b5b74f4152782cb4c2a7e3e99747f7c1d3ccd0466f61709e', 'closure': '32d592ade1cc447d3300b6ffa306d313143052d138c088d971b5ca7ee58fa93b', 'frameTransport': 'f53689d4f2389af93ad8f6a43fe0de94caf8dcaabde3eacbd13b1c957b129a76', 'retainResult': 'bdcb7f104ebfa8c26d2aa68c1dd31cf7780f12174eb92d3e98ffb928797a9071'}
EXECUTOR_BINDING_SHA256='b38e5180e2e8618cabf56086e6a54a44fd21f6c7130ac7b5c73cbd47b31da2c9'

def pinned_module(path,digest):
    raw=Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('source pin')
    import types
    module=types.ModuleType('selim_collection_component');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module

def prepare_command(plan_path,plan_sha,submission_path,submission_sha,submission,prestart,binding,operator,executor,component_hashes,terminal_observation):
    if component_hashes!=EXPECTED_COMPONENTS:raise ValueError('unreviewed collector components')
    executor_raw=(ROOT/'executor-binding.json').read_bytes()
    if hashlib.sha256(executor_raw).hexdigest()!=EXECUTOR_BINDING_SHA256 or json.loads(executor_raw)!=executor:raise ValueError('executor binding')
    if operator!='433a743a-eb04-4066-8251-791c89e978e3' or executor['executor']!=operator:raise ValueError('sole collector')
    plan_path=Path(plan_path).resolve();raw=plan_path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=plan_sha:raise ValueError('selected plan')
    plan=json.loads(raw)
    submission_path=Path(submission_path).resolve();submission_raw=submission_path.read_bytes()
    if submission_path!=plan_path.parent/'submission.json' or hashlib.sha256(submission_raw).hexdigest()!=submission_sha or json.loads(submission_raw)!=submission:raise ValueError('submission bytes')
    if plan.get('executionHold') or not isinstance(plan.get('ownerSelection'),dict) or plan['ownerSelection'].get('owner')!=operator:raise ValueError('not selected')
    contract=pinned_module(ROOT/'collection-contract.py',component_hashes['collectionContract'])
    job=contract.validate_collection(submission,prestart,binding,plan,raw,operator)
    job_command=submission['request']['command']
    if not isinstance(job_command,list) or not job_command or not all(isinstance(x,str) for x in job_command):raise ValueError('reviewed command unavailable')
    command_sha=hashlib.sha256(json.dumps(job_command,ensure_ascii=True,separators=(',',':')).encode()).hexdigest()
    sdk=pinned_module(ROOT/'sdk-verify.py',component_hashes['sdkVerifier']);manifest=(ROOT/'sdk-file-manifest.json').read_bytes()
    if hashlib.sha256(manifest).hexdigest()!=component_hashes['sdkManifest']:raise ValueError('SDK manifest')
    sdk.verify(manifest,executor['sdkTarget'])
    if hashlib.sha256(Path(executor['python']).read_bytes()).hexdigest()!=executor['pythonSha256']:raise ValueError('interpreter')
    helper=pinned_module(ROOT/'authenticated-child-snapshot-command.py',component_hashes['authChild'])
    safe=pinned_module(ROOT/'snapshot-child.py',component_hashes['snapshotChild'])
    pilot=ROOT/'pilot.py';access=ROOT/'hf-project-access-v4.py';payload=ROOT/'native-payload-mapref-candidate.cjs'
    probe=helper.authenticated_pilot_command(executor['python'],access,component_hashes['authAccess'],ROOT/'inspect-selim-job.py',component_hashes['inspector'],plan_path,executor['sdkTarget'])
    probe=safe.protect_auth_command(probe,helper.CHILD_BOOTSTRAP,plan_path,plan_sha,payload,component_hashes['payload'])+['--job-id',job,'--command-sha256',command_sha]
    if terminal_observation is None:return {'jobId':job,'inspectionCommand':probe,'command':None}
    closure=pinned_module(ROOT/'collection-closure.py',component_hashes['closure'])
    closure.check_terminal(terminal_observation,job,command_sha)
    cmd=helper.authenticated_pilot_command(executor['python'],access,component_hashes['authAccess'],pilot,component_hashes['pilot'],plan_path,executor['sdkTarget'])
    cmd=safe.protect_auth_command(cmd,helper.CHILD_BOOTSTRAP,plan_path,plan_sha,payload,component_hashes['payload'],[(submission_path,submission_sha),(ROOT/'frame_transport.py',component_hashes['frameTransport'])])+['--collect']
    return {'jobId':job,'inspectionCommand':probe,'command':cmd}

def execute_collection_held(plan_path,plan_sha,submission_path,submission_sha,submission,prestart,binding,operator,executor,component_hashes):
    # Intentionally unreachable until genuine direct provenance and same-job custody are independently bound.
    raise RuntimeError('HELD: authenticated provenance and exclusive existing-job custody are not established')
    prepared=prepare_command(plan_path,plan_sha,submission_path,submission_sha,submission,prestart,binding,operator,executor,component_hashes,None)
    case=Path(plan_path).resolve().parent;closure=pinned_module(ROOT/'collection-closure.py',component_hashes['closure'])
    # Authenticated terminal inspection occurs before consuming the one-shot collection intent.
    try:
        inspection=subprocess.run(prepared['inspectionCommand'],capture_output=True,timeout=120)
    except subprocess.TimeoutExpired as exc:
        closure.retain_inspection(case,exc.stdout,exc.stderr,'TIMEOUT')
        raise RuntimeError('inspection timed out: reconcile; collection intent not consumed') from None
    except OSError as exc:
        closure.retain_inspection(case,b'',b'',type(exc).__name__)
        raise RuntimeError('inspection failed to start: reconcile; collection intent not consumed') from None
    observation_path,_=closure.retain_inspection(case,inspection.stdout,inspection.stderr,'EXIT_'+str(inspection.returncode))
    if inspection.returncode:raise RuntimeError('inspection failed: reconcile; collection intent not consumed')
    terminal=json.loads(inspection.stdout)
    command_sha=hashlib.sha256(json.dumps(submission['request']['command'],ensure_ascii=True,separators=(',',':')).encode()).hexdigest()
    closure.check_terminal(terminal,prepared['jobId'],command_sha)
    selected=prepare_command(plan_path,plan_sha,submission_path,submission_sha,submission,prestart,binding,operator,executor,component_hashes,terminal)
    closure.create_exclusive_intent(case/'collection-custody.json',prepared['jobId'],plan_sha,operator,observation_path,hashlib.sha256(inspection.stdout).hexdigest(),command_sha)
    before=closure.snapshot_names(case)
    child=closure.run_collection_child(case,selected['command'])
    if child['outcome']!='EXIT_0':raise RuntimeError('collection failed or ambiguous: retain custody and reconcile')
    retained=closure.identify_collected(case,before,prepared['jobId'])
    retained['classification']='NOT_REVIEWED';retained['collector']=operator;retained['childCapture']=child
    with (case/'collection-closure.json').open('x') as f:json.dump(retained,f,indent=2);f.write('\n')
    return retained

def main():
    raise RuntimeError('HELD: actual reviewed same-job provenance and collector authority are not bound')

if __name__=='__main__':main()
