"""Actual OS child controls on private synthetic files; no held main/provider."""
import pathlib,tempfile,py_compile,os,sys,hashlib,importlib.util,subprocess,json
R=pathlib.Path(__file__).resolve().parent

def load(name,file):
 spec=importlib.util.spec_from_file_location(name,file);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
snap=load('snapshot_child',R/'snapshot-child.py');helper=load('auth_helper',R/'authenticated-child-snapshot-command.py');sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();python=str(pathlib.Path(sys.executable).resolve())
with tempfile.TemporaryDirectory() as t:
 root=pathlib.Path(t);sdk=root/'sdk';sdk.mkdir();mod=sdk/'sentinel.py';bad="VALUE='BAD' \n";good="VALUE='GOOD'\n";assert len(bad)==len(good)
 mod.write_text(bad);stamp=mod.stat().st_mtime_ns;py_compile.compile(str(mod),doraise=True);mod.write_text(good);os.utime(mod,ns=(stamp,stamp));pyc=list((sdk/'__pycache__').iterdir());assert len(pyc)==1;old=pyc[0].read_bytes()
 payload=root/'payload.cjs';payload.write_text('ORIGINAL_PAYLOAD');plan=root/'plan.json';plan.write_text(json.dumps({'payloadFile':'payload.cjs','value':'ORIGINAL_PLAN'}));plan_sha=sha(plan);payload_sha=sha(payload)
 pilot=root/'fake-pilot.py';pilot.write_text("import sentinel,sys,json\nfrom pathlib import Path\np=Path(sys.argv[sys.argv.index('--plan')+1]).resolve();data=json.loads(p.read_text());v=(p.parent/data['payloadFile']).read_text();print(json.dumps({'value':sentinel.VALUE,'plan':data['value'],'payload':v,'argv':sys.argv[1:],'file':__file__,'name':__name__}))\n");pilot_hash=sha(pilot)
 cmd=snap.preview_command(python,sha(python),pilot,pilot_hash,plan,plan_sha,payload,payload_sha,sdk);assert cmd[1:6]==['-I','-B','-X','pycache_prefix=/dev/null','-c']
 access=root/'fake-access.py';access.write_text("import sentinel,sys,json\nfrom pathlib import Path\np=Path(sys.argv[sys.argv.index('--plan')+1]).resolve();d=json.loads(p.read_bytes());print('AUTH-'+sentinel.VALUE+'-'+d['value']+'-'+(p.parent/d['payloadFile']).read_text())\n");access_hash=sha(access);dummy=root/'dummy-entry.py';dummy.write_text('pass\n');base=helper.authenticated_pilot_command(python,access,access_hash,dummy,sha(dummy),plan,sdk);auth=snap.protect_auth_command(base,helper.CHILD_BOOTSTRAP,plan,plan_sha,payload,payload_sha);assert auth[1:6]==['-I','-B','-X','pycache_prefix=/dev/null','-c']
 pilot.write_text("raise RuntimeError('mutated pilot executed')\n");access.write_text("raise RuntimeError('mutated access executed')\n");decoy_plan=root/'decoy-plan.json';decoy_plan.write_text('{"payloadFile":"payload.cjs","value":"MUTATED"}');decoy_payload=root/'decoy-payload.cjs';decoy_payload.write_text('MUTATED');plan.unlink();plan.symlink_to(decoy_plan);payload.unlink();payload.symlink_to(decoy_payload)
 result=subprocess.run(cmd,capture_output=True,text=True,check=True);x=json.loads(result.stdout);assert x['value']=='GOOD' and x['plan']=='ORIGINAL_PLAN' and x['payload']=='ORIGINAL_PAYLOAD' and x['argv']==['--plan',str(plan)] and x['file']==str(pilot) and x['name']=='__main__' and pyc[0].read_bytes()==old
 response=subprocess.run(auth,capture_output=True,text=True,check=True);assert response.stdout.strip()=='AUTH-GOOD-ORIGINAL_PLAN-ORIGINAL_PAYLOAD' and pyc[0].read_bytes()==old
 for fn in (lambda:snap.preview_command(python,'0'*64,pilot,sha(pilot),plan,sha(plan),payload,sha(payload),sdk),lambda:snap.capture_reads(plan,plan_sha,payload,payload_sha),lambda:snap.protect_auth_command([python,'-c','bad'],helper.CHILD_BOOTSTRAP,plan,sha(plan),payload,sha(payload))):
  try:fn()
  except ValueError:pass
  else:raise AssertionError('bad pin/bootstrap accepted')
 orphan=sdk/'orphan.py';orphan.write_text("VALUE='BYTECODE_ONLY'\n");py_compile.compile(str(orphan),cfile=str(sdk/'orphan.pyc'),doraise=True);orphan.unlink();orphan_pilot=root/'orphan-pilot.py';orphan_pilot.write_text('import orphan\n');orphan_cmd=snap.preview_command(python,sha(python),orphan_pilot,sha(orphan_pilot),decoy_plan,sha(decoy_plan),payload,sha(payload),sdk);orphan_run=subprocess.run(orphan_cmd,capture_output=True,text=True);assert orphan_run.returncode!=0 and 'sourceless bytecode imports disabled' in orphan_run.stderr
 print('actual synthetic OS children: pilot, adapter, plan and payload snapshots survive pathname mutation; valid poisoned pyc ignored; sourceless pyc refused; argv/file/name correct; corrupt pins rejected; no provider or held main')
