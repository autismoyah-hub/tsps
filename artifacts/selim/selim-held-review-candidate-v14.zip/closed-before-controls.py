"""Synthetic real-scanner BEFORE-retained -> AFTER composition; no provider, Cuttle or main."""
from pathlib import Path
import tempfile,json,hashlib,importlib.util,types,copy,datetime
R=Path(__file__).resolve().parent

def load(name,path):s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
scanner=load('real_scan',R/'nested-custody-scan.py');closed=load('closed',R/'closed-before-disposition.py');custody=load('collector_custody',R/'collector-custody.py');m=load('after_caller',R/'after'/'prestart-selim.py');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();owner=m.OWNER
with tempfile.TemporaryDirectory(dir=R/'before',prefix='synthetic-closed-') as bt, tempfile.TemporaryDirectory(dir=R/'after',prefix='synthetic-current-') as at:
 before=Path(bt);after=Path(at);job='synthetic-before-job';after_job='synthetic-after-job';plan={'source':closed.BEFORE,'name':'before-synthetic','executionHold':None,'ownerSelection':{'owner':owner}};planpath=before/'pilot.json';planpath.write_text(json.dumps(plan));plan_sha=sha(planpath)
 def put(path,obj):path.write_text(json.dumps(obj));return path
 cmd=['node','-e','synthetic'];command_sha=hashlib.sha256(json.dumps(cmd,ensure_ascii=True,separators=(',',':')).encode()).hexdigest();submission=put(before/'submission.json',{'stage':'SUBMITTED','namespace':'Autismo-Yah','plan':plan,'request':{'command':cmd},'job':{'id':job,'command':cmd}})
 runtime=put(before/'mapref-runtime-custody.json',{'jobId':job,'planSHA256':plan_sha,'owner':owner,'stage':'ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED'})
 observation=put(before/'terminal-inspection-synthetic.stdout',{'namespace':'Autismo-Yah','jobId':job,'stage':'COMPLETED','commandSHA256':command_sha});intent=put(before/'collection-custody.json',{'jobId':job,'planSHA256':plan_sha,'operator':owner,'stage':'COLLECTION_OWNED_PENDING','noAutomaticRetry':True,'terminalObservationPath':str(observation),'terminalObservationSHA256':sha(observation),'commandSHA256':command_sha})
 status=put(before/'status-20260101.json',{'id':job,'status':{'stage':'COMPLETED'},'command':cmd});log=before/'logs-20260101.txt';log.write_text('synthetic log')
 childout=before/'collection-child-synthetic.stdout';childout.write_text('synthetic child');childerr=before/'collection-child-synthetic.stderr';childerr.write_text('');childmeta=put(before/'collection-child-synthetic.json',{'outcome':'EXIT_0','stdout':childout.name,'stdoutSHA256':sha(childout),'stderr':childerr.name,'stderrSHA256':sha(childerr)});closure=put(before/'collection-closure.json',{'jobId':job,'stage':'COMPLETED','collector':owner,'classification':'NOT_REVIEWED','childCapture':{'outcome':'EXIT_0','stdout':str(childout),'metadata':str(childmeta)},'status':{'path':status.name,'sha256':sha(status),'bytes':status.stat().st_size},'log':{'path':log.name,'sha256':sha(log),'bytes':log.stat().st_size}})
 paths={'plan':planpath,'submission':submission,'runtime':runtime,'collectionIntent':intent,'collectionClosure':closure,'terminalStatus':status,'rawLog':log,'terminalObservation':observation,'childMeta':childmeta,'childStdout':childout,'childStderr':childerr}
 def rows():return {k:{'path':str(p.relative_to(R)),'sha256':sha(p)} for k,p in paths.items()}
 disp={'type':'INDEPENDENTLY_REVIEWED_CLOSED_BEFORE','jobId':job,'terminalStage':'COMPLETED','resultClassification':'CAUSAL_BASELINE_CONFIRMED','files':rows(),'reviewEvidence':{'synthetic':True}}
 class FakeReview:
  def validate(self,record,subject,sender,owner2,operator,marker,workspace,producer,validator,require_artifacts,historical=False):
   assert record=={'synthetic':True} and marker=='SELIM_BEFORE_CLOSED_GO' and historical and subject['files']==disp['files'];return {'synthetic':True}
 fake_review=FakeReview();real_load=m.load_guard_component
 class RealScanner:
  roots=[before]
  def scan(self,ignored):return scanner.scan(self.roots)
 real_scan=RealScanner()
 def fake_load(file,digest):
  if file=='nested-custody-scan.py':return real_scan
  if file=='authenticated-review.py':return fake_review
  if file=='case-sessions.py':return types.SimpleNamespace(discover=lambda:{'sessions':[{'id':owner,'status':'running'}]})
  return real_load(file,digest)
 m.load_guard_component=fake_load
 try:
  after_plan={'source':closed.AFTER,'name':'after-synthetic'};result=m.scan_case_custody(after_plan,{'closedBefore':disp});assert len(result['found'])==3 and len(result['reviewedClosedBefore']['allowedScannerRecords'])==3
  now=datetime.datetime.now(datetime.timezone.utc).isoformat();pre_record={'type':'BOUNDED_SAME_CASE_RECONCILIATION','operator':owner,'source':closed.AFTER,'name':after_plan['name'],'planSHA256':'p'*64,'selectionSHA256':'s'*64,'checkedUTC':now,'knownCaseSessions':[owner],'peerEvidence':{},'closedBefore':disp};preflight=m.validate_reconciliation(pre_record,'p'*64,'s'*64,after_plan);assert len(preflight['localScan']['reviewedClosedBefore']['allowedScannerRecords'])==3
  (before/'case-check.json').write_text('{}');assert len(m.scan_case_custody(after_plan,{'closedBefore':disp})['found'])==3
  blocked=before/'reconciliation.json';blocked.write_text('{}')
  try:m.scan_case_custody(after_plan,{'closedBefore':disp})
  except ValueError:pass
  else:raise AssertionError('unaccounted reconciliation filename accepted')
  blocked.unlink()
  # No disposition, wrong phase, changed hash, wrong job and nonterminal all fail closed.
  try:m.scan_case_custody(after_plan,{})
  except ValueError:pass
  else:raise AssertionError('undisposed BEFORE accepted')
  try:m.scan_case_custody({'source':closed.BEFORE},{'closedBefore':disp})
  except ValueError:pass
  else:raise AssertionError('BEFORE replay exemption accepted')
  original=status.read_text();status.write_text(json.dumps({'id':'wrong','status':{'stage':'COMPLETED'}}))
  try:m.scan_case_custody(after_plan,{'closedBefore':disp})
  except ValueError:pass
  else:raise AssertionError('changed hash accepted')
  # Update actual file hashes in the synthetic record to isolate job-identity rejection.
  bad=copy.deepcopy(disp);bad['files']=rows()
  try:m.scan_case_custody(after_plan,{'closedBefore':bad})
  except ValueError:pass
  else:raise AssertionError('wrong job accepted')
  status.write_text(json.dumps({'id':job,'status':{'stage':'COMPLETED'},'command':['wrong']}));bad=copy.deepcopy(disp);bad['files']=rows()
  try:m.scan_case_custody(after_plan,{'closedBefore':bad})
  except ValueError:pass
  else:raise AssertionError('wrong returned command accepted')
  status.write_text(original);obs_original=observation.read_text();observation.write_text(json.dumps({'namespace':'Autismo-Yah','jobId':job,'stage':'COMPLETED','commandSHA256':'0'*64}));bad=copy.deepcopy(disp);bad['files']=rows()
  try:m.scan_case_custody(after_plan,{'closedBefore':bad})
  except ValueError:pass
  else:raise AssertionError('wrong terminal observation accepted')
  observation.write_text(obs_original);child_original=childout.read_text();childout.write_text('changed');bad=copy.deepcopy(disp);bad['files']=rows()
  try:m.scan_case_custody(after_plan,{'closedBefore':bad})
  except ValueError:pass
  else:raise AssertionError('changed child capture accepted')
  childout.write_text(child_original)
  status.write_text(original);bad=copy.deepcopy(disp);bad['resultClassification']='UNKNOWN'
  try:m.scan_case_custody(after_plan,{'closedBefore':bad})
  except ValueError:pass
  else:raise AssertionError('unreviewed causal baseline accepted')
  bad=copy.deepcopy(disp);bad['terminalStage']='RUNNING'
  try:m.scan_case_custody(after_plan,{'closedBefore':bad})
  except ValueError:pass
  else:raise AssertionError('nonterminal accepted')
  extra=before/'unknown-custody.json';extra.write_text('{}')
  try:m.scan_case_custody(after_plan,{'closedBefore':disp})
  except ValueError:pass
  else:raise AssertionError('extra custody accepted')
  extra.unlink()
  # AFTER collection scan sees exactly the reviewed BEFORE files and AFTER's own two records.
  after_plan.update({'executionHold':None,'ownerSelection':{'owner':owner}});after_planpath=after/'pilot.json';after_planpath.write_text(json.dumps(after_plan));aps=sha(after_planpath);asub=put(after/'submission.json',{'synthetic':True});aruntime=put(after/'mapref-runtime-custody.json',{'jobId':after_job,'planSHA256':aps,'owner':owner,'stage':'ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED'});real_scan.roots=[before,after]
  now=datetime.datetime.now(datetime.timezone.utc).isoformat();record={'type':'BOUNDED_SAME_JOB_COLLECTOR_RECONCILIATION','operator':owner,'source':closed.AFTER,'name':after_plan['name'],'planSHA256':aps,'selectionSHA256':'s'*64,'jobId':after_job,'checkedUTC':now,'knownCaseSessions':[owner],'peerEvidence':{},'closedBefore':disp};discovery=types.SimpleNamespace(discover=lambda:{'sessions':[{'id':owner,'status':'running'}]})
  r=custody.validate(record,after_plan,aps,'s'*64,after_job,owner,R,asub,None,None,fake_review,discovery,real_scan,closed);assert len(r['localScan']['found'])==5 and len(r['reviewedClosedBefore']['allowedScannerRecords'])==3
  aruntime.write_text(json.dumps({'jobId':'wrong','planSHA256':aps,'owner':owner,'stage':'ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED'}))
  try:custody.validate(record,after_plan,aps,'s'*64,after_job,owner,R,asub,None,None,fake_review,discovery,real_scan,closed)
  except ValueError:pass
  else:raise AssertionError('wrong AFTER job accepted')
 finally:m.load_guard_component=real_load
print('synthetic real scanner: reviewed terminal BEFORE retained -> AFTER prestart + AFTER collector; wrong hash/job/nonterminal/unknown/replay negatives pass; no actual evidence or provider')
