"""Narrow exact, independently reviewed terminal BEFORE disposition; no provider operation."""
from pathlib import Path
import hashlib,json
BEFORE='aecaaa206a2269f15cd00b347f6bbae2fe46de04'
AFTER='dd94dfa5ba3b85ebb4d8b7bb2b78024c8ecdb52e'
REVIEWER='fd71cec2-5528-4513-91b9-2b4d8e49c40c'
TERMINAL={'COMPLETED','CANCELED','ERROR'}

def validate(disposition,current_source,owner,workspace,producer,validator,review):
    if current_source!=AFTER or disposition.get('type')!='INDEPENDENTLY_REVIEWED_CLOSED_BEFORE' or disposition.get('resultClassification')!='CAUSAL_BASELINE_CONFIRMED':raise ValueError('DISPOSITION_SCOPE')
    workspace=Path(workspace).resolve();before_root=(workspace/'before').resolve();rows=disposition.get('files')
    keys={'plan','submission','runtime','collectionIntent','collectionClosure','terminalStatus','rawLog','terminalObservation','childMeta','childStdout','childStderr'}
    if not isinstance(rows,dict) or set(rows)!=keys:raise ValueError('DISPOSITION_FILES')
    blobs={};paths={}
    for key,row in rows.items():
        if not isinstance(row,dict) or set(row)!={'path','sha256'}:raise ValueError('DISPOSITION_ROW')
        original=workspace/row['path'];path=original.resolve(strict=True)
        if original.is_symlink() or not path.is_relative_to(before_root) or not path.is_file() or path in paths.values():raise ValueError('DISPOSITION_PATH')
        raw=path.read_bytes()
        if len(raw)>32*1024*1024 or hashlib.sha256(raw).hexdigest()!=row['sha256']:raise ValueError('DISPOSITION_HASH')
        blobs[key]=raw;paths[key]=path
    case=paths['plan'].parent
    if any(p.parent!=case for p in paths.values()):raise ValueError('DISPOSITION_CASE_DIRECTORY')
    for key,name in {'plan':'pilot.json','submission':'submission.json','runtime':'mapref-runtime-custody.json','collectionIntent':'collection-custody.json','collectionClosure':'collection-closure.json'}.items():
        if paths[key].name!=name:raise ValueError('DISPOSITION_FILENAME')
    if not paths['terminalStatus'].name.startswith('status-') or not paths['terminalStatus'].name.endswith('.json'):raise ValueError('DISPOSITION_STATUS_NAME')
    stamp=paths['terminalStatus'].name[len('status-'):-len('.json')]
    if not stamp or paths['rawLog'].name!='logs-'+stamp+'.txt':raise ValueError('DISPOSITION_LOG_NAME')
    if not paths['terminalObservation'].name.startswith('terminal-inspection-') or not paths['terminalObservation'].name.endswith('.stdout'):raise ValueError('DISPOSITION_OBSERVATION_NAME')
    plan=json.loads(blobs['plan']);submission=json.loads(blobs['submission']);runtime=json.loads(blobs['runtime']);intent=json.loads(blobs['collectionIntent']);closure=json.loads(blobs['collectionClosure']);status=json.loads(blobs['terminalStatus']);observation=json.loads(blobs['terminalObservation']);child_meta=json.loads(blobs['childMeta'])
    plan_sha=hashlib.sha256(blobs['plan']).hexdigest();job_id=disposition.get('jobId');stage=disposition.get('terminalStage')
    if not isinstance(job_id,str) or not job_id or stage not in TERMINAL:raise ValueError('DISPOSITION_JOB_OR_STAGE')
    if plan.get('source')!=BEFORE or plan.get('executionHold') or (plan.get('ownerSelection') or {}).get('owner')!=owner:raise ValueError('DISPOSITION_PLAN')
    if submission.get('stage')!='SUBMITTED' or submission.get('namespace')!='Autismo-Yah' or submission.get('plan')!=plan or (submission.get('job') or {}).get('id')!=job_id:raise ValueError('DISPOSITION_SUBMISSION')
    if runtime.get('jobId')!=job_id or runtime.get('planSHA256')!=plan_sha or runtime.get('owner')!=owner or runtime.get('stage') not in ('ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED','ADMITTED_BINDING_PENDING_MANUAL_COLLECTION_OWNED'):raise ValueError('DISPOSITION_RUNTIME')
    if intent.get('jobId')!=job_id or intent.get('planSHA256')!=plan_sha or intent.get('operator')!=owner or intent.get('stage')!='COLLECTION_OWNED_PENDING' or intent.get('noAutomaticRetry') is not True:raise ValueError('DISPOSITION_COLLECTION_INTENT')
    if status.get('id')!=job_id or (status.get('status') or {}).get('stage')!=stage:raise ValueError('DISPOSITION_TERMINAL_STATUS')
    command=(submission.get('request') or {}).get('command')
    if not isinstance(command,list) or not command or not all(isinstance(x,str) for x in command) or (submission.get('job') or {}).get('command')!=command:raise ValueError('DISPOSITION_SUBMITTED_COMMAND')
    command_sha=hashlib.sha256(json.dumps(command,ensure_ascii=True,separators=(',',':')).encode()).hexdigest()
    if status.get('command')!=command:raise ValueError('DISPOSITION_RETURNED_COMMAND')
    if observation.get('namespace')!='Autismo-Yah' or observation.get('jobId')!=job_id or observation.get('stage')!=stage or observation.get('commandSHA256')!=command_sha:raise ValueError('DISPOSITION_OBSERVATION')
    if Path(intent.get('terminalObservationPath','')).resolve()!=paths['terminalObservation'] or intent.get('terminalObservationSHA256')!=hashlib.sha256(blobs['terminalObservation']).hexdigest() or intent.get('commandSHA256')!=command_sha:raise ValueError('DISPOSITION_INTENT_OBSERVATION')
    if closure.get('jobId')!=job_id or closure.get('stage')!=stage or closure.get('collector')!=owner or closure.get('classification')!='NOT_REVIEWED':raise ValueError('DISPOSITION_CLOSURE')
    for key,expected in (('status','terminalStatus'),('log','rawLog')):
        item=closure.get(key) or {};raw=blobs[expected]
        if item.get('path')!=paths[expected].name or item.get('sha256')!=hashlib.sha256(raw).hexdigest() or item.get('bytes')!=len(raw):raise ValueError('DISPOSITION_CLOSURE_FILE')
    child=closure.get('childCapture') or {}
    if child.get('outcome')!='EXIT_0' or child_meta.get('outcome')!='EXIT_0' or Path(child.get('metadata','')).resolve()!=paths['childMeta'] or Path(child.get('stdout','')).resolve()!=paths['childStdout']:raise ValueError('DISPOSITION_CHILD_UNKNOWN')
    for label,key in (('stdout','childStdout'),('stderr','childStderr')):
        if child_meta.get(label)!=paths[key].name or child_meta.get(label+'SHA256')!=hashlib.sha256(blobs[key]).hexdigest():raise ValueError('DISPOSITION_CHILD_CAPTURE')
    subject={'source':BEFORE,'jobId':job_id,'planSHA256':plan_sha,'terminalStage':stage,'files':rows,'resultClassification':'CAUSAL_BASELINE_CONFIRMED','disposition':'INDEPENDENTLY_REVIEWED_CLOSED_BEFORE'}
    reviewed=review.validate(disposition['reviewEvidence'],subject,REVIEWER,owner,owner,'SELIM_BEFORE_CLOSED_GO',workspace,producer,validator,True,historical=True)
    allowed={str(paths[k]):hashlib.sha256(blobs[k]).hexdigest() for k in ('submission','runtime','collectionIntent')}
    return {'subject':subject,'review':reviewed,'allowedScannerRecords':allowed}
