"""Bounded same-case collector reconciliation; no global absence claim."""
from pathlib import Path
import datetime,json,hashlib

def validate(record,plan,plan_sha,selection_sha,job_id,owner,workspace,submission_path,producer,validator,review,discovery,scanner,closed_guard):
    if record.get('type')!='BOUNDED_SAME_JOB_COLLECTOR_RECONCILIATION' or record.get('operator')!=owner or record.get('source')!=plan['source'] or record.get('name')!=plan['name'] or record.get('planSHA256')!=plan_sha or record.get('selectionSHA256')!=selection_sha or record.get('jobId')!=job_id:raise ValueError('COLLECTOR_SCOPE')
    try:observed=datetime.datetime.fromisoformat(record['checkedUTC'].replace('Z','+00:00'));age=(datetime.datetime.now(datetime.timezone.utc)-observed).total_seconds()
    except (KeyError,TypeError,ValueError):raise ValueError('COLLECTOR_TIME')
    if observed.utcoffset() is None or not 0<=age<=300:raise ValueError('COLLECTOR_STALE')
    known=record.get('knownCaseSessions');peers=record.get('peerEvidence')
    if not isinstance(known,list) or owner not in known or any(not isinstance(x,str) for x in known) or len(set(known))!=len(known) or not isinstance(peers,dict) or set(peers)!=set(known)-{owner}:raise ValueError('COLLECTOR_KNOWN_SESSION_SET')
    found=discovery.discover();ids={x['id'] for x in found['sessions']}
    if owner not in ids or not ids.issubset(set(known)) or any(not isinstance(x.get('status'),str) or not x['status'] for x in found['sessions']):raise ValueError('COLLECTOR_UNACCOUNTED_CASE_SESSION')
    subject={'source':plan['source'],'name':plan['name'],'planSHA256':plan_sha,'selectionSHA256':selection_sha,'jobId':job_id,'disposition':'NO_CONFLICTING_COLLECTOR_FOR_JOB','checkedUTC':record['checkedUTC']}
    checked={}
    for peer in sorted(peers):
        checked[peer]=review.validate(peers[peer],subject,peer,owner,owner,'SELIM_COLLECTOR_CUSTODY_CLEAR',workspace,producer,validator,False)
        if datetime.datetime.fromisoformat(checked[peer]['sentUTC'])<observed:raise ValueError('COLLECTOR_PEER_PREDATES_CHECK')
    roots=['/workspace/selim-notes','/workspace/selim-custody','/workspace/selim-custody-selim-partisan'];local=scanner.scan(roots)
    if local['errors'] or local['skippedSymlinkDirectories']:raise ValueError('COLLECTOR_LOCAL_SCAN_INCOMPLETE')
    disposition=record.get('closedBefore');closed=None;allowed={}
    if disposition is not None:
        closed=closed_guard.validate(disposition,plan['source'],owner,workspace,producer,validator,review);allowed=closed['allowedScannerRecords']
    submission_path=Path(submission_path).resolve();runtime_path=submission_path.parent/'mapref-runtime-custody.json';seen_submission=False;seen_runtime=False
    for row in local['found']:
        path=Path(row['path']).resolve()
        if path==submission_path:
            if seen_submission or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:raise ValueError('COLLECTOR_SUBMISSION_CHANGED')
            seen_submission=True
        elif path==runtime_path:
            if seen_runtime:raise ValueError('COLLECTOR_DUPLICATE_CUSTODY')
            raw=path.read_bytes();data=json.loads(raw)
            if hashlib.sha256(raw).hexdigest()!=row['sha256'] or data.get('jobId')!=job_id or data.get('planSHA256')!=plan_sha or data.get('owner')!=owner or data.get('stage') not in ('ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED','ADMITTED_BINDING_PENDING_MANUAL_COLLECTION_OWNED'):raise ValueError('COLLECTOR_CUSTODY_UNKNOWN')
            seen_runtime=True
        elif str(path) in allowed and row['sha256']==allowed[str(path)]:pass
        else:raise ValueError('COLLECTOR_OTHER_LOCAL_INTENT_OR_CUSTODY')
    if not seen_submission or not seen_runtime:raise ValueError('COLLECTOR_LOCAL_PROVENANCE_MISSING')
    return {'scope':'known same-case sessions and own local roots; no global absence claim','discovery':found,'peerEvidence':checked,'localScan':local,'reviewedClosedBefore':closed}
