"""Synthetic direct peer disposition capture; no network or provider."""
from pathlib import Path
import importlib.util,tempfile,json,hashlib,datetime,shlex,types,copy
R=Path(__file__).resolve().parent
for phase in ('before','after'):
 spec=importlib.util.spec_from_file_location('candidate_'+phase,R/phase/'prestart-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 owner=m.OWNER;peer='11111111-1111-4111-8111-111111111111';now=datetime.datetime.now(datetime.timezone.utc).isoformat();plan=json.loads((R/phase/'pilot.json').read_bytes());ps='a'*64;ss='b'*64;subject={'source':plan['source'],'name':plan['name'],'planSHA256':ps,'selectionSHA256':ss,'disposition':'NO_MATCHING_INTENT_OR_COLLECTOR','checkedUTC':now};marker='SELIM_SELECTED_CUSTODY_CLEAR';message=marker+' '+json.dumps(subject,sort_keys=True,separators=(',',':'));fname='synthetic-disposition.txt';tool='synthetic-peer-tool';cmd=shlex.join(['cuttle','--json','sessions','send',owner,'--file',fname]);session={'id':peer,'name':'peer'};out={'turns':[{'role':'assistant','kind':'tool','ts':now,'tool':{'id':tool,'input':json.dumps({'command':cmd})}},{'role':'user','kind':'tool_result','ts':now,'tool':{'id':tool,'ok':True}}]};inc={'turns':[{'role':'user','ts':now,'text':'[From Cuttle session "peer" · '+peer+']\n'+message}]}
 with tempfile.TemporaryDirectory(dir=R) as tmp:
  root=Path(tmp);n=[0]
  def file(data):
   p=root/str(n[0]);n[0]+=1;raw=data if isinstance(data,bytes) else json.dumps(data).encode();p.write_bytes(raw);return {'path':str(p.relative_to(R)),'sha256':hashlib.sha256(raw).hexdigest()}
  def cap(data,method,route):return {**file(data),'method':method,'route':route,'status':200,'observedUTC':now}
  evidence={'reviewerSession':cap(session,'GET','/api/sessions/'+peer),'reviewerTranscript':cap(out,'GET','/api/sessions/'+peer+'/transcript'),'ownerTranscript':cap(inc,'GET','/api/sessions/'+owner+'/transcript')};evidence['sendRequest']={**file(message.encode()),'sourceFile':fname};evidence['sendResponse']={**file({'ok':True,'sessionId':owner}),'source':'SUPPORTED_CUTTLE_CLI','sourceFile':fname,'exitCode':0,'argv':['cuttle','--json','sessions','send',owner,'--file',fname],'observedUTC':now}
  peerev={'type':'AUTHENTICATED_DIRECT_REVIEW_CAPTURE','issuer':peer,'owner':owner,'operator':owner,'verdict':marker,'subject':subject,'directSessionEvidence':evidence,'reviewArtifacts':[]};record={'type':'BOUNDED_SAME_CASE_RECONCILIATION','operator':owner,'source':plan['source'],'name':plan['name'],'planSHA256':ps,'selectionSHA256':ss,'checkedUTC':now,'knownCaseSessions':[owner,peer],'peerEvidence':{peer:peerev}}
  live={'reviewerSession':session,'ownerSession':{'id':owner},'reviewerTranscript':out,'ownerTranscript':inc};discovery={'sessions':[{'id':owner,'name':'Selim owner','status':'running'},{'id':peer,'name':'Selim peer','status':'running'}]};oldload=m.load_guard_component;oldscan=m.scan_case_custody
  def fake_load(file,digest):
   if file=='case-sessions.py':return types.SimpleNamespace(discover=lambda:discovery)
   if file=='authenticated-direct-context.py':return types.SimpleNamespace(authentic_direct_context=lambda sender:live)
   return oldload(file,digest)
  m.load_guard_component=fake_load;m.scan_case_custody=lambda *args:{'found':[]}
  try:
   assert peer in m.validate_reconciliation(record,ps,ss,plan)['peerEvidence']
   for mode in ('wrong_disposition','truncated_peer','failed_send','wrong_selection'):
    bad=copy.deepcopy(record);saved=copy.deepcopy(live)
    if mode=='wrong_disposition':bad['peerEvidence'][peer]['subject']['disposition']='UNKNOWN'
    if mode=='truncated_peer':live['ownerTranscript']={'turns':[]}
    if mode=='failed_send':bad['peerEvidence'][peer]['directSessionEvidence']['sendResponse']['exitCode']=1
    if mode=='wrong_selection':bad['selectionSHA256']='c'*64
    try:m.validate_reconciliation(bad,ps,ss,plan)
    except (ValueError,AssertionError):pass
    else:raise AssertionError('accepted '+mode)
    live.clear();live.update(saved)
  finally:m.load_guard_component=oldload;m.scan_case_custody=oldscan
 print(phase,'synthetic direct peer disposition and four failure negatives; no network/provider/main')
