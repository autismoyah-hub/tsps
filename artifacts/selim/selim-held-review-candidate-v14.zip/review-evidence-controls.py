import importlib.util,pathlib,copy,datetime
R=pathlib.Path(__file__).resolve().parent;s=importlib.util.spec_from_file_location('evidence',R/'review-evidence-validators.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
now=datetime.datetime.now(datetime.timezone.utc); source='a'*40;name='tsps-selim-before';row={'id':'one','owner':m.NAMESPACE,'stage':'COMPLETED','labels':{'project':'tsps','source':'b'*40,'name':'other'}}
c={'namespace':m.NAMESPACE,'project':'tsps','complete':True,'finishedUTC':now.isoformat(),'queries':{'project':{'labels':{'project':'tsps'},'complete':True,'rows':[row]},'source':{'labels':{'project':'tsps','source':source},'complete':True,'rows':[]},'name':{'labels':{'project':'tsps','name':name},'complete':True,'rows':[]}}}
assert m.validate_provider_content(c,source,name,now)
changes=[lambda x:x.update(complete=False),lambda x:x.update(finishedUTC=(now-datetime.timedelta(seconds=301)).isoformat()),lambda x:x['queries']['project']['rows'][0]['labels'].pop('name'),lambda x:x['queries']['source'].update(complete=False),lambda x:x['queries']['source']['rows'].append(row),lambda x:x['queries']['project']['rows'][0].update(stage='UNRECOGNIZED'),lambda x:x['queries']['project']['rows'][0]['labels'].update(source=source),lambda x:x.update(namespace='wrong')]
for change in changes:
 bad=copy.deepcopy(c);change(bad)
 try:m.validate_provider_content(bad,source,name,now)
 except ValueError:pass
 else:raise AssertionError('provider mutation accepted')
subject={'source':source,'hash':'c'*64};nonce='n'*32; parent={'id':'fd71cec2-5528-4513-91b9-2b4d8e49c40c'};owner={'id':'433a743a-eb04-4066-8251-791c89e978e3'};value={'nonce':nonce,'verdict':'EXACT_INPUT_PROFILE_GO','subject':subject}
import json,shlex
outgoing=json.dumps(value);tool_id='synthetic-tool-1';command=shlex.join(['cuttle','--json','sessions','send',owner['id'],outgoing])
p={'turns':[{'role':'assistant','kind':'tool','ts':now.isoformat(),'tool':{'id':tool_id,'input':json.dumps({'command':command})}},{'role':'user','kind':'tool_result','ts':now.isoformat(),'tool':{'id':tool_id,'ok':True}}]}
o={'turns':[{'role':'user','text':'[From Cuttle session "reviewer" · '+parent['id']+']\n'+outgoing,'ts':now.isoformat()}]};sent={'ok':True,'sessionId':owner['id']}
assert m.validate_review_content(subject,parent,p,owner,o,sent,outgoing,nonce)
for index in range(6):
 a,b,d,e=map(copy.deepcopy,(parent,p,o,sent))
 if index==0:a['id']='wrong'
 if index==1:b['turns'][0]['tool']['input']='{}'
 if index==2:d['turns'][0]['role']='assistant'
 if index==3:e['ok']=False
 if index==4:b['turns'][1]['tool']['ok']=False
 if index==5:d['turns'][0]['ts']=(now-datetime.timedelta(seconds=1)).isoformat()
 try:m.validate_review_content(subject,a,b,owner,d,e,outgoing,nonce)
 except ValueError:pass
 else:raise AssertionError('review mutation accepted')
print('synthetic content checks: positive and 8 provider/6 review negatives pass; no transport authenticity asserted; no main/provider invoked')
s2=importlib.util.spec_from_file_location('snapshot',R/'provider-snapshot.py');snap=importlib.util.module_from_spec(s2);s2.loader.exec_module(snap)
class API:
 def __init__(self,fail=False):self.calls=[];self.fail=fail
 def list_jobs(self,namespace,labels):
  self.calls.append((namespace,labels))
  if self.fail and len(self.calls)==2:raise RuntimeError('partial listing')
  return iter([])
a=API();capture=snap.collect(a,source,name);assert len(a.calls)==3 and m.validate_provider_content(capture,source,name)
try:snap.collect(API(True),source,name)
except RuntimeError:pass
else:raise AssertionError('partial provider failure accepted')
print('synthetic complete 3-query provider iterator accepted; partial iteration rejected; no provider connected')
s3=importlib.util.spec_from_file_location('retrieval',R/'cuttle-review-retrieval.py');retrieval=importlib.util.module_from_spec(s3);s3.loader.exec_module(retrieval)
class Response:
 def __init__(self,content):self.stdout=json.dumps(content).encode()
def fake_run(argv,**kwargs):
 assert argv[:2]==['cuttle','--json'] and kwargs['check'] is True
 if argv[2:4]==['sessions','get']:return Response({'id':argv[-1]})
 return Response({'turns':[]})
r=retrieval.retrieve(fake_run);assert r['parentIdentity']['document']['id']==parent['id'] and r['ownerIdentity']['document']['id']==owner['id']
print('synthetic authenticated-retrieval argv/identity wiring checked; no Cuttle request invoked by control')
s4=importlib.util.spec_from_file_location('collection',R/'collection-contract.py');collection=importlib.util.module_from_spec(s4);s4.loader.exec_module(collection)
plan={'source':source};raw=json.dumps(plan).encode();digest=__import__('hashlib').sha256(raw).hexdigest();cmd=['node','-e','example'];sub={'stage':'SUBMITTED','namespace':'Autismo-Yah','plan':plan,'request':{'command':cmd},'job':{'id':'job1','command':cmd}};pre={'planSHA256':digest,'source':source,'noJobAPI':True};binding={'jobId':'job1','planSHA256':digest,'renderedEqualsSubmittedEqualsReturned':True};owner_id='433a743a-eb04-4066-8251-791c89e978e3'
assert collection.validate_collection(sub,pre,binding,plan,raw,owner_id)=='job1'
for key in ('jobId','planSHA256','renderedEqualsSubmittedEqualsReturned'):
 bad=copy.deepcopy(binding);bad[key]=None
 try:collection.validate_collection(sub,pre,bad,plan,raw,owner_id)
 except ValueError:pass
 else:raise AssertionError('bad collector binding accepted')
print('synthetic same-job collector identity and three negatives passed; no collect invoked')
