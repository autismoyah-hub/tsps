"""HELD author-owned same-job collection candidate; no automatic collection."""
from pathlib import Path
import hashlib,importlib.util,json,sys
ROOT=Path(__file__).resolve().parent
EXPECTED_COMPONENTS={'collectionContract': 'f38306f3da67d45e7469876abbded1c6c144d3b1656dbf3e455682ec47736394', 'sdkVerifier': 'e47594c5e8c9858111312b194c3659ba98d927672968eba56e44cccedaa717be', 'sdkManifest': '8d40023673b396fc7f507e3ff39fdcef1f7e416aa649ece34c92949d56b297d6', 'authChild': '00ff45d75be1eae3bc8f04995cfb8bcbe2bc5adc28c1162b843cfe88c87024f9', 'snapshotChild': '8de08bd848f4cba2a4d1bd514534165f687a55795046516c109f9b60c1b424a6', 'authAccess': 'fab4bc92dc8601143ce61e910f8121774c22a0d19be6d2617bba9449f7131326', 'pilot': '2d7c5e44bb37f3043311962f8c05deee90e83ab6fa5ee5e3b499df238ed98200', 'payload': '220ef3554ec1bf8951c22dc8e50b849feeeaaa5b0b0b06f664ea7b393cb1dde4'}
EXECUTOR_BINDING_SHA256='b38e5180e2e8618cabf56086e6a54a44fd21f6c7130ac7b5c73cbd47b31da2c9'

def pinned_module(path,digest):
    raw=Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=digest:raise ValueError('source pin')
    import types
    module=types.ModuleType('selim_collection_component');module.__file__=str(path)
    exec(compile(raw,str(path),'exec'),module.__dict__)
    return module

def prepare_command(plan_path,plan_sha,submission,prestart,binding,operator,executor,component_hashes):
    if component_hashes!=EXPECTED_COMPONENTS:raise ValueError('unreviewed collector components')
    executor_raw=(ROOT/'executor-binding.json').read_bytes()
    if hashlib.sha256(executor_raw).hexdigest()!=EXECUTOR_BINDING_SHA256 or json.loads(executor_raw)!=executor:raise ValueError('executor binding')
    if operator!='433a743a-eb04-4066-8251-791c89e978e3' or executor['executor']!=operator:raise ValueError('sole collector')
    plan_path=Path(plan_path).resolve();raw=plan_path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=plan_sha:raise ValueError('selected plan')
    plan=json.loads(raw)
    if plan.get('executionHold') or not isinstance(plan.get('ownerSelection'),dict) or plan['ownerSelection'].get('owner')!=operator:raise ValueError('not selected')
    contract=pinned_module(ROOT/'collection-contract.py',component_hashes['collectionContract'])
    job=contract.validate_collection(submission,prestart,binding,plan,raw,operator)
    sdk=pinned_module(ROOT/'sdk-verify.py',component_hashes['sdkVerifier']);manifest=(ROOT/'sdk-file-manifest.json').read_bytes()
    if hashlib.sha256(manifest).hexdigest()!=component_hashes['sdkManifest']:raise ValueError('SDK manifest')
    sdk.verify(manifest,executor['sdkTarget'])
    if hashlib.sha256(Path(executor['python']).read_bytes()).hexdigest()!=executor['pythonSha256']:raise ValueError('interpreter')
    helper=pinned_module(ROOT/'authenticated-child-snapshot-command.py',component_hashes['authChild'])
    safe=pinned_module(ROOT/'snapshot-child.py',component_hashes['snapshotChild'])
    pilot=ROOT/'pilot.py';access=ROOT/'hf-project-access-v4.py';payload=ROOT/'native-payload-mapref-candidate.cjs'
    cmd=helper.authenticated_pilot_command(executor['python'],access,component_hashes['authAccess'],pilot,component_hashes['pilot'],plan_path,executor['sdkTarget'])
    cmd=safe.protect_auth_command(cmd,helper.CHILD_BOOTSTRAP,plan_path,plan_sha,payload,component_hashes['payload'])+['--collect']
    return {'jobId':job,'command':cmd}

def main():
    raise RuntimeError('HELD: actual reviewed same-job provenance and collector authority are not bound')

if __name__=='__main__':main()
