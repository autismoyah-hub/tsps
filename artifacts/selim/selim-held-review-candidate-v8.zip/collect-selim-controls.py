"""Synthetic collector command construction; no main, child or provider invocation."""
import pathlib,tempfile,hashlib,json,importlib.util,copy
R=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('collect',R/'collect-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();operator='433a743a-eb04-4066-8251-791c89e978e3';executor=json.loads((R/'executor-binding.json').read_bytes());names={'collectionContract':'collection-contract.py','sdkVerifier':'sdk-verify.py','sdkManifest':'sdk-file-manifest.json','authChild':'authenticated-child-snapshot-command.py','snapshotChild':'snapshot-child.py','authAccess':'hf-project-access-v4.py','pilot':'pilot.py','payload':'native-payload-mapref-candidate.cjs'};pins={k:sha(R/v) for k,v in names.items()}
with tempfile.TemporaryDirectory() as t:
 plan={'source':'a'*40,'payloadFile':str(R/'native-payload-mapref-candidate.cjs'),'executionHold':None,'ownerSelection':{'owner':operator}};p=pathlib.Path(t)/'plan.json';p.write_text(json.dumps(plan));digest=sha(p);cmd=['node','-e','synthetic'];submission={'stage':'SUBMITTED','namespace':'Autismo-Yah','plan':plan,'request':{'command':cmd},'job':{'id':'synthetic-job','command':cmd}};prestart={'planSHA256':digest,'source':plan['source'],'noJobAPI':True};binding={'jobId':'synthetic-job','planSHA256':digest,'renderedEqualsSubmittedEqualsReturned':True}
 result=m.prepare_command(p,digest,submission,prestart,binding,operator,executor,pins);assert result['jobId']=='synthetic-job' and result['command'][-1]=='--collect' and result['command'][1:6]==['-I','-B','-X','pycache_prefix=/dev/null','-c']
 for label in ('operator','job','digest','contract','snapshot'):
  s,b,h=copy.deepcopy(submission),copy.deepcopy(binding),dict(pins);owner=operator
  if label=='operator':owner='wrong'
  if label=='job':b['jobId']='other'
  if label=='digest':b['planSHA256']='0'*64
  if label=='contract':h['collectionContract']='0'*64
  if label=='snapshot':h['snapshotChild']='0'*64
  try:m.prepare_command(p,digest,s,prestart,b,owner,executor,h)
  except ValueError:pass
  else:raise AssertionError('accepted '+label)
print('collector synthetic same-job command construction and five corrupted identity/pin negatives passed; no child, main, provider or collection')
