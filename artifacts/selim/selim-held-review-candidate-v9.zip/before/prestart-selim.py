"""Isolated reference-aware prestart candidate. NEVER submits or changes a plan.
Requires already-selected exact reviewed bytes. Every output is a prestart receipt,
not admission authority. Frozen generic caller/pilot/D46 remain unchanged.
"""
from pathlib import Path
import argparse,base64,hashlib,json,re,subprocess,urllib.request,datetime
ROOT=Path(__file__).resolve().parent
WS=ROOT.parent
HF=ROOT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def bound(path,digest):
 raw=Path(path).read_bytes();assert re.fullmatch('[a-f0-9]{64}',digest) and sha(raw)==digest,str(path)
 return raw

def reference_url(plan):
 spec=plan['expectedInputsRef']
 assert not plan.get('expectedInputs') and not plan.get('sourceBlobs'),'Mixed modes'
 assert set(spec)=={'schema','repository','artifactCommit','path','sha256','bytes','source','count'}
 assert spec['schema']==1 and spec['repository']==plan['repository'] and re.fullmatch('[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',spec['repository'])
 assert re.fullmatch('[a-f0-9]{40}',spec['artifactCommit']) and len(set(spec['artifactCommit']))>1,'Prospective/placeholder artifact inadmissible'
 assert spec['source']==plan['source'] and re.fullmatch('[a-f0-9]{40}',plan['source'])
 assert re.fullmatch('[a-f0-9]{64}',spec['sha256']) and type(spec['bytes']) is int and 0<spec['bytes']<=2*1024*1024
 assert type(spec['count']) is int and 0<spec['count']<=10000
 assert re.fullmatch('[A-Za-z0-9_./-]+[.]json',spec['path']) and all(x and x not in ('.','..') for x in spec['path'].split('/'))
 return f"https://raw.githubusercontent.com/{spec['repository']}/{spec['artifactCommit']}/{spec['path']}"

class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):raise ValueError('Manifest redirect refused')

def resolve_bytes(plan,raw):
 spec=plan['expectedInputsRef'];assert len(raw)==spec['bytes'] and sha(raw)==spec['sha256'],'Manifest byte identity'
 # Reuse EXACT tested/embedded JS parser/schema, not a second document interpretation.
 code="""const fs=require('node:fs');const {resolveInputManifest}=require(process.argv[1]);
 const x=JSON.parse(fs.readFileSync(0,'utf8'));const raw=Buffer.from(x.base64,'base64');
 resolveInputManifest(x.plan,async url=>({ok:true,url,body:(async function*(){yield raw})()}))
 .then(x=>console.log(JSON.stringify(x))).catch(e=>{console.error(e.message);process.exitCode=70});"""
 r=subprocess.run(['node','-e',code,str(HF/'input-manifest-resolver.cjs')],input=json.dumps({'plan':plan,'base64':base64.b64encode(raw).decode()}).encode(),capture_output=True,check=True)
 return json.loads(r.stdout)

def verify_git(plan,resolved):
 repo=Path('/workspace/selim-custody');rows=resolved['expectedInputs'];blobs=resolved['sourceBlobs']
 assert len(rows)==plan['expectedInputsRef']['count'] and set(rows)==set(blobs)
 tree={}
 for row in subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','-z',plan['source']]).split(b'\0'):
  if row:
   meta,file=row.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[file.decode()]=(kind,oid)
 for file in rows:assert tree[file]==('blob',blobs[file]),file
 names=list(rows);data=subprocess.check_output(['git','-C',str(repo),'cat-file','--batch'],input=('\n'.join(blobs[x] for x in names)+'\n').encode());offset=0;actual={}
 for file in names:
  end=data.index(b'\n',offset);oid,kind,size=data[offset:end].decode().split();offset=end+1;raw=data[offset:offset+int(size)];offset+=int(size)+1
  actual[file]=sha(raw);assert actual[file]==rows[file] and oid==blobs[file] and kind=='blob',file
 assert offset==len(data)
 return actual,blobs

OTTO_SOURCE='aecaaa206a2269f15cd00b347f6bbae2fe46de04'
OTTO_REF='refs/heads/cuttle/selim-input-before'
OWNER='433a743a-eb04-4066-8251-791c89e978e3'
REVIEWER='d750bb0b-a1e2-42b2-833b-1598278fc31b'
OPERATOR='433a743a-eb04-4066-8251-791c89e978e3'
ORIGINAL_PLAN='5e25986dcba6dae291e28f657a3fdadac76b25f189859850bcb8798c011e5b88'
ORIGINAL_REQUEST='455a97629936dc885aeb43bf2ca44e1f49ab3225c4c015a2a9a33cd54278a86b'
PROFILE_BASIS='8eb0af645befdd9c250e8716ab9adabfeeb65fc2044a33852e0d3eaad2aacb06'

def validate_lineage(plan,resolved,original,source_ref):
 assert source_ref==OTTO_REF and plan['source']==original['source']==OTTO_SOURCE,'Reviewed source/ref drift'
 assert plan['expectedInputsRef']['count']==4893
 assert resolved['expectedInputs']==original['expectedInputs'] and resolved['sourceBlobs']==original['sourceBlobs'],'Audited original maps differ'
 allowed={'name','payloadFile','executionHold','ownerSelection','sourceReview','expectedInputsRef','expectedInputs','sourceBlobs'}
 assert set(plan)-set(original)<={'expectedInputsRef','ownerSelection'},'Unsupported plan extension'
 assert set(original)-set(plan)=={'expectedInputs','sourceBlobs'},'Unsupported plan removal'
 for key in set(original)-allowed:assert plan[key]==original[key],f'Unapproved plan delta: {key}'
 assert plan['tests']==['npc-dialogue-event-entrypoints.test.cjs', 'quest-dialogue.test.cjs', 'quest-plugins.test.cjs']
 assert plan['expectedTestCounts']=={'npc-dialogue-event-entrypoints.test.cjs': 190, 'quest-dialogue.test.cjs': 194, 'quest-plugins.test.cjs': 424}

def build_authority_subject(plan,plan_sha,bindings,bindings_sha,selection_sha,caller_sha):
 return {'source':OTTO_SOURCE,'sourceRef':OTTO_REF,'originalPlanSHA256':ORIGINAL_PLAN,'originalRequestSHA256':ORIGINAL_REQUEST,'planSHA256':plan_sha,'manifestSHA256':plan['expectedInputsRef']['sha256'],'count':4893,'tests':plan['tests'],'expectedTestCounts':plan['expectedTestCounts'],'callerSHA256':caller_sha,'submitCallerSHA256':bindings['submitCaller']['sha256'],'payloadSHA256':bindings['payload']['sha256'],'bindingsSHA256':bindings_sha,'profileBasisSHA256':PROFILE_BASIS,'selectionSHA256':selection_sha,'snapshotChildSHA256':'1aa6b38fa85b95993851f45a524fec2fd8aebb0e192e050fbd8bfd8e899dba11','sdkVerifierSHA256':'e47594c5e8c9858111312b194c3659ba98d927672968eba56e44cccedaa717be','sdkManifestSHA256':'8d40023673b396fc7f507e3ff39fdcef1f7e416aa649ece34c92949d56b297d6','collectionCallerSHA256':'28e814035f5551ae12c3ccb082b2065767e0812f2e1a3a8212dd792949d3e968','collectionContractSHA256':'f38306f3da67d45e7469876abbded1c6c144d3b1656dbf3e455682ec47736394','collectorBindingSHA256':'04b0f3f8f36e0bf016d2e25c6742bdc7bea822277b4b16904e11cc739e748c2b','cuttleRetrievalSHA256':'97f8f38f116c5bdc0066a2a26e9f94207792c7a3286fa4df9626ec206ae339a3','providerSnapshotSHA256':'597fcf35082e415aa9a79afa90ec057d40dfaa29231df046ff34f571018b8604','evidenceValidatorSHA256':'888801e5a9fd6c74419dc34f58f79ed971a87b535c5f00a6abfb726520033c65','localScanSHA256':'fdd259968d92183d0b1cefd584e457ddb8ac7efce964362fd4513215bcfdfff8','executorBindingSHA256':'b38e5180e2e8618cabf56086e6a54a44fd21f6c7130ac7b5c73cbd47b31da2c9'}

def verify_subject_pair(expected,receipt_subject,authority_subject):
 assert receipt_subject==expected and authority_subject==expected,'Current plan/review subject mismatch'

def validate_authority(record,subject):
 raise RuntimeError('HELD: supported authenticated direct-session acquisition and delivery correlation not yet bound')

def validate_reconciliation(record,plan_sha,selection_sha):
 raise RuntimeError('HELD: authenticated complete provider snapshots and freshness not yet bound')

def correlate_review_content(subject,nonce,send_response,outgoing_text):
 # Real-time CLI acquisition is authenticated; passed send_response is NOT authenticated here.
 import types
 def load_pinned(path,digest):
  raw=bound(path,digest);mod=types.ModuleType('case_guard');exec(compile(raw,str(path),'exec'),mod.__dict__);return mod
 retrieval=load_pinned(HF/'cuttle-review-retrieval.py','97f8f38f116c5bdc0066a2a26e9f94207792c7a3286fa4df9626ec206ae339a3')
 validator=load_pinned(HF/'review-evidence-validators.py','888801e5a9fd6c74419dc34f58f79ed971a87b535c5f00a6abfb726520033c65')
 capture=retrieval.retrieve()
 validator.validate_review_content(subject,capture['parentIdentity']['document'],capture['parentTranscript']['document'],capture['ownerIdentity']['document'],capture['ownerTranscript']['document'],send_response,outgoing_text,nonce)
 return capture

def live_provider_check(plan,plan_path,plan_sha,payload_sha):
 # Future post-review use only: execute verified nonsecret snapshots with auth004.
 import types
 def load_pinned(path,digest):
  raw=bound(path,digest); mod=types.ModuleType('case_guard');mod.__file__=str(path);exec(compile(raw,str(path),'exec'),mod.__dict__);return mod
 executor=json.loads(bound(HF/'executor-binding.json','b38e5180e2e8618cabf56086e6a54a44fd21f6c7130ac7b5c73cbd47b31da2c9'))
 assert executor['executor']==OWNER and sha(Path(executor['python']).read_bytes())==executor['pythonSha256']
 bound(executor['sdkReceipt'],executor['sdkReceiptSha256'])
 helper=load_pinned(HF/'authenticated-child-snapshot-command.py','00ff45d75be1eae3bc8f04995cfb8bcbe2bc5adc28c1162b843cfe88c87024f9')
 sdkguard=load_pinned(HF/'sdk-verify.py','e47594c5e8c9858111312b194c3659ba98d927672968eba56e44cccedaa717be')
 sdkguard.verify(bound(HF/'sdk-file-manifest.json','8d40023673b396fc7f507e3ff39fdcef1f7e416aa649ece34c92949d56b297d6'),executor['sdkTarget'])
 validator=load_pinned(HF/'review-evidence-validators.py','888801e5a9fd6c74419dc34f58f79ed971a87b535c5f00a6abfb726520033c65')
 command=helper.authenticated_pilot_command(executor['python'],HF/'hf-project-access-v4.py','fab4bc92dc8601143ce61e910f8121774c22a0d19be6d2617bba9449f7131326',HF/'provider-snapshot.py','597fcf35082e415aa9a79afa90ec057d40dfaa29231df046ff34f571018b8604',plan_path,executor['sdkTarget'])
 safe=load_pinned(HF/'snapshot-child.py','1aa6b38fa85b95993851f45a524fec2fd8aebb0e192e050fbd8bfd8e899dba11')
 command=safe.protect_auth_command(command,helper.CHILD_BOOTSTRAP,plan_path,plan_sha,HF/'native-payload-mapref-candidate.cjs',payload_sha)
 result=subprocess.run(command,capture_output=True,check=True,timeout=120)
 capture=json.loads(result.stdout);validator.validate_provider_content(capture,plan['source'],plan['name'])
 return capture

def scan_case_custody():
 import types
 file=HF/'nested-custody-scan.py'; raw=bound(file,'fdd259968d92183d0b1cefd584e457ddb8ac7efce964362fd4513215bcfdfff8')
 mod=types.ModuleType('nested_custody_scan'); exec(compile(raw,str(file),'exec'),mod.__dict__)
 result=mod.scan(['/workspace/selim-notes','/workspace/selim-custody','/workspace/selim-custody-selim-partisan'])
 assert not result['errors'] and not result['skippedSymlinkDirectories'], 'Local custody scan incomplete'
 assert not result['found'], 'Local custody evidence exists: reconcile before continuing'
 return result

def validate_binding_bundle(bindings,plan,plan_dir):
 required={'payload','resolver','pilot','package','caller','originalPlan','originalRequest','profileBasis','originalD46','submitCaller','inputCollector'};assert set(bindings)==required
 required_paths={'payload':HF/'native-payload-mapref-candidate.cjs','resolver':HF/'input-manifest-resolver.cjs','pilot':HF/'pilot.py','package':HF/'package.json','caller':Path(__file__).resolve(),'originalPlan':ROOT/'original-selim-full-plan.json','originalRequest':ROOT/'original-selim-request.json','profileBasis':HF/'profile-basis.json','originalD46':HF/'native-payload-failure-seals.cjs','submitCaller':ROOT/'submit-selim.py','inputCollector':HF/'retain-contiguous-inputs003.py'}
 for key in required:
  entry=bindings[key];assert set(entry)=={'path','sha256'} and (WS/entry['path']).resolve()==required_paths[key]
  bound(required_paths[key],entry['sha256'])
 assert (plan_dir/plan['payloadFile']).resolve()==required_paths['payload']
 return required_paths

def main():
 raise RuntimeError('HELD: Selim auth004, current namespace reconciliation and case caller review are not yet bound')
 p=argparse.ArgumentParser(description=__doc__)
 for name in ['plan','mirror','bindings','selection','authority','reconciliation','output']:p.add_argument('--'+name,type=Path,required=True)
 for name in ['plan-sha256','bindings-sha256','selection-sha256','authority-sha256','reconciliation-sha256','source-ref']:p.add_argument('--'+name,required=True)
 a=p.parse_args();output=a.output.resolve();assert output.is_relative_to(ROOT) and not output.exists(),'New isolated receipt output only'
 plan=json.loads(bound(a.plan,a.plan_sha256));assert not plan.get('executionHold'),'Not selected'
 bound(HF/'executor-binding.json','b38e5180e2e8618cabf56086e6a54a44fd21f6c7130ac7b5c73cbd47b31da2c9')
 url=reference_url(plan)
 selection=json.loads(bound(a.selection,a.selection_sha256));assert selection['action']=='SELECT_ONCE' and selection['attempts']==1
 assert selection['source']==plan['source'] and selection['planSHA256']==a.plan_sha256 and selection['manifestSHA256']==plan['expectedInputsRef']['sha256'] and selection['count']==plan['expectedInputsRef']['count'] and selection['tests']==plan['tests']
 assert selection['owner']==plan['ownerSelection']['owner']
 bindings=json.loads(bound(a.bindings,a.bindings_sha256))
 required_paths=validate_binding_bundle(bindings,plan,a.plan.parent)
 assert bindings['originalPlan']['sha256']==ORIGINAL_PLAN and bindings['originalRequest']['sha256']==ORIGINAL_REQUEST and bindings['profileBasis']['sha256']==PROFILE_BASIS
 assert bindings['originalD46']['sha256']=='d46b3773c4bb3134920efa29074f9f2e6d9cf06e99b27b28cc909a222aa67620'
 original=read(required_paths['originalPlan']);request=read(required_paths['originalRequest'])
 assert request['source']==OTTO_SOURCE and request['forkRef']==OTTO_REF
 assert selection['owner']==OWNER
 subject=build_authority_subject(plan,a.plan_sha256,bindings,a.bindings_sha256,a.selection_sha256,sha(Path(__file__).read_bytes()))
 authority=json.loads(bound(a.authority,a.authority_sha256));validate_authority(authority,subject)
 reconciliation=json.loads(bound(a.reconciliation,a.reconciliation_sha256));validate_reconciliation(reconciliation,a.plan_sha256,a.selection_sha256)
 reviews=authority['reviewArtifacts']
 basis=read(required_paths['profileBasis'])
 for key in ['image','flavor','timeout','attempts','expectedCacheFiles']:assert plan[key]==basis[key],key
 assert plan['timeout']==1800 and plan['attempts']==1
 # Resolve remote and mirror before source fetch/guard; failure has no runtime seals.
 mirror=bound(a.mirror,plan['expectedInputsRef']['sha256']);mirrorResolved=resolve_bytes(plan,mirror)
 validate_lineage(plan,mirrorResolved,original,a.source_ref)
 opener=urllib.request.build_opener(NoRedirect())
 with opener.open(url,timeout=60) as response:
  assert response.status==200 and response.geturl()==url
  remote=response.read(plan['expectedInputsRef']['bytes']+1)
 assert remote==mirror,'Downloaded immutable manifest differs from reviewed mirror'
 resolved=resolve_bytes(plan,remote)
 local_scan=scan_case_custody()
 provider_capture=live_provider_check(plan,a.plan,a.plan_sha256,bindings['payload']['sha256'])
 repo=Path('/workspace/selim-custody');fork=f"https://github.com/{plan['repository']}.git"
 subprocess.run(['git','-C',str(repo),'-c','maintenance.auto=false','-c','gc.auto=0','fetch','--refmap=','--no-write-fetch-head','--no-tags',fork,plan['source']],check=True,capture_output=True)
 remote_ref=subprocess.check_output(['git','ls-remote',fork,a.source_ref]).decode().strip();assert remote_ref.split()[0]==plan['source']
 with urllib.request.urlopen(urllib.request.Request(f"https://codeload.github.com/{plan['repository']}/tar.gz/{plan['source']}",method='HEAD'),timeout=40) as response:assert response.status==200
 rows,blobs=verify_git(plan,resolved)
 executor=json.loads(bound(HF/'executor-binding.json','b38e5180e2e8618cabf56086e6a54a44fd21f6c7130ac7b5c73cbd47b31da2c9'))
 import types
 def preview_module(file,digest):
  raw=bound(file,digest);mod=types.ModuleType('preview_guard');exec(compile(raw,str(file),'exec'),mod.__dict__);return mod
 sdkguard=preview_module(HF/'sdk-verify.py','e47594c5e8c9858111312b194c3659ba98d927672968eba56e44cccedaa717be');sdkguard.verify(bound(HF/'sdk-file-manifest.json','8d40023673b396fc7f507e3ff39fdcef1f7e416aa649ece34c92949d56b297d6'),executor['sdkTarget'])
 snapshot=preview_module(HF/'snapshot-child.py','1aa6b38fa85b95993851f45a524fec2fd8aebb0e192e050fbd8bfd8e899dba11')
 preview=snapshot.preview_command(executor['python'],executor['pythonSha256'],HF/'pilot.py',bindings['pilot']['sha256'],a.plan,a.plan_sha256,HF/'native-payload-mapref-candidate.cjs',bindings['payload']['sha256'],executor['sdkTarget'])
 rendered=json.loads(subprocess.check_output(preview))
 assert rendered['plan']==plan
 command=rendered['request']['command'];sizes=[len(x.encode())+1 for x in command];assert all(x<131072 for x in sizes)
 output.mkdir();(output/'downloaded-manifest.json').write_bytes(remote)
 (output/'resolved-maps.json').write_text(json.dumps(resolved,indent=2)+'\n')
 (output/'request-preview.json').write_text(json.dumps(rendered,indent=2)+'\n')
 receipt={'stage':'SELECTED_REFERENCE_PRESTART_CHECKED_NO_JOB_API','source':plan['source'],'manifest':resolved['provenance'],'count':len(rows),'freshInputs':rows,'freshGitBlobs':blobs,'bindings':bindings,'reviews':reviews,'selectionSHA256':a.selection_sha256,'selectionPath':str(a.selection.resolve()),'bindingsPath':str(a.bindings.resolve()),'bindingsSHA256':a.bindings_sha256,'planSHA256':a.plan_sha256,'forkReadback':remote_ref,'codeloadHEAD':200,'localDuplicateScan':'CLEAR','localScan':local_scan,'providerCapture':provider_capture,'normalReconciliationSHA256':a.reconciliation_sha256,'authoritySHA256':a.authority_sha256,'authoritySubject':subject,'normalReconciliationScope':'Retained operator selected-source/name check only, not global provider census','prestartCallerSHA256':sha(Path(__file__).read_bytes()),'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selectedPlanPath':str(a.plan.resolve()),'argumentBytesInclNUL':sizes,'programSHA256':sha(command[-1].encode()),'noJobAPI':True,'sourceRuntimeSeals':'NOT_AVAILABLE: prestart only, no runtime source/install/test occurred'}
 (output/'prestart-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'stage':receipt['stage'],'count':len(rows),'argumentBytesInclNUL':sizes}))
if __name__=='__main__':main()
