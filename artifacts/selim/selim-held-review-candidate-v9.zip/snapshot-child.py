"""Construct verified source/data-snapshot child commands; no job or provider action."""
from pathlib import Path
import hashlib,base64,json

NO_BYTECODE = '''import sys,importlib.machinery
sys.dont_write_bytecode=True
def _source_only_get_code(self,fullname):
 path=self.get_filename(fullname)
 _candidate=globals().get('_data',{}).get(path)
 return self.source_to_code(_candidate if _candidate is not None else self.get_data(path),path)
def _deny_sourceless(self,fullname):
 raise ImportError('sourceless bytecode imports disabled')
importlib.machinery.SourceFileLoader.get_code=_source_only_get_code
importlib.machinery.SourcelessFileLoader.get_code=_deny_sourceless
'''
SNAPSHOT_READS = '''import sys,base64,hashlib,json,os
from pathlib import Path
_encoded=sys.argv.pop(1);_expected=sys.argv.pop(1)
_raw=base64.b64decode(_encoded,validate=True)
if hashlib.sha256(_raw).hexdigest()!=_expected:raise SystemExit(1)
_rows=json.loads(_raw);_data={}
for _row in _rows:
 _bytes=base64.b64decode(_row['bytes'],validate=True)
 if hashlib.sha256(_bytes).hexdigest()!=_row['sha256']:raise SystemExit(1)
 if _row['path'] in _data:raise SystemExit(1)
 _data[_row['path']]=_bytes
_old_text=Path.read_text;_old_bytes=Path.read_bytes;_old_resolve=Path.resolve
def _bound_resolve(self,strict=False):
 _path=os.path.abspath(self)
 return Path(_path) if _path in _data else _old_resolve(self,strict=strict)
Path.resolve=_bound_resolve
def _bound_bytes(self):
 _path=str(self.resolve())
 return _data[_path] if _path in _data else _old_bytes(self)
def _bound_text(self,encoding=None,errors=None):
 _path=str(self.resolve())
 if _path in _data:return _data[_path].decode(encoding or 'utf-8',errors or 'strict')
 return _old_text(self,encoding=encoding,errors=errors)
Path.read_bytes=_bound_bytes;Path.read_text=_bound_text
'''
PREVIEW = '''import sys,base64,hashlib,types
from pathlib import Path
snapshot=base64.b64decode(sys.argv.pop(1),validate=True)
digest=sys.argv.pop(1)
filename=sys.argv.pop(1)
sdk_target=sys.argv.pop(1)
if hashlib.sha256(snapshot).hexdigest()!=digest:raise SystemExit(1)
if sdk_target:sys.path.insert(0,sdk_target)
sys.path.insert(0,str(Path(filename).parent))
sys.argv[0]=filename
module=types.ModuleType('__main__')
module.__dict__.update(__file__=filename,__name__='__main__',__package__='',__spec__=None,__cached__=None)
sys.modules['__main__']=module
exec(compile(snapshot,filename,'exec'),module.__dict__)
'''

def capture_reads(plan_path,plan_sha256,payload_file,payload_sha256,extra_reads=()):
    plan_path=Path(plan_path).resolve();payload_file=Path(payload_file).resolve()
    plan=plan_path.read_bytes();payload=payload_file.read_bytes()
    if hashlib.sha256(plan).hexdigest()!=plan_sha256 or hashlib.sha256(payload).hexdigest()!=payload_sha256:raise ValueError('plan/payload pin')
    parsed=json.loads(plan)
    if (plan_path.parent/parsed['payloadFile']).resolve()!=payload_file:raise ValueError('plan/payload path')
    rows=[{'path':str(p),'sha256':h,'bytes':base64.b64encode(b).decode()} for p,h,b in ((plan_path,plan_sha256,plan),(payload_file,payload_sha256,payload))]
    for path,digest in extra_reads:
        path=Path(path).resolve();data=path.read_bytes()
        if hashlib.sha256(data).hexdigest()!=digest or str(path) in {row['path'] for row in rows}:raise ValueError('extra file pin or duplicate')
        rows.append({'path':str(path),'sha256':digest,'bytes':base64.b64encode(data).decode()})
    raw=json.dumps(rows,separators=(',',':')).encode();return base64.b64encode(raw).decode(),hashlib.sha256(raw).hexdigest()

def preview_command(python,python_sha256,pilot_file,pilot_sha256,plan_path,plan_sha256,payload_file,payload_sha256,sdk_target):
    executable=Path(python).resolve();raw=executable.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=python_sha256:raise ValueError('interpreter pin')
    pilot_file=Path(pilot_file).resolve();snapshot=pilot_file.read_bytes()
    if hashlib.sha256(snapshot).hexdigest()!=pilot_sha256:raise ValueError('pilot pin')
    reads,reads_sha=capture_reads(plan_path,plan_sha256,payload_file,payload_sha256)
    cmd=[str(executable),'-I','-B','-X','pycache_prefix=/dev/null','-c',NO_BYTECODE+SNAPSHOT_READS+PREVIEW,reads,reads_sha,base64.b64encode(snapshot).decode(),pilot_sha256,str(pilot_file),str(Path(sdk_target).resolve()),'--plan',str(Path(plan_path).resolve())]
    if any('\0' in a or len(a.encode())+1>=131072 for a in cmd):raise ValueError('argv bound')
    return cmd

def protect_auth_command(command,expected_bootstrap,plan_path,plan_sha256,payload_file,payload_sha256,extra_reads=()):
    if len(command)<3 or command[1]!='-c' or command[2]!=expected_bootstrap:raise ValueError('unexpected auth helper command')
    reads,reads_sha=capture_reads(plan_path,plan_sha256,payload_file,payload_sha256,extra_reads)
    cmd=[command[0],'-I','-B','-X','pycache_prefix=/dev/null','-c',NO_BYTECODE+SNAPSHOT_READS+expected_bootstrap,reads,reads_sha,*command[3:]]
    if any('\0' in a or len(a.encode())+1>=131072 for a in cmd):raise ValueError('argv bound')
    return cmd
