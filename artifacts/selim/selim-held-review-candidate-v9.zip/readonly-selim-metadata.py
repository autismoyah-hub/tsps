"""Read-only namespace metadata; no inspect, logs, selection or job submission."""
import argparse,json,datetime
from pathlib import Path
NAMESPACE='Autismo-Yah'

def collect(api,plan):
 queries={'project':{'project':'tsps'}}
 for phase in ('before','after'):
  queries[phase+'-source']={'project':'tsps','source':plan[phase]['source']}
  queries[phase+'-name']={'project':'tsps','name':plan[phase]['name']}
 result={}
 for key,labels in queries.items():
  rows=[]
  for job in api.list_jobs(namespace=NAMESPACE,labels=labels):
   if len(rows)>=100000:raise RuntimeError('provider query exceeded complete bound')
   stage=getattr(getattr(job,'status',None),'stage',None);stage=getattr(stage,'value',stage)
   rows.append({'id':getattr(job,'id',None),'owner':getattr(getattr(job,'owner',None),'name',None),'stage':stage,'labels':getattr(job,'labels',None)})
  result[key]={'labels':labels,'complete':True,'rows':rows}
 return {'namespace':NAMESPACE,'project':'tsps','complete':True,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queries':result}

def main():
 p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);args=p.parse_args();plan=json.loads(args.plan.read_bytes())
 from huggingface_hub import HfApi
 print(json.dumps(collect(HfApi(),plan)))

if __name__=='__main__':main()
