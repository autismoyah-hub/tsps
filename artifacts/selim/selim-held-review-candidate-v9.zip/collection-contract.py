"""Future same-job collection gate; no provider call or action entrypoint."""
import hashlib,json

def validate_collection(submission, prestart, binding, plan, plan_bytes, operator):
    if operator!='433a743a-eb04-4066-8251-791c89e978e3':raise ValueError('collector identity')
    digest=hashlib.sha256(plan_bytes).hexdigest()
    if json.loads(plan_bytes)!=plan:raise ValueError('plan bytes')
    if submission.get('stage')!='SUBMITTED' or submission.get('namespace')!='Autismo-Yah' or submission.get('plan')!=plan:raise ValueError('submission identity')
    job=submission.get('job');job_id=job.get('id') if isinstance(job,dict) else None
    if not isinstance(job_id,str) or not job_id:raise ValueError('ambiguous job; hold')
    if binding.get('jobId')!=job_id or binding.get('planSHA256')!=digest or binding.get('renderedEqualsSubmittedEqualsReturned') is not True:raise ValueError('job binding')
    if prestart.get('planSHA256')!=digest or prestart.get('source')!=plan.get('source') or prestart.get('noJobAPI') is not True:raise ValueError('prestart binding')
    if submission.get('request',{}).get('command')!=job.get('command'):raise ValueError('returned command drift')
    return job_id
