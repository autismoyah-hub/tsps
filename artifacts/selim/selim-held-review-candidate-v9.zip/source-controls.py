import pathlib,importlib.util,hashlib,tempfile,json,sys
R=pathlib.Path(__file__).resolve().parent
for name in ('nested-custody-scan','authenticated-child-snapshot-command'):
 path=R/(name+'.py');spec=importlib.util.spec_from_file_location(name.replace('-','_'),path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 if name.startswith('nested'):
  with tempfile.TemporaryDirectory() as t:
   root=pathlib.Path(t); (root/'a'/'b').mkdir(parents=True);(root/'a'/'b'/'submission.json').write_text('{}'); result=m.scan([root]);assert len(result['found'])==1 and not result['errors'] and not result['skippedSymlinkDirectories']
   (root/'linked').symlink_to(root/'a',target_is_directory=True);assert m.scan([root])['skippedSymlinkDirectories']
  print('nested scan: nested intent found; skipped symlink disclosed')
 else:
  sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest(); access=R/'hf-project-access-v4.py'; pilot=R/'pilot.py';plan=R/'before'/'pilot.json';cmd=m.authenticated_pilot_command(sys.executable,access,sha(access),pilot,sha(pilot),plan,'/workspace/selim-notes/author-sdk/site-packages');assert cmd[-3:]==['--','--plan',str(plan)] and all(len(a.encode())+1<131072 for a in cmd)
  try:m.authenticated_pilot_command(sys.executable,access,'0'*64,pilot,sha(pilot),plan)
  except RuntimeError:pass
  else:raise AssertionError('bad auth digest accepted')
  print('auth child argv: pinned sources accepted, changed digest rejected; child not executed')
for phase in ('before','after'):
 for name in ('prestart-selim.py','submit-selim.py'):
  src=(R/phase/name).read_text();compile(src,str(R/phase/name),'exec');assert "raise RuntimeError('HELD:" in src
print('candidate callers compile; held guards present; no main invoked')
# Inject only the subprocess boundary of the helper; no child/main/provider is invoked.
import datetime,types
for phase in ('before','after'):
 d=R/phase;spec=importlib.util.spec_from_file_location('candidate_'+phase,d/'prestart-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);plan=json.loads((d/'pilot.json').read_bytes())
 queries={k:{'labels':labels,'complete':True,'rows':[]} for k,labels in {'project':{'project':'tsps'},'source':{'project':'tsps','source':plan['source']},'name':{'project':'tsps','name':plan['name']}}.items()}
 capture={'namespace':'Autismo-Yah','project':'tsps','complete':True,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queries':queries}
 original=m.subprocess.run;seen=[]
 def fake(argv,**kwargs):
  seen.append(argv);assert kwargs['check'] is True and kwargs['capture_output'] is True
  return types.SimpleNamespace(stdout=json.dumps(capture).encode())
 try:
  m.subprocess.run=fake;assert m.live_provider_check(plan,d/'pilot.json',hashlib.sha256((d/'pilot.json').read_bytes()).hexdigest(),hashlib.sha256((R/'native-payload-mapref-candidate.cjs').read_bytes()).hexdigest())==capture;assert len(seen)==1 and seen[0][-3:]==['--','--plan',str(d/'pilot.json')]
  capture['queries']['project']['complete']=False
  try:m.live_provider_check(plan,d/'pilot.json',hashlib.sha256((d/'pilot.json').read_bytes()).hexdigest(),hashlib.sha256((R/'native-payload-mapref-candidate.cjs').read_bytes()).hexdigest())
  except ValueError:pass
  else:raise AssertionError('partial live snapshot accepted')
 finally:m.subprocess.run=original
 print(phase,'pinned live-provider composition: synthetic empty positive and incomplete negative; no subprocess executed')
for phase in ('before','after'):
 d=R/phase;spec=importlib.util.spec_from_file_location('corrupt_'+phase,d/'prestart-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);plan=json.loads((d/'pilot.json').read_bytes())
 original_bound=m.bound;original_run=m.subprocess.run;calls=[]
 def corrupt_validator(path,digest):
  return original_bound(path,'0'*64 if pathlib.Path(path).name=='review-evidence-validators.py' else digest)
 def forbidden_run(*a,**kw):calls.append(a);raise AssertionError('unexpected subprocess')
 try:
  m.bound=corrupt_validator;m.subprocess.run=forbidden_run
  for fn in (lambda:m.live_provider_check(plan,d/'pilot.json',hashlib.sha256((d/'pilot.json').read_bytes()).hexdigest(),hashlib.sha256((R/'native-payload-mapref-candidate.cjs').read_bytes()).hexdigest()),lambda:m.correlate_review_content({},'n'*32,{},'{}')):
   try:fn()
   except AssertionError as e:
    if str(e)=='unexpected subprocess':raise
   else:raise AssertionError('corrupt transitive pin accepted')
  assert not calls
 finally:m.bound=original_bound;m.subprocess.run=original_run
 print(phase,'corrupted transitive validator pin rejected in both composed paths before subprocess')
import shlex
for phase in ('before','after'):
 d=R/phase;spec=importlib.util.spec_from_file_location('correlate_'+phase,d/'prestart-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 owner='433a743a-eb04-4066-8251-791c89e978e3';parent='d750bb0b-a1e2-42b2-833b-1598278fc31b';nonce='n'*32;subject={'source':'a'*40};outgoing=json.dumps({'nonce':nonce,'verdict':'EXACT_INPUT_PROFILE_GO','subject':subject});stamp=datetime.datetime.now(datetime.timezone.utc).isoformat();command=shlex.join(['cuttle','--json','sessions','send',owner,outgoing]);tool_id='synthetic-send'
 parent_turns=[{'role':'assistant','kind':'tool','ts':stamp,'tool':{'id':tool_id,'input':json.dumps({'command':command})}},{'role':'user','kind':'tool_result','ts':stamp,'tool':{'id':tool_id,'ok':True}}];owner_turns=[{'role':'user','ts':stamp,'text':'[From Cuttle session "reviewer" · '+parent+']\n'+outgoing}]
 original=m.subprocess.run;seen=[]
 def fake(argv,**kwargs):
  seen.append(argv);assert argv[:2]==['cuttle','--json'];identity=argv[-1]
  data={'id':identity} if argv[2:4]==['sessions','get'] else {'turns':parent_turns if identity==parent else owner_turns}
  return types.SimpleNamespace(stdout=json.dumps(data).encode())
 try:
  m.subprocess.run=fake;result=m.correlate_review_content(subject,nonce,{'ok':True,'sessionId':owner},outgoing);assert len(seen)==4 and result['ownerIdentity']['document']['id']==owner
  try:m.correlate_review_content(subject,nonce,{'ok':False,'sessionId':owner},outgoing)
  except ValueError:pass
  else:raise AssertionError('invalid send response accepted')
 finally:m.subprocess.run=original
 print(phase,'composed review-correlation synthetic positive and bad response negative; no subprocess executed')
