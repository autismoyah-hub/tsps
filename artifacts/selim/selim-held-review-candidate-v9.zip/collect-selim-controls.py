"""Synthetic collector command construction; no main, child or provider invocation."""
import pathlib,tempfile,hashlib,json,importlib.util,copy,datetime
R=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('collect',R/'collect-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest();operator='433a743a-eb04-4066-8251-791c89e978e3';executor=json.loads((R/'executor-binding.json').read_bytes());names={'collectionContract':'collection-contract.py','sdkVerifier':'sdk-verify.py','sdkManifest':'sdk-file-manifest.json','authChild':'authenticated-child-snapshot-command.py','snapshotChild':'snapshot-child.py','authAccess':'hf-project-access-v4.py','pilot':'pilot.py','payload':'native-payload-mapref-candidate.cjs','inspector':'inspect-selim-job.py','closure':'collection-closure.py','frameTransport':'frame_transport.py','retainResult':'retain-job-result.py'};pins={k:sha(R/v) for k,v in names.items()}
with tempfile.TemporaryDirectory() as t:
 plan={'source':'a'*40,'payloadFile':str(R/'native-payload-mapref-candidate.cjs'),'executionHold':None,'ownerSelection':{'owner':operator}};p=pathlib.Path(t)/'plan.json';p.write_text(json.dumps(plan));digest=sha(p);cmd=['node','-e','synthetic'];submission={'stage':'SUBMITTED','namespace':'Autismo-Yah','plan':plan,'request':{'command':cmd},'job':{'id':'synthetic-job','command':cmd}};prestart={'planSHA256':digest,'source':plan['source'],'noJobAPI':True};binding={'jobId':'synthetic-job','planSHA256':digest,'renderedEqualsSubmittedEqualsReturned':True}
 submission_path=pathlib.Path(t)/'submission.json';submission_path.write_text(json.dumps(submission));submission_sha=sha(submission_path);terminal={'namespace':'Autismo-Yah','jobId':'synthetic-job','stage':'COMPLETED','observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()};first=m.prepare_command(p,digest,submission_path,submission_sha,submission,prestart,binding,operator,executor,pins,None);assert first['command'] is None and first['inspectionCommand'][-2:]==['--job-id','synthetic-job'];result=m.prepare_command(p,digest,submission_path,submission_sha,submission,prestart,binding,operator,executor,pins,terminal);assert result['jobId']=='synthetic-job' and result['command'][-1]=='--collect' and result['command'][1:6]==['-I','-B','-X','pycache_prefix=/dev/null','-c']
 for label in ('operator','job','digest','contract','snapshot'):
  s,b,h=copy.deepcopy(submission),copy.deepcopy(binding),dict(pins);owner=operator
  if label=='operator':owner='wrong'
  if label=='job':b['jobId']='other'
  if label=='digest':b['planSHA256']='0'*64
  if label=='contract':h['collectionContract']='0'*64
  if label=='snapshot':h['snapshotChild']='0'*64
  try:m.prepare_command(p,digest,submission_path,submission_sha,s,prestart,b,owner,executor,h,terminal)
  except ValueError:pass
  else:raise AssertionError('accepted '+label)
print('collector synthetic same-job command construction and five corrupted identity/pin negatives passed; no child, main, provider or collection')
spec=importlib.util.spec_from_file_location('closure',R/'collection-closure.py');closure=importlib.util.module_from_spec(spec);spec.loader.exec_module(closure)
now=datetime.datetime.now(datetime.timezone.utc);good={'namespace':'Autismo-Yah','jobId':'synthetic-job','stage':'COMPLETED','observedUTC':now.isoformat()};assert closure.check_terminal(good,'synthetic-job')
for mutation in ({'stage':'RUNNING'},{'stage':'DELETED'},{'jobId':'other'},{'observedUTC':(now-datetime.timedelta(seconds=301)).isoformat()}):
 bad={**good,**mutation}
 try:closure.check_terminal(bad,'synthetic-job')
 except ValueError:pass
 else:raise AssertionError('invalid terminal accepted')
with tempfile.TemporaryDirectory() as t:
 case=pathlib.Path(t);intent=case/'collection-custody.json';closure.create_exclusive_intent(intent,'synthetic-job','a'*64,operator)
 try:closure.create_exclusive_intent(intent,'synthetic-job','a'*64,operator)
 except FileExistsError:pass
 else:raise AssertionError('duplicate custody accepted')
 before=closure.snapshot_names(case);(case/'status-20260101.json').write_text(json.dumps({'id':'synthetic-job','status':{'stage':'COMPLETED'}}));(case/'logs-20260101.txt').write_text('synthetic');result=closure.identify_collected(case,before,'synthetic-job');assert result['status']['path']=='status-20260101.json' and result['decodedManifest'] is None
 try:closure.identify_collected(case,before,'other')
 except ValueError:pass
 else:raise AssertionError('wrong collected job accepted')
print('synthetic terminal/unknown/stale, exclusive custody and exact status/log matching controls passed; no actual job inspected or collected')
spec=importlib.util.spec_from_file_location('inspect',R/'inspect-selim-job.py');inspect=importlib.util.module_from_spec(spec);spec.loader.exec_module(inspect)
from types import SimpleNamespace
class FakeApi:
 def __init__(self,id='synthetic-job',stage='COMPLETED',owner='Autismo-Yah'):self.row=SimpleNamespace(id=id,status=SimpleNamespace(stage=stage),owner=SimpleNamespace(name=owner))
 def inspect_job(self,job_id,namespace):return self.row
assert inspect.inspect(FakeApi(),'Autismo-Yah','synthetic-job')['stage']=='COMPLETED'
for api in (FakeApi(id='wrong'),FakeApi(stage='UNKNOWN'),FakeApi(owner='wrong')):
 try:inspect.inspect(api,'Autismo-Yah','synthetic-job')
 except ValueError:pass
 else:raise AssertionError('bad inspector row accepted')
print('synthetic inspector terminal positive and wrong job/stage/namespace negatives passed; no provider call')
