"""Case-owned nested local evidence discovery; not provider/global clearance."""
import hashlib,os
from pathlib import Path

def scan(roots):
 found=[]; errors=[]; skipped=[]
 def onerror(e):errors.append(str(e))
 for root in roots:
  root=Path(root)
  if not root.is_dir():errors.append(f'missing root: {root}');continue
  for base,dirs,files in os.walk(root,followlinks=False,onerror=onerror):
   for name in list(dirs):
    p=Path(base)/name
    if p.is_symlink():skipped.append(str(p));dirs.remove(name)
   for name in files:
    low=name.lower()
    if low=='submission.json' or (low.endswith('.json') and any(x in low for x in ('custody','intent','reconciliation'))):
     p=Path(base)/name
     try:
      if p.is_symlink():errors.append(f'symlink evidence: {p}');continue
      b=p.read_bytes();found.append({'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
     except OSError as e:errors.append(str(e))
 return {'roots':[str(x) for x in roots],'found':sorted(found,key=lambda r:r['path']),'errors':errors,'skippedSymlinkDirectories':skipped,'scope':'case-owned local roots only; no provider or global absence claim'}
