"""Future auth004 child: inspect one already admitted same job, no logs or writes."""
import argparse,json,datetime
from pathlib import Path

def inspect(api,namespace,job_id):
    job=api.inspect_job(job_id=job_id,namespace=namespace)
    stage=getattr(getattr(job,'status',None),'stage',None);stage=getattr(stage,'value',stage)
    owner=getattr(getattr(job,'owner',None),'name',None)
    if getattr(job,'id',None)!=job_id or owner!=namespace:raise ValueError('job identity mismatch')
    if stage not in {'COMPLETED','CANCELED','ERROR','DELETED','SCHEDULING','RUNNING'}:raise ValueError('unknown stage')
    return {'namespace':namespace,'jobId':job_id,'stage':stage,'observedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}

def main():
    p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);p.add_argument('--job-id',required=True);a=p.parse_args()
    # Exact plan data is supplied by the verified auth child snapshot mechanism.
    json.loads(a.plan.read_bytes())
    from huggingface_hub import HfApi
    print(json.dumps(inspect(HfApi(),'Autismo-Yah',a.job_id)))

if __name__=='__main__':main()
