"""Read live Cuttle session records; correlation does not authenticate a supplied send receipt."""
import subprocess,json,hashlib
PARENT='d750bb0b-a1e2-42b2-833b-1598278fc31b';OWNER='433a743a-eb04-4066-8251-791c89e978e3'

def retrieve(run=subprocess.run):
 result={}
 for key,argv in [('parentIdentity',['sessions','get',PARENT]),('parentTranscript',['sessions','read','--turns','500',PARENT]),('ownerIdentity',['sessions','get',OWNER]),('ownerTranscript',['sessions','read','--turns','500',OWNER])]:
  p=run(['cuttle','--json',*argv],capture_output=True,check=True,timeout=30)
  raw=p.stdout;result[key]={'sha256':hashlib.sha256(raw).hexdigest(),'document':json.loads(raw)}
 return result
