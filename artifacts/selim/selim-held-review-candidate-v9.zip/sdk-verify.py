"""Verify reviewed private SDK tree; no import, installation or provider contact."""
from pathlib import Path
import hashlib,json

def verify(raw,expected_root):
 doc=json.loads(raw);root=Path(expected_root)
 if doc.get('root')!=str(root) or doc.get('exclusion')!='__pycache__ and .pyc only' or not root.is_dir():raise ValueError('SDK root')
 actual={}
 for p in sorted(root.rglob('*')):
  if '__pycache__' in p.parts or p.suffix=='.pyc':continue
  if p.is_symlink():raise ValueError('SDK symlink')
  if p.is_file():actual[p.relative_to(root).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
 if actual!=doc.get('files'):raise ValueError('SDK content mismatch')
 return len(actual)
