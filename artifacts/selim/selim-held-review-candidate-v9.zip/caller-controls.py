import importlib.util,json,pathlib,hashlib,copy
R=pathlib.Path(__file__).resolve().parent
for phase in ('before','after'):
 D=R/phase; spec=importlib.util.spec_from_file_location('selim_'+phase,D/'prestart-selim.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 plan=json.loads((D/'pilot.json').read_text()); bindings=json.loads((D/'bindings.json').read_text()); original=json.loads((D/'original-selim-full-plan.json').read_text()); raw=(R.parent/f'selim-{phase}-manifest-draft-v1.json').read_bytes()
 assert len(bindings)==11 and plan['executionHold'] and plan['ownerSelection'] is None
 m.validate_binding_bundle(bindings,plan,D)
 resolved=m.resolve_bytes(plan,raw);m.validate_lineage(plan,resolved,original,m.OTTO_REF)
 for key in bindings:
  bad=copy.deepcopy(bindings);bad[key]['sha256']='0'*64
  try:m.validate_binding_bundle(bad,plan,D)
  except (AssertionError,FileNotFoundError):pass
  else:raise AssertionError('accepted corrupted '+key)
 print(phase,'11 bindings and lineage valid; all corrupted binding hashes rejected; main not called')
