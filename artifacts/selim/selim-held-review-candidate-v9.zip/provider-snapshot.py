"""Capture complete sanitized HF project/source/name listings through auth004 only."""
import argparse,json,datetime
from pathlib import Path
NAMESPACE='Autismo-Yah';PROJECT='tsps';LIMIT=100000

def collect(api,source,name):
    filters={'project':{'project':PROJECT},'source':{'project':PROJECT,'source':source},'name':{'project':PROJECT,'name':name}}
    out={}
    for key,labels in filters.items():
        rows=[]
        for job in api.list_jobs(namespace=NAMESPACE,labels=labels):
            if len(rows)>=LIMIT:raise RuntimeError('listing exceeds bound; incomplete')
            stage=getattr(getattr(job,'status',None),'stage',None);stage=getattr(stage,'value',stage)
            rows.append({'id':getattr(job,'id',None),'owner':getattr(getattr(job,'owner',None),'name',None),'stage':stage,'labels':getattr(job,'labels',None)})
        out[key]={'labels':labels,'complete':True,'rows':rows}
    return {'namespace':NAMESPACE,'project':PROJECT,'complete':True,'finishedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'queries':out}

def main():
    p=argparse.ArgumentParser();p.add_argument('--plan',type=Path,required=True);args=p.parse_args()
    plan=json.loads(args.plan.read_bytes())
    from huggingface_hub import HfApi
    print(json.dumps(collect(HfApi(),plan['source'],plan['name'])))

if __name__=='__main__':main()
