"""Conservative local custody/closure primitives; no provider operation."""
from pathlib import Path
import os,json,hashlib,datetime

TERMINAL={'COMPLETED','CANCELED','ERROR'}
def check_terminal(observation,job_id):
    if observation.get('namespace')!='Autismo-Yah' or observation.get('jobId')!=job_id or observation.get('stage') not in TERMINAL:raise ValueError('terminal observation absent, unknown or wrong job')
    try:age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(observation['observedUTC'])).total_seconds()
    except (KeyError,TypeError,ValueError):raise ValueError('terminal observation time')
    if not 0<=age<=300:raise ValueError('terminal observation stale')
    return True

def create_exclusive_intent(path,job_id,plan_sha,operator):
    if operator!='433a743a-eb04-4066-8251-791c89e978e3' or not job_id or len(plan_sha)!=64:raise ValueError('intent identity')
    data={'stage':'COLLECTION_OWNED_PENDING','jobId':job_id,'planSHA256':plan_sha,'operator':operator,'noAutomaticRetry':True}
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as f:json.dump(data,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    return data

def snapshot_names(case):
    case=Path(case)
    return {p.name for pattern in ('status-*.json','logs-*.txt','decoded-*') for p in case.glob(pattern)}

def identify_collected(case,before,job_id):
    case=Path(case);after=snapshot_names(case);new=after-before
    statuses=sorted(x for x in new if x.startswith('status-') and x.endswith('.json'))
    if len(statuses)!=1 or sorted(case.glob('status-*.json'))[-1].name!=statuses[0]:raise ValueError('ambiguous status set')
    status_path=case/statuses[0];status=json.loads(status_path.read_bytes());stage=status.get('status',{}).get('stage')
    if status.get('id')!=job_id or stage not in TERMINAL:raise ValueError('wrong job or nonterminal collected status')
    stamp=statuses[0][7:-5];log=case/('logs-'+stamp+'.txt');decoded=case/('decoded-'+stamp)
    if log.name not in new or not log.is_file():raise ValueError('missing new matching log')
    def info(p):
        b=p.read_bytes();return {'path':p.relative_to(case).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
    result={'jobId':job_id,'stage':stage,'status':info(status_path),'log':info(log),'newEntries':sorted(new),'decodedManifest':None}
    if decoded.name in new:
        manifest=decoded/'manifest.json'
        if not manifest.is_file():raise ValueError('incomplete decoded transport')
        result['decodedManifest']=info(manifest)
    return result
