﻿const assert=require('node:assert/strict');
const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const {spawnSync}=require('node:child_process');
const source=process.argv[2];assert.ok(source);
const root=fs.mkdtempSync(path.join(os.tmpdir(),'vm-pr3966-synthetic-'));
try {
 const scripts=path.join(root,'server/scripts'),defs=path.join(root,'server/data/definitions'),docs=path.join(root,'docs');for(const p of [scripts,defs,docs])fs.mkdirSync(p,{recursive:true});
 fs.copyFileSync(source,path.join(scripts,'import-osrs-shops.mjs'));fs.writeFileSync(path.join(defs,'shops.json'),'[]\n');
 const record=(currency,general_store,buys_at,change_per,items)=>({shop_info:{currency,general_store,buys_at,change_per},items,owners:[]});
 const data={"Synthetic coin":record('coins',false,600,20,[{id:1353,stock:3,sell:'200'},{id:1354,stock:3,sell:'N/A'},{id:1355,stock:3,sell:'100',currency:'Tokkul'}]),"Synthetic general":record('coins',true,400,30,[{id:1931,stock:3}]),"Dusuri's Star Shop":record('stardust',false,800,10,[{id:25539,stock:3,sell:'200'}]),"Mysterious Stranger (shop)":record('coins',false,600,20,[{id:22517,stock:3,sell:'1'}])};
 fs.writeFileSync(path.join(docs,'shops-items-by-shop.json'),JSON.stringify(data));
 function run(args=[]){const p=spawnSync(process.execPath,[path.join(scripts,'import-osrs-shops.mjs'),'--docs',docs,...args],{encoding:'utf8'});assert.equal(p.status,0,p.stderr);return p;}
 run();const first=fs.readFileSync(path.join(defs,'shops.json'));run();assert.deepEqual(fs.readFileSync(path.join(defs,'shops.json')),first);const check=run(['--check']);assert.match(check.stdout,/shops\.json is up to date/);assert.deepEqual(fs.readFileSync(path.join(defs,'shops.json')),first);
 const shops=JSON.parse(first),find=n=>shops.find(s=>s.name===n);const coin=find('Synthetic coin');assert.equal(coin.originalStock[0].price,200);assert.equal(coin.originalStock[1].price,undefined);assert.equal(coin.originalStock[2].price,undefined);assert.equal(coin.sellMultiplier,undefined);const general=find('Synthetic general');assert.equal(general.sellMultiplier,400);assert.equal(general.priceChangePer,30);const reward=find("Dusuri's Star Shop");assert.equal(reward.sellMultiplier,800);assert.equal(reward.priceChangePer,10);assert.ok(reward.prices);assert.equal(find('Mysterious Stranger (shop)').originalStock[0].price,75000);
 console.log('PASS: synthetic raw-sell, mismatch/unsupported, ITEM_PRICES, SHOP_PRICES, PR3966 sellPolicy and repeat/check byte identity');
} finally {fs.rmSync(root,{recursive:true,force:true});}
