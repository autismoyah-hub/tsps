import { Sound } from "../../../Sound";
import { Sounds } from "../../../Sounds";
import { ItemDefinition } from "../../../definition/ItemDefinition";
import { ShopCurrency, ShopDefinition } from "../../../definition/ShopDefinition";
import { Item } from "../../Item";
import { PlayerStatus } from "../../PlayerStatus";
import { Task } from "../../../task/Task";
import { TaskManager } from "../../../task/TaskManager";
import { PluginManager } from "../../../../plugins/PluginManager";
import { ItemIdentifiers } from "../../../../util/ItemIdentifiers";
import { Misc } from "../../../../util/Misc";
import { ShopIdentifiers } from "../../../../util/ShopIdentifiers";
import { encodeShopClose, encodeShopOpen } from "../../../../net/protocol/ClientProtocol";
import { PlayerSave } from "../../../entity/impl/player/persistence/PlayerSave";
import { Inventory } from "../impl/Inventory";

export interface ShopItemContainerAction {
    kind: "value" | "buy_sell" | "x";
    containerId: number;
    slot: number;
    itemId: number;
    amount: number;
}

export interface ShopCurrencyHandler {
    amount(player: any): number;
    add(player: any, amount: number): void;
    remove(player: any, amount: number): void;
    name: string;
    /** The inventory item the currency is paid in, if it is one. */
    itemId?: number;
    /**
     * How live shop messages name an amount of it ("trade sticks"). When set, price checks and
     * refusals use OSRS's wording: "Red topaz: currently costs 240 trade sticks.", "... shop will
     * buy for 120 trade sticks.", "You don't have enough trade sticks.".
     */
    unit?: string;
}

interface RuntimeShop {
    definition: ShopDefinition;
    originalAmounts: Map<number, number>;
    itemRestockTicks: Map<number, number>;
    itemPrices: Map<number, number>;
    stock: Map<number, number>;
    order: number[];
    originalSlotCount: number;
    changeTimers: Map<number, number>;
}

interface DisplayEntry {
    itemId: number;
    amount: number;
}

class ShopRestockTask extends Task {
    constructor() {
        super(1);
    }

    public execute(): void {
        if (!ShopManager.restockAll()) {
            this.stop();
        }
    }
}

export class ShopManager {
    public static readonly SHOP_INTERFACE_ID = 3824;
    public static readonly INVENTORY_INTERFACE_ID = 3823;
    public static readonly ITEMS_INTERFACE_ID = 3900;
    public static readonly MAIN_INTERFACE_ID = 300;
    public static readonly SIDE_INTERFACE_ID = 301;

    private static readonly NAME_INTERFACE_ID = 3901;
    private static readonly SCROLL_INTERFACE_ID = 29995;
    private static readonly MAX_SHOP_ITEMS = 1000;
    private static readonly MAX_ACTION_AMOUNT = 5000;
    private static readonly SALES_TAX = 0.85;
    private static readonly BLOOD_MONEY_SHOP_IDS = [13, 14, 27];
    /**
     * The quantity row (Value, Buy-1/5/10/50) sets varbit 6348, which the
     * cache scripts read to make an item's left-click "Value" or "Buy N".
     */
    private static readonly QUANTITY_VARBIT = 6348;
    private static readonly QUANTITY_MODE_BY_BUTTON = new Map([[5, 0], [8, 1], [10, 2], [12, 3], [14, 4]]);
    private static readonly QUANTITY_BY_MODE = [0, 1, 5, 10, 50];
    private static readonly QUANTITY_MODE_ATTRIBUTE = "shop:quantity-mode";
    private static readonly POINTS_ATTRIBUTE = "shop:points";
    private static readonly shopsById = new Map<number, RuntimeShop>();
    private static readonly activeShopByPlayer = new WeakMap<object, number>();
    private static readonly activeTargetByPlayer = new WeakMap<object, number>();
    private static readonly viewersByShopId = new Map<number, Set<any>>();
    private static restockTaskRunning = false;
    private static readonly currencyHandlers = new Map<string, ShopCurrencyHandler>();

    public static registerCurrency(name: string, handler: ShopCurrencyHandler): void {
        if (!name || !handler || typeof handler.amount !== "function" || typeof handler.add !== "function" || typeof handler.remove !== "function") {
            throw new Error(`Invalid shop currency registration: ${name}`);
        }
        this.currencyHandlers.set(name, handler);
    }

    public static registerItemCurrency(
        itemId: number,
        options?: { name?: string; aliases?: string[]; unit?: string }
    ): void {
        if (!Number.isInteger(itemId) || itemId <= 0) {
            throw new Error(`Invalid item shop currency: ${itemId}`);
        }
        const name =
            options?.name ??
            ItemDefinition.forId(itemId)?.getName?.() ??
            `Item ${itemId}`;
        const handler: ShopCurrencyHandler = {
            name,
            itemId,
            unit: options?.unit,
            amount: (player) =>
                Number(player?.getInventory?.()?.getAmount?.(itemId) ?? 0),
            add: (player, amount) => player?.getInventory?.()?.adds?.(itemId, amount),
            remove: (player, amount) =>
                player?.getInventory?.()?.deleteNumber?.(itemId, amount),
        };
        for (const key of [name, ...(options?.aliases ?? [])]) {
            if (typeof key === "string" && key.trim()) {
                this.registerCurrency(key.trim().toUpperCase(), handler);
            }
        }
    }

    public static initialize(): void {
        PlayerSave.persistAttribute(this.QUANTITY_MODE_ATTRIBUTE);
        this.reload();
    }

    public static reload(): number {
        this.shopsById.clear();
        for (const definition of ShopDefinition.all()) {
            this.shopsById.set(definition.getId(), this.createRuntimeShop(definition));
        }

        for (const shopId of Array.from(this.viewersByShopId.keys())) {
            if (!this.shopsById.has(shopId)) {
                for (const player of Array.from(this.viewersByShopId.get(shopId) ?? [])) {
                    this.close(player);
                }
                continue;
            }
            this.refresh(shopId);
        }
        return this.shopsById.size;
    }

    /**
     * Adds a shop a plugin owns, such as Rogue Trader's rune caskets for one player, without touching the stock of the
     * others (reload() would reset them all). Remove it with removeShop when its owner is done.
     */
    public static registerShop(definition: ShopDefinition): void {
        ShopDefinition.register(definition);
        this.shopsById.set(definition.getId(), this.createRuntimeShop(definition));
    }

    /** Whether a shop is registered under this id (a plugin's per-player shop, see registerShop). */
    public static hasShop(shopId: number): boolean {
        return this.shopsById.has(shopId);
    }

    /** Puts more of an item into a shop's stock; anything above its original amount falls back with the shop's restock timer. */
    public static addShopStock(shopId: number, itemId: number, amount: number): boolean {
        const shop = this.shopsById.get(shopId);
        if (!shop || !this.addStock(shop, itemId, amount)) {
            return false;
        }
        this.refresh(shopId);
        this.ensureRestockTask();
        return true;
    }

    public static removeShop(shopId: number): void {
        for (const player of Array.from(this.viewersByShopId.get(shopId) ?? [])) {
            this.close(player);
        }
        this.shopsById.delete(shopId);
        this.viewersByShopId.delete(shopId);
        ShopDefinition.unregister(shopId);
    }

    public static open(
        player: any,
        shopId: number,
        resetScroll = true,
        targetUid = (161 << 16) | 16
    ): boolean {
        const shop = this.shopsById.get(shopId);
        if (!player || !shop) {
            return false;
        }
        if (PluginManager.emitCanShop(player, shopId) === false) {
            return true;
        }

        this.setActiveShop(player, shopId, targetUid);
        const opened = this.openInterface(player, shop, resetScroll, targetUid);
        if (opened) {
            PluginManager.emitCustomEvent("shop:opened", {
                player,
                shopId,
                shopName: shop.definition.getName(),
            });
        }
        return opened;
    }

    public static close(player: any): void {
        if (!player) {
            return;
        }
        const shopId = this.activeShopByPlayer.get(player);
        if (!Number.isInteger(shopId)) {
            return;
        }
        const viewers = this.viewersByShopId.get(shopId!);
        viewers?.delete(player);
        if (viewers?.size === 0) {
            this.viewersByShopId.delete(shopId!);
        }
        this.activeShopByPlayer.delete(player);
        this.activeTargetByPlayer.delete(player);
        player.getSession?.().sendClientPacket?.(encodeShopClose());
    }

    public static processPlayer(player: any): void {
        if (
            (player?.isUnwatchedBot?.() ?? player?.isPlayerBot?.()) ||
            !this.activeShopByPlayer.has(player)
        ) {
            return;
        }
        if (
            !this.isOpen(player)
        ) {
            this.close(player);
        }
    }

    public static handleItemContainerAction(
        player: any,
        action: ShopItemContainerAction
    ): boolean {
        const shop = this.currentShop(player);
        if (!shop) {
            return false;
        }

        const fromShop = action.containerId === this.ITEMS_INTERFACE_ID;
        const fromInventory = action.containerId === this.INVENTORY_INTERFACE_ID;
        if (!fromShop && !fromInventory) {
            return false;
        }

        if (fromShop) {
            const entry = this.itemAtDisplaySlot(player, shop, action.slot);
            if (!entry) {
                return true;
            }
            const packetItemId = this.toUnsignedShort(action.itemId);
            const itemId = packetItemId > 0 && packetItemId === entry.itemId
                ? packetItemId
                : entry.itemId;
            if (action.kind === "value") {
                this.priceCheck(player, shop, itemId, true);
            } else if (action.kind === "x") {
                player.setEnteredAmountAction({
                    execute: (amount: number) => this.buyItem(player, shop, itemId, amount),
                });
                player.getPacketSender().sendEnterAmountPrompt(
                    "How many would you like to buy?"
                );
            } else {
                this.buyItem(player, shop, itemId, action.amount);
            }
            return true;
        }

        const inventory = player.getInventory();
        if (
            !Number.isInteger(action.slot) ||
            action.slot < 0 ||
            action.slot >= inventory.capacity()
        ) {
            return true;
        }
        const inventoryItem = inventory.getItems()?.[action.slot];
        if (!inventoryItem || inventoryItem.getId() <= 0) {
            return true;
        }
        const itemId = inventoryItem.getId();
        if (action.kind === "value") {
            this.priceCheck(player, shop, itemId, false, inventoryItem);
        } else if (action.kind === "x") {
            player.setEnteredAmountAction({
                execute: (amount: number) => this.sellItem(player, shop, inventoryItem, amount),
            });
            player.getPacketSender().sendEnterAmountPrompt(
                "How many would you like to sell?"
            );
        } else {
            this.sellItem(player, shop, inventoryItem, action.amount);
        }
        return true;
    }

    public static handleWidgetAction(player: any, packet: {
        groupId: number;
        childId: number;
        buttonNum: number;
        option?: string;
        slot?: number;
        itemId?: number;
    }): boolean {
        if (!this.isOpen(player)) return false;
        const mode = this.QUANTITY_MODE_BY_BUTTON.get(packet.childId);
        if (packet.groupId === this.MAIN_INTERFACE_ID && mode !== undefined) {
            this.setQuantityMode(player, mode);
            return true;
        }
        if (packet.slot == null) return false;
        const option = packet.option?.trim().toLowerCase() ?? "";
        const selected = this.QUANTITY_BY_MODE[this.quantityMode(player)];
        const amount = this.actionAmount(packet.buttonNum, option) ??
            (packet.groupId === this.MAIN_INTERFACE_ID && packet.buttonNum === 1 && !option && selected > 0 ? selected : null);
        const examine = packet.buttonNum === 10 || option === "examine";

        if (packet.groupId === this.MAIN_INTERFACE_ID && packet.childId === 16) {
            const slot = packet.slot - 1;
            const shop = this.currentShop(player);
            const item = shop ? this.itemAtDisplaySlot(player, shop, slot) : null;
            // The stock can shift (sold-in items leave), so the clicked slot
            // must still hold the item the client showed there.
            if (!item || (packet.itemId != null && packet.itemId > 0 && packet.itemId !== item.itemId)) return true;
            if (examine) {
                const definition = ItemDefinition.forId(item.itemId);
                player.sendMessage(definition.getExamine() || definition.getName());
            } else {
                this.handleItemContainerAction(player, {
                    kind: amount != null ? "buy_sell" : "value",
                    containerId: this.ITEMS_INTERFACE_ID,
                    slot,
                    itemId: item.itemId,
                    amount: amount ?? 0,
                });
            }
            return true;
        }

        if (packet.groupId === this.SIDE_INTERFACE_ID && packet.childId === 0) {
            const item = player.getInventory().getItems()[packet.slot];
            if (!item || item.getId() < 0) return true;
            if (examine) {
                const definition = ItemDefinition.forId(item.getId());
                player.sendMessage(definition.getExamine() || definition.getName());
            } else {
                this.handleItemContainerAction(player, {
                    kind: amount != null ? "buy_sell" : "value",
                    containerId: this.INVENTORY_INTERFACE_ID,
                    slot: packet.slot,
                    itemId: item.getId(),
                    amount: amount ?? 0,
                });
            }
            return true;
        }
        return false;
    }

    /** The player's open shop; `stock` is in display order, so an entry's index is its display slot. */
    public static getOpenShop(player: any): {
        name: string; currency: string; stock: Array<{ itemId: number; amount: number; price: number }>;
    } | null {
        const shop = this.currentShop(player);
        if (!shop) return null;
        return {
            name: shop.definition.getName(),
            currency: this.currencyName(shop.definition.getCurrency()),
            stock: this.displayEntries(shop, player).map((entry) => ({
                ...entry, price: this.buyPrice(player, shop, ItemDefinition.forId(entry.itemId)),
            })),
        };
    }

    private static quantityMode(player: any): number {
        const mode = Number(player.getAttribute?.(this.QUANTITY_MODE_ATTRIBUTE) ?? 0);
        return Number.isInteger(mode) && mode >= 0 && mode < this.QUANTITY_BY_MODE.length ? mode : 0;
    }

    private static setQuantityMode(player: any, mode: number): void {
        player.setAttribute?.(this.QUANTITY_MODE_ATTRIBUTE, mode);
        const shop = this.currentShop(player);
        if (shop) {
            // Reopening rebuilds the stock, and with it each item's left-click op.
            this.openInterface(player, shop, false, this.activeTargetByPlayer.get(player) ?? ((161 << 16) | 16));
        }
    }

    public static actionAmount(button: number, option?: string): number | null {
        const named = /(?:buy|sell)[ -](1|5|10|50)$/i.exec(option?.trim() ?? "");
        if (named) return Number(named[1]);
        return ({ 2: 1, 3: 5, 4: 10, 5: 50 } as Record<number, number>)[button] ?? null;
    }

    public static restockAll(): boolean {
        let pending = false;
        for (const shop of this.shopsById.values()) {
            if (this.restockShop(shop)) {
                pending = true;
            }
        }
        if (!pending) {
            this.restockTaskRunning = false;
        }
        return pending;
    }

    private static createRuntimeShop(definition: ShopDefinition): RuntimeShop {
        const originalAmounts = new Map<number, number>();
        const itemRestockTicks = new Map<number, number>();
        const itemPrices = new Map<number, number>();
        const stock = new Map<number, number>();
        const order: number[] = [];
        const seen = new Set<number>();

        for (const entry of definition.getOriginalStock()) {
            originalAmounts.set(
                entry.id,
                (originalAmounts.get(entry.id) ?? 0) + entry.amount
            );
            stock.set(entry.id, (stock.get(entry.id) ?? 0) + entry.amount);
            if (entry.restockTicks != null) {
                itemRestockTicks.set(entry.id, entry.restockTicks);
            }
            if (entry.price != null) {
                itemPrices.set(entry.id, entry.price);
            }
            if (!seen.has(entry.id)) {
                seen.add(entry.id);
                order.push(entry.id);
            }
        }

        return {
            definition,
            originalAmounts,
            itemRestockTicks,
            itemPrices,
            stock,
            order,
            originalSlotCount: definition.getOriginalStock().length,
            changeTimers: new Map(),
        };
    }

    private static currentShop(player: any): RuntimeShop | null {
        if (!this.isOpen(player)) {
            this.close(player);
            return null;
        }
        const shopId = this.activeShopByPlayer.get(player);
        return Number.isInteger(shopId)
            ? this.shopsById.get(shopId!) ?? null
            : null;
    }

    private static isOpen(player: any): boolean {
        return player?.getStatus?.() === PlayerStatus.SHOPPING &&
            (player?.getInterfaceId?.() === this.SHOP_INTERFACE_ID ||
                player?.getInterfaceId?.() === this.MAIN_INTERFACE_ID);
    }

    private static setActiveShop(player: any, shopId: number, targetUid: number): void {
        this.close(player);
        this.activeShopByPlayer.set(player, shopId);
        this.activeTargetByPlayer.set(player, targetUid);
        const viewers = this.viewersByShopId.get(shopId) ?? new Set<any>();
        viewers.add(player);
        this.viewersByShopId.set(shopId, viewers);
    }

    private static openInterface(
        player: any,
        shop: RuntimeShop,
        _resetScroll: boolean,
        targetUid = (161 << 16) | 16
    ): boolean {
        const sender = player.getPacketSender();
        const opening =
            !this.isOpen(player);

        const stock = this.displayEntries(shop, player).map((entry, slot) => {
            const definition = ItemDefinition.forId(entry.itemId);
            const price = definition ? this.buyPrice(player, shop, definition) : 0;
            return {
                slot, itemId: entry.itemId, quantity: entry.amount,
                defaultQuantity: shop.originalAmounts.get(entry.itemId) ?? 0,
                priceEach: price, sellPrice: definition ? this.sellPrice(shop, definition, player) : 0,
            };
        });
        player.setInterfaceId(this.MAIN_INTERFACE_ID);
        player.setStatus(PlayerStatus.SHOPPING);
        sender.sendVarbit(this.QUANTITY_VARBIT, this.quantityMode(player));
        sender.sendSubInterface(targetUid, this.MAIN_INTERFACE_ID, 0)
            .sendSubInterface((161 << 16) | 79, this.SIDE_INTERFACE_ID, 1)
            .sendInterfaceScript(1074, [516, shop.definition.getName(), this.currencyItemId(shop.definition.getCurrency()), 0, 1])
            .sendInterfaceFlagsRange((this.MAIN_INTERFACE_ID << 16) | 16, 0, 299, 1662)
            .sendInterfaceScript(149, [this.SIDE_INTERFACE_ID << 16, 93, 4, 7, 0, -1, "Value", "Sell 1", "Sell 5", "Sell 10", "Sell 50"])
            .sendInterfaceFlagsRange(this.SIDE_INTERFACE_ID << 16, 0, 27, 1086)
            .sendItemContainer(player.getInventory(), this.INVENTORY_INTERFACE_ID);
        player.getSession().sendClientPacket(encodeShopOpen(
            String(shop.definition.getId()), shop.definition.getName(),
            this.currencyItemId(shop.definition.getCurrency()), this.isGeneralStore(shop), 1, 1, stock
        ));
        if (opening) Sounds.sendSound(player, Sound.CONTAINER_OPEN);
        return true;
    }

    private static refresh(shopId: number): void {
        const shop = this.shopsById.get(shopId);
        const viewers = this.viewersByShopId.get(shopId);
        if (!shop || !viewers) {
            return;
        }
        for (const player of Array.from(viewers)) {
            if (
                !this.isOpen(player) ||
                this.activeShopByPlayer.get(player) !== shopId
            ) {
                this.close(player);
                continue;
            }
            this.openInterface(
                player,
                shop,
                false,
                this.activeTargetByPlayer.get(player) ?? ((161 << 16) | 16)
            );
        }
    }

    /**
     * The stock this player sees, in slot order. An item the shop stocks keeps its slot at 0
     * when sold out, as in OSRS; items players sold in leave when gone.
     */
    private static displayEntries(shop: RuntimeShop, player: any): DisplayEntry[] {
        const entries: DisplayEntry[] = [];
        for (const itemId of shop.order) {
            const amount = shop.stock.get(itemId) ?? 0;
            if ((amount > 0 || shop.originalAmounts.has(itemId)) && this.stockVisible(player, shop, itemId)) {
                entries.push({ itemId, amount });
            }
        }
        return entries;
    }

    /**
     * "shop:stock-visible": content may hide stock from one player (the Lost Property shop
     * lists only what the player has unlocked; some stock waits for a quest). Hidden stock
     * takes no slot, so it can't be bought either.
     */
    private static stockVisible(player: any, shop: RuntimeShop, itemId: number): boolean {
        const request = { player, shopId: shop.definition.getId(), shopName: shop.definition.getName(), itemId, visible: true };
        PluginManager.emitCustomEvent("shop:stock-visible", request);
        return request.visible !== false;
    }

    private static itemAtDisplaySlot(
        player: any,
        shop: RuntimeShop,
        slot: number
    ): DisplayEntry | null {
        return Number.isInteger(slot) && slot >= 0
            ? this.displayEntries(shop, player)[slot] ?? null
            : null;
    }

    private static priceCheck(
        player: any,
        shop: RuntimeShop,
        itemId: number,
        fromShop: boolean,
        item?: any
    ): void {
        if (!fromShop) {
            // A note sells as the item it stands for.
            itemId = ItemDefinition.forId(itemId).unNote();
        }
        if (!fromShop && shop.definition.getCurrency() === "COINS" && this.isBloodMoneyShopItem(itemId)) {
            player.sendMessage("PK shop items cannot be sold for coins.");
            return;
        }
        if (!fromShop && !this.buysItem(shop, itemId)) {
            player.sendMessage(this.sellRefusal(shop));
            return;
        }
        const definition = ItemDefinition.forId(itemId);
        if (!fromShop && !this.canSell(shop, item, player)) {
            player.sendMessage(
                "This item cannot be sold to a shop."
            );
            return;
        }
        const price = fromShop ? this.buyPrice(player, shop, definition) : this.sellPrice(shop, definition, player);
        if ((!fromShop && this.isOwnCurrency(shop, itemId))
            || (price <= 0 && !((fromShop || this.stockPriced(shop)) && this.itemPrice(shop, definition) > 0))) {
            player.sendMessage("This item has no value.");
            return;
        }
        const unit = this.currencyUnit(shop.definition.getCurrency());
        if (unit) {
            const named = unit === "coins" && price === 1 ? "coin" : unit;
            player.sendMessage(
                `${definition.getName()}: ${fromShop ? "currently costs" : "shop will buy for"} ` +
                `${Misc.insertCommasToNumber(String(price))} ${named}.`
            );
            return;
        }
        player.sendMessage(
            `${definition.getName()}${fromShop ? " currently costs " : ": shop will buy for "}` +
            `${Misc.insertCommasToNumber(String(price))} x ` +
            `${this.currencyName(shop.definition.getCurrency())}.`
        );
    }

    private static buyItem(
        player: any,
        shop: RuntimeShop,
        itemId: number,
        amount: number
    ): void {
        const definition = ItemDefinition.forId(itemId);
        // An item with no price of its own is never sold; content may still make a priced one free ("shop:buy-price").
        if (this.itemPrice(shop, definition) <= 0 || !this.stockVisible(player, shop, itemId)) {
            return;
        }
        const price = this.buyPrice(player, shop, definition);

        let quantity = Math.min(this.normalizeAmount(amount), this.MAX_ACTION_AMOUNT);
        if (quantity <= 0) {
            return;
        }
        let available = shop.stock.get(itemId) ?? 0;
        if (available <= 0) {
            player.sendMessage(
                "This item is currently out of stock. Come back later."
            );
            return;
        }
        // "shop:buy-limit": a plugin may lower how many of the stock this player can buy (an
        // Ironman buys only the shop's own stock, not what players sold it).
        const limit = {
            player, shopId: shop.definition.getId(), itemId, available,
            original: shop.originalAmounts.get(itemId) ?? 0, limit: available, message: null as string | null,
        };
        PluginManager.emitCustomEvent("shop:buy-limit", limit);
        if (limit.limit < available) {
            available = Math.max(0, limit.limit);
            if (available <= 0) {
                if (limit.message) player.sendMessage(limit.message);
                return;
            }
        }
        quantity = Math.min(
            quantity,
            price > 0 ? Math.floor(this.currencyAmount(player, shop.definition.getCurrency()) / price) : quantity,
            available
        );
        if (quantity <= 0) {
            const unit = this.currencyUnit(shop.definition.getCurrency());
            player.sendMessage(unit ? `You don't have enough ${unit}.` : "You can't afford that.");
            return;
        }

        // Content may hand the purchase over as another item ("shop:delivery", a league relic's noted purchases), or as
        // a bundle of several per item bought (`amount`, the PvP Arena's Blighted surge sack (x50)).
        const delivery = { player, shopId: shop.definition.getId(), currency: shop.definition.getCurrency(), itemId, deliverId: itemId, amount: 1, captureDelivery: false };
        PluginManager.emitCustomEvent("shop:delivery", delivery);
        const deliverId = Number.isInteger(delivery.deliverId) && delivery.deliverId > 0 ? delivery.deliverId : itemId;
        const perPurchase = Number.isInteger(delivery.amount) && delivery.amount > 0 ? delivery.amount : 1;
        const delivered = ItemDefinition.forId(deliverId);
        const inventory = player.getInventory();
        if (delivered.isStackable?.()) {
            quantity = Math.min(quantity, Math.floor(inventory.getAddableAmount(new Item(deliverId, quantity * perPurchase)) / perPurchase));
            if (quantity <= 0) {
                inventory.full();
                return;
            }
        } else {
            quantity = Math.min(quantity, Math.floor(inventory.getFreeSlots() / perPurchase));
            if (quantity <= 0) {
                inventory.full();
                return;
            }
        }

        const removed = this.takeStock(player, shop, itemId, quantity);
        if (removed <= 0) {
            return;
        }
        this.removeCurrency(
            player,
            shop.definition.getCurrency(),
            removed * price
        );
        // Capture only an actual single nonstackable delivery, never a bundle.
        const deliveredSlot = delivery.captureDelivery && removed === 1 && perPurchase === 1 && !delivered.isStackable?.()
            ? inventory.getEmptySlot() : -1;
        inventory.adds(deliverId, removed * perPurchase);
        const deliveredItem = deliveredSlot >= 0 ? inventory.getItems()[deliveredSlot] : null;
        PluginManager.emitCustomEvent("shop:purchase", {
            player, shopId: shop.definition.getId(), shopName: shop.definition.getName(),
            itemId, amount: removed, originalStock: (shop.originalAmounts.get(itemId) ?? 0) > 0,
            currency: shop.definition.getCurrency(),
            ...(delivery.captureDelivery ? { deliverId, deliveredSlot, deliveredItem } : {}),
        });
        Sounds.sendSound(player, Sound.PICK_UP_ITEM);
        this.refresh(shop.definition.getId());
        this.ensureRestockTask();
    }

    private static sellItem(
        player: any,
        shop: RuntimeShop,
        item: any,
        amount: number
    ): void {
        const itemId = item?.getId?.();
        if (!Number.isInteger(itemId)) {
            return;
        }
        // A note sells as the item it stands for.
        const stockId = ItemDefinition.forId(itemId).unNote();
        if (shop.definition.getCurrency() === "COINS" && this.isBloodMoneyShopItem(stockId)) {
            player.sendMessage("PK shop items cannot be sold for coins.");
            return;
        }
        if (!this.buysItem(shop, stockId)) {
            player.sendMessage(this.sellRefusal(shop));
            return;
        }
        const definition = ItemDefinition.forId(stockId);
        if (!this.canSell(shop, item, player)) {
            player.sendMessage("This item cannot be sold.");
            return;
        }

        const inventory = player.getInventory();
        const slot = inventory.getItems().indexOf(item);
        if (slot < 0) {
            return;
        }
        // A stack sells from its own slot; unstackable items (one per slot)
        // start at the clicked slot and continue through the others.
        const slots = item.getDefinition().isStackable()
            ? [slot]
            : [slot, ...inventory.getItems().map((_, index) => index).filter((index) => index !== slot)];
        const sellable = slots.filter((index) => {
            const held = inventory.getItems()[index];
            return held?.getId() === itemId && this.canSell(shop, held, player);
        });
        const held = sellable.reduce((total, index) => total + inventory.getItems()[index].getAmount(), 0);
        let quantity = Math.min(this.normalizeAmount(amount), this.MAX_ACTION_AMOUNT, held);
        if (quantity <= 0) {
            return;
        }
        const price = this.sellPrice(shop, definition, player);
        // Wiki (Lumbridge General Store, Bandit Duty Free): a stocked pot, jug or chisel is "bought at" 0 coins. A
        // stock-priced general store refuses only an item of no value, not one its formula rounds down to 0.
        if (this.isOwnCurrency(shop, stockId) || (this.stockPriced(shop) ? this.itemPrice(shop, definition) <= 0 : price <= 0)) {
            player.sendMessage("This item has no value.");
            return;
        }
        if ((shop.stock.get(stockId) ?? 0) <= 0 && shop.order.length >= this.MAX_SHOP_ITEMS) {
            player.sendMessage("The shop is currently full.");
            return;
        }

        // A multi-item sale changes the price after each unit, even when content
        // restores stock after the transaction (the league keep-stock hook).
        let payment = quantity * price;
        if (this.stockPriced(shop)) {
            payment = 0;
            for (let offset = 0; offset < quantity; offset++) {
                payment += this.sellPrice(shop, definition, player, offset);
            }
        }
        if (!this.canReceivePayment(player, shop.definition.getCurrency(), sellable, quantity, payment)) {
            player.sendMessage("You don't have enough inventory space.");
            return;
        }

        let remaining = quantity;
        for (const index of sellable) {
            if (remaining <= 0) break;
            const taken = Math.min(remaining, inventory.getItems()[index].getAmount());
            inventory.deleteAtSlot(index, taken, false);
            remaining -= taken;
        }
        inventory.refreshItems();
        this.addCurrency(
            player,
            shop.definition.getCurrency(),
            payment
        );
        // Content may keep the stock as it was on a sale too ("shop:keep-stock" with `selling`, a
        // league's shops whose stock never changes): the item is paid for and not added.
        const keep = { player, shopId: shop.definition.getId(), itemId: stockId, amount: quantity, keep: false, selling: true };
        PluginManager.emitCustomEvent("shop:keep-stock", keep);
        if (!keep.keep) this.addStock(shop, stockId, quantity);
        Sounds.sendSound(player, Sound.DROP_ITEM);
        this.refresh(shop.definition.getId());
        this.ensureRestockTask();
    }

    private static restockShop(shop: RuntimeShop): boolean {
        const itemIds = new Set([...shop.order, ...shop.originalAmounts.keys()]);
        let changed = false;
        let pending = false;
        for (const itemId of itemIds) {
            const original = shop.originalAmounts.get(itemId) ?? 0;
            const current = shop.stock.get(itemId) ?? 0;
            const decrease = current > original;
            const increase = current < original;
            if (!decrease && !increase) {
                shop.changeTimers.delete(itemId);
                continue;
            }

            pending = true;
            const interval = this.stockChangeIntervalTicks(shop, itemId, decrease);
            let timer = Number(shop.changeTimers.get(itemId) ?? interval);
            if (!Number.isFinite(timer) || timer <= 0) {
                timer = interval;
            }
            timer--;
            if (timer <= 0) {
                changed = decrease
                    ? this.removeStock(shop, itemId, 1) > 0 || changed
                    : this.addStock(shop, itemId, 1) || changed;
                timer = interval;
            }

            const next = shop.stock.get(itemId) ?? 0;
            if ((decrease && next > original) || (increase && next < original)) {
                shop.changeTimers.set(itemId, timer);
            } else {
                shop.changeTimers.delete(itemId);
            }
        }
        if (changed) {
            this.refresh(shop.definition.getId());
        }
        return pending;
    }

    private static stockChangeIntervalTicks(
        shop: RuntimeShop,
        itemId: number,
        decrease: boolean
    ): number {
        if (
            decrease &&
            this.deletesItems(shop) &&
            !shop.originalAmounts.has(itemId)
        ) {
            return Math.max(1, shop.definition.getSoldItemDestockTicks());
        }
        const configured = decrease
            ? shop.itemRestockTicks.get(itemId) ??
              shop.definition.getDefaultDestockTicks()
            : shop.itemRestockTicks.get(itemId) ??
              shop.definition.getDefaultRestockTicks();
        return Math.max(1, Number(configured));
    }

    private static addStock(shop: RuntimeShop, itemId: number, amount: number): boolean {
        const quantity = this.normalizeAmount(amount);
        if (quantity <= 0) {
            return false;
        }
        const current = shop.stock.get(itemId) ?? 0;
        if (current <= 0 && shop.order.length >= this.MAX_SHOP_ITEMS) {
            return false;
        }
        if (!shop.order.includes(itemId)) {
            shop.order.push(itemId);
        }
        shop.stock.set(
            itemId,
            Math.min(Number.MAX_SAFE_INTEGER, current + quantity)
        );
        return true;
    }

    /**
     * Takes a purchase out of the stock: what was bought. Content may keep the shop's own stock
     * ("shop:keep-stock" { player, shopId, itemId, amount, keep }, a league's shops that never
     * deplete): then only stock above the shop's own amount (what players sold it) goes. A sale
     * asks the same event with `selling: true` (sellItem).
     */
    private static takeStock(player: any, shop: RuntimeShop, itemId: number, amount: number): number {
        const request = { player, shopId: shop.definition.getId(), itemId, amount, keep: false };
        PluginManager.emitCustomEvent("shop:keep-stock", request);
        if (!request.keep) return this.removeStock(shop, itemId, amount);
        const current = shop.stock.get(itemId) ?? 0;
        const taken = Math.min(current, this.normalizeAmount(amount));
        const surplus = Math.max(0, current - (shop.originalAmounts.get(itemId) ?? 0));
        if (Math.min(taken, surplus) > 0) this.removeStock(shop, itemId, Math.min(taken, surplus));
        return taken;
    }

    private static removeStock(shop: RuntimeShop, itemId: number, amount: number): number {
        const quantity = this.normalizeAmount(amount);
        const current = shop.stock.get(itemId) ?? 0;
        const removed = Math.min(current, quantity);
        if (removed <= 0) {
            return 0;
        }
        const remaining = current - removed;
        if (remaining <= 0) {
            shop.stock.delete(itemId);
            if (!shop.originalAmounts.has(itemId)) {
                shop.order = shop.order.filter((id) => id !== itemId);
            }
        } else {
            shop.stock.set(itemId, remaining);
        }
        return removed;
    }

    /**
     * Shops that sell for a currency other than coins and still buy items for it: the TzHaar shops (tokkul) and
     * Tai Bwo Wannai's cooperative (trading sticks). Other reward shops (minigame points, tickets) buy nothing back,
     * unless the Wiki gives the shop a buy percentage (`specialistBuyback`) or their plugin says the shop does
     * ("shop:buys-back" { shopId, shopName, currency, itemId, buys }).
     */
    private static readonly BUYBACK_CURRENCIES = new Set(["COINS", "TOKKUL", "TRADING STICKS", "BLOOD_MONEY"]);

    /**
     * A shop buys what it lists, including items it lists at 0 (Gerrant's raw fish). A reward shop doesn't: it paid
     * 85% of an item's coin value in its own currency, so coal sold to Petrified Pete minted Volcanic Mine points,
     * and arrows sold at the Ranging Guild turned coins into archery tickets.
     */
    private static buysItem(shop: RuntimeShop, itemId: number): boolean {
        if (!this.BUYBACK_CURRENCIES.has(String(shop.definition.getCurrency()).toUpperCase())) {
            const request = {
                shopId: shop.definition.getId(), shopName: shop.definition.getName(),
                currency: shop.definition.getCurrency(), itemId, buys: this.specialistBuyback(shop) > 0,
            };
            PluginManager.emitCustomEvent("shop:buys-back", request);
            if (request.buys !== true) return false;
        }
        return this.isGeneralStore(shop) || shop.originalAmounts.has(itemId);
    }

    /**
     * The Wiki's "Buys at" (per mille) for a shop paying in its own reward currency, 0 where it has none. Wiki
     * StoreTableHead: Grace's Graceful Clothing, Prospector Percy's Nugget Shop, the Mining Guild Mineral Exchange
     * and Dusuri's Star Shop buy their stock back at 80% (a graceful hood bought for 35 marks sells for 28); Petrified
     * Pete's Ore Shop buys at 0%. The TzHaar and Tai Bwo Wannai shops keep the standard refund.
     */
    private static specialistBuyback(shop: RuntimeShop): number {
        if (this.BUYBACK_CURRENCIES.has(String(shop.definition.getCurrency()).toUpperCase())) return 0;
        const multiplier = shop.definition.getSalesPolicy().sellMultiplier;
        return Number.isSafeInteger(multiplier) && Number(multiplier) > 0 ? Number(multiplier) : 0;
    }

    /**
     * Why a sale is refused: a shop that buys nothing, "You cannot sell to this shop." (rsprox 227/01840 Temple
     * Supplies, 234/03299 Mairin's Market, both on Value and Sell); one that buys only some items, "You can't sell this
     * item to this shop." (cache script9714's wording; no recording).
     */
    private static sellRefusal(shop: RuntimeShop): string {
        const buysAnything = this.BUYBACK_CURRENCIES.has(String(shop.definition.getCurrency()).toUpperCase())
            || [...shop.originalAmounts.keys()].some((stocked) => this.buysItem(shop, stocked));
        return buysAnything ? "You can't sell this item to this shop." : "You cannot sell to this shop.";
    }

    private static isBloodMoneyShopItem(itemId: number): boolean {
        return this.BLOOD_MONEY_SHOP_IDS.some((shopId) =>
            ShopDefinition.forId(shopId)?.getCurrency() === "BLOOD_MONEY" &&
            ShopDefinition.forId(shopId)?.getOriginalStock().some((stock) => stock.id === itemId)
        );
    }

    private static deletesItems(shop: RuntimeShop): boolean {
        return this.isGeneralStore(shop);
    }

    /** General stores buy any item; the shop data only marks them by name. */
    private static isGeneralStore(shop: RuntimeShop): boolean {
        const configured = shop.definition.getSalesPolicy().generalStore;
        if (configured != null) return configured;
        return shop.definition.getId() === ShopIdentifiers.GENERAL_STORE ||
            /general store/i.test(shop.definition.getName());
    }

    /** `player` (when known) and `currency` let content refuse a sale for one player (a league relic's shops that buy nothing for gold). */
    private static canSell(shop: RuntimeShop, item: Item, player: any = null): boolean {
        if (!item || item.isUntradeable()) return false;
        // Wiki (Amylase pack): untradeable stock "can only be sold back to Grace's Graceful Clothing". A shop that
        // buys its stock back for its own currency takes the items it lists, though no other shop would.
        const ownStock = this.specialistBuyback(shop) > 0
            && shop.originalAmounts.has(ItemDefinition.forId(item.getId()).unNote());
        const request = {
            player, shopId: shop.definition.getId(), shopName: shop.definition.getName(), currency: shop.definition.getCurrency(),
            itemId: item.getId(), sellable: ownStock || item.isSellable(),
        };
        PluginManager.emitCustomEvent("shop:can-sell", request);
        return request.sellable === true;
    }

    /**
     * What this player pays for one: the item's price, as content may change it ("shop:buy-price",
     * a league relic's free coin shops). Never below 0.
     */
    private static buyPrice(player: any, shop: RuntimeShop, definition: ItemDefinition): number {
        const price = this.itemPrice(shop, definition);
        const request = {
            player, shopId: shop.definition.getId(), shopName: shop.definition.getName(), currency: shop.definition.getCurrency(),
            itemId: definition.getId(), price,
        };
        PluginManager.emitCustomEvent("shop:buy-price", request);
        return Number.isSafeInteger(request.price) && request.price >= 0 ? request.price : price;
    }

    /** The shop's own currency item (coins to a coin shop): never bought, even where the price formula would allow 0. */
    private static isOwnCurrency(shop: RuntimeShop, itemId: number): boolean {
        const currencyId = this.currencyHandlers.get(shop.definition.getCurrency())?.itemId
            ?? this.currencyItemId(shop.definition.getCurrency());
        return currencyId > 0 && ItemDefinition.forId(itemId).unNote() === currencyId;
    }

    /** A coin general store with the Wiki's buy percentage and change per item: its price follows its stock. */
    private static stockPriced(shop: RuntimeShop): boolean {
        const policy = shop.definition.getSalesPolicy();
        return policy.generalStore === true && shop.definition.getCurrency() === "COINS"
            && policy.sellMultiplier != null && policy.priceChangePer != null;
    }

    private static sellPrice(shop: RuntimeShop, definition: ItemDefinition, player: any = null, additionalStock = 0): number {
        const buyPrice = this.itemPrice(shop, definition);
        const buyback = this.specialistBuyback(shop);
        let price = buyback > 0
            ? Math.floor(buyPrice * buyback / 1000)
            : buyPrice > 1 ? Math.floor(buyPrice * this.SALES_TAX) : buyPrice;
        const policy = shop.definition.getSalesPolicy();
        if (this.stockPriced(shop)) {
            const overstock = Math.max(0, (shop.stock.get(definition.getId()) ?? 0)
                - (shop.originalAmounts.get(definition.getId()) ?? 0) + additionalStock);
            // Wiki StoreTableHead multipliers use per mille; the general-store floor is 10%.
            price = Math.floor(Number(definition.getValue()) * Math.max(100, policy.sellMultiplier - overstock * policy.priceChangePer) / 1000);
        }
        const request = {
            player, shopId: shop.definition.getId(), shopName: shop.definition.getName(), currency: shop.definition.getCurrency(),
            itemId: definition.getId(), buyPrice, price,
        };
        PluginManager.emitCustomEvent("shop:sell-price", request);
        return Number.isSafeInteger(request.price) && request.price >= 0 ? request.price : price;
    }

    private static itemPrice(shop: RuntimeShop, definition: ItemDefinition): number {
        const override = shop.itemPrices.get(definition.getId());
        if (override != null && override > 0) {
            return override;
        }
        return shop.definition.getCurrency() === "BLOOD_MONEY"
            ? Number(definition.getBloodMoneyValue?.() ?? 0)
            : Number(definition.getValue?.() ?? 0);
    }

    /**
     * Coins have a unit too (rsprox: "Blood rune: currently costs 400 coins.", "Empty plant pot: currently costs 1
     * coin.", "Raw chicken: shop will buy for 0 coins.", "You don't have enough coins.").
     */
    private static currencyUnit(currency: ShopCurrency): string | null {
        return this.currencyHandlers.get(currency)?.unit ?? (currency === "COINS" ? "coins" : null);
    }

    private static currencyAmount(player: any, currency: ShopCurrency): number {
        const handler = this.currencyHandlers.get(currency);
        if (handler) return Math.max(0, handler.amount(player) | 0);
        if (currency === "POINTS") {
            return Number(player.getAttribute(this.POINTS_ATTRIBUTE) ?? 0);
        }
        const itemId = this.currencyItemId(currency);
        return itemId > 0
            ? Number(player.getInventory()?.getAmount?.(itemId) ?? 0)
            : 0;
    }

    private static addCurrency(
        player: any,
        currency: ShopCurrency,
        amount: number
    ): void {
        const quantity = this.normalizeAmount(amount);
        if (quantity <= 0) {
            return;
        }
        const handler = this.currencyHandlers.get(currency);
        if (handler) {
            handler.add(player, quantity);
            return;
        }
        if (currency === "POINTS") {
            player.setAttribute(this.POINTS_ATTRIBUTE, this.currencyAmount(player, currency) + quantity);
            return;
        }
        const itemId = this.currencyItemId(currency);
        if (itemId > 0) {
            player.getInventory().adds(itemId, quantity);
        }
    }

    private static removeCurrency(
        player: any,
        currency: ShopCurrency,
        amount: number
    ): void {
        const quantity = this.normalizeAmount(amount);
        if (quantity <= 0) {
            return;
        }
        const handler = this.currencyHandlers.get(currency);
        if (handler) {
            handler.remove(player, quantity);
            return;
        }
        if (currency === "POINTS") {
            player.setAttribute(this.POINTS_ATTRIBUTE, Math.max(0, this.currencyAmount(player, currency) - quantity));
            return;
        }
        const itemId = this.currencyItemId(currency);
        if (itemId > 0) {
            player.getInventory().deleteNumber(itemId, quantity);
        }
    }

    /**
     * Preview the same slot deletions as the sale, then ask the actual container
     * whether its complete payment fits, including metadata and stack limits.
     */
    private static canReceivePayment(player: any, currency: ShopCurrency, slots: number[], quantity: number, payment: number): boolean {
        const itemId = this.currencyHandlers.get(currency)?.itemId ?? this.currencyItemId(currency);
        if (!(itemId > 0)) return true;
        const inventory = player.getInventory();
        const preview = new Inventory(player).setItems(inventory.getCopiedItems());
        let remaining = quantity;
        for (const slot of slots) {
            if (remaining <= 0) break;
            const taken = Math.min(remaining, preview.getItems()[slot].getAmount());
            preview.deleteAtSlot(slot, taken, false);
            remaining -= taken;
        }
        return remaining === 0 && preview.getAddableAmount(new Item(itemId, payment)) === payment;
    }

    private static currencyItemId(currency: ShopCurrency): number {
        if (currency === "COINS") {
            return ItemIdentifiers.COINS;
        }
        if (currency === "BLOOD_MONEY") {
            return ItemIdentifiers.BLOOD_MONEY;
        }
        return -1;
    }

    private static currencyName(currency: ShopCurrency): string {
        const handler = this.currencyHandlers.get(currency);
        if (handler) return handler.name;
        if (currency === "COINS") {
            return "Coins";
        }
        if (currency === "BLOOD_MONEY") {
            return "Blood money";
        }
        if (currency === "POINTS") {
            return "Points";
        }
        return "Currency";
    }

    private static ensureRestockTask(): void {
        if (this.restockTaskRunning) {
            return;
        }
        this.restockTaskRunning = true;
        TaskManager.submit(new ShopRestockTask());
    }

    private static normalizeAmount(value: number): number {
        return Number.isFinite(value) ? Math.max(0, Math.floor(value)) : 0;
    }

    private static toUnsignedShort(value: number): number {
        return Number.isInteger(value) ? value & 0xffff : -1;
    }
}
