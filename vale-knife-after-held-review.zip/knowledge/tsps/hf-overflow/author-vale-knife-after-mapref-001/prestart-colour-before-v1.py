"""Isolated reference-aware prestart candidate. NEVER submits or changes a plan.
Requires already-selected exact reviewed bytes. Every output is a prestart receipt,
not admission authority. Frozen generic caller/pilot/D46 remain unchanged.
"""
from pathlib import Path
import argparse,base64,hashlib,json,re,subprocess,urllib.request,datetime
ROOT=Path(__file__).resolve().parent
WS=ROOT.parents[3]
HF=ROOT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def bound(path,digest):
 raw=Path(path).read_bytes();assert re.fullmatch('[a-f0-9]{64}',digest) and sha(raw)==digest,str(path)
 return raw

def reference_url(plan):
 spec=plan['expectedInputsRef']
 assert not plan.get('expectedInputs') and not plan.get('sourceBlobs'),'Mixed modes'
 assert set(spec)=={'schema','repository','artifactCommit','path','sha256','bytes','source','count'}
 assert spec['schema']==1 and spec['repository']==plan['repository'] and re.fullmatch('[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',spec['repository'])
 assert re.fullmatch('[a-f0-9]{40}',spec['artifactCommit']) and len(set(spec['artifactCommit']))>1,'Prospective/placeholder artifact inadmissible'
 assert spec['source']==plan['source'] and re.fullmatch('[a-f0-9]{40}',plan['source'])
 assert re.fullmatch('[a-f0-9]{64}',spec['sha256']) and type(spec['bytes']) is int and 0<spec['bytes']<=2*1024*1024
 assert type(spec['count']) is int and 0<spec['count']<=10000
 assert re.fullmatch('[A-Za-z0-9_./-]+[.]json',spec['path']) and all(x and x not in ('.','..') for x in spec['path'].split('/'))
 return f"https://raw.githubusercontent.com/{spec['repository']}/{spec['artifactCommit']}/{spec['path']}"

class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):raise ValueError('Manifest redirect refused')

def resolve_bytes(plan,raw):
 spec=plan['expectedInputsRef'];assert len(raw)==spec['bytes'] and sha(raw)==spec['sha256'],'Manifest byte identity'
 # Reuse EXACT tested/embedded JS parser/schema, not a second document interpretation.
 code="""const fs=require('node:fs');const {resolveInputManifest}=require(process.argv[1]);
 const x=JSON.parse(fs.readFileSync(0,'utf8'));const raw=Buffer.from(x.base64,'base64');
 resolveInputManifest(x.plan,async url=>({ok:true,url,body:(async function*(){yield raw})()}))
 .then(x=>console.log(JSON.stringify(x))).catch(e=>{console.error(e.message);process.exitCode=70});"""
 r=subprocess.run(['node','-e',code,str(ROOT/'input-manifest-resolver.cjs')],input=json.dumps({'plan':plan,'base64':base64.b64encode(raw).decode()}).encode(),capture_output=True,check=True)
 return json.loads(r.stdout)

def verify_git(plan,resolved):
 repo=WS/'repos/tsps';rows=resolved['expectedInputs'];blobs=resolved['sourceBlobs']
 assert len(rows)==plan['expectedInputsRef']['count'] and set(rows)==set(blobs)
 tree={}
 for row in subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','-z',plan['source']]).split(b'\0'):
  if row:
   meta,file=row.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[file.decode()]=(kind,oid)
 for file in rows:assert tree[file]==('blob',blobs[file]),file
 names=list(rows);data=subprocess.check_output(['git','-C',str(repo),'cat-file','--batch'],input=('\n'.join(blobs[x] for x in names)+'\n').encode());offset=0;actual={}
 for file in names:
  end=data.index(b'\n',offset);oid,kind,size=data[offset:end].decode().split();offset=end+1;raw=data[offset:offset+int(size)];offset+=int(size)+1
  actual[file]=sha(raw);assert actual[file]==rows[file] and oid==blobs[file] and kind=='blob',file
 assert offset==len(data)
 return actual,blobs

COLOUR_SOURCE='15bdf31841fc288eb9049d30c7ea491d88c83811'
COLOUR_REF='refs/heads/cuttle/vale-knife-after-7b9eef1d'
OWNER='7b9eef1d-c2d6-4b9a-8125-57104d8b6986'
REVIEWER='a4d43058-5882-445b-8c6f-398aaa054265'
OPERATOR='e684f690-a74d-47d4-b468-30c43b86f13f'
ORIGINAL_PLAN='a7013191c411fcfa417621889cde1b7382b251d9140387a5e93bffc9cb6b392d'
ORIGINAL_REQUEST='e0473b2c95910cf8bb0fd861ba050758a98bf318c230952a79c786c0967cffb2'
PROFILE_BASIS='8eb0af645befdd9c250e8716ab9adabfeeb65fc2044a33852e0d3eaad2aacb06'

def validate_lineage(plan,resolved,original,source_ref):
 assert source_ref==COLOUR_REF and plan['source']==original['source']==COLOUR_SOURCE,'Reviewed source/ref drift'
 assert plan['expectedInputsRef']['count']==4895
 assert resolved['expectedInputs']==original['expectedInputs'] and resolved['sourceBlobs']==original['sourceBlobs'],'Audited original maps differ'
 allowed={'name','payloadFile','executionHold','ownerSelection','sourceReview','expectedInputsRef','expectedInputs','sourceBlobs'}
 assert set(plan)-set(original)<={'expectedInputsRef','ownerSelection'},'Unsupported plan extension'
 assert set(original)-set(plan)=={'expectedInputs','sourceBlobs'},'Unsupported plan removal'
 for key in set(original)-allowed:assert plan[key]==original[key],f'Unapproved plan delta: {key}'
 assert plan['tests']==['vale-fletching-knife-timing.test.cjs', 'fletching.test.cjs', 'fletching-action-provenance.test.cjs']
 assert plan['expectedTestCounts']=={'vale-fletching-knife-timing.test.cjs': 4, 'fletching.test.cjs': 31, 'fletching-action-provenance.test.cjs': 4}

def build_authority_subject(plan,plan_sha,bindings,bindings_sha,selection_sha,caller_sha):
 return {'source':COLOUR_SOURCE,'sourceRef':COLOUR_REF,'originalPlanSHA256':ORIGINAL_PLAN,'originalRequestSHA256':ORIGINAL_REQUEST,'planSHA256':plan_sha,'manifestSHA256':plan['expectedInputsRef']['sha256'],'count':4895,'tests':plan['tests'],'expectedTestCounts':plan['expectedTestCounts'],'callerSHA256':caller_sha,'submitCallerSHA256':bindings['submitCaller']['sha256'],'payloadSHA256':bindings['payload']['sha256'],'bindingsSHA256':bindings_sha,'profileBasisSHA256':PROFILE_BASIS,'selectionSHA256':selection_sha}

def verify_subject_pair(expected,receipt_subject,authority_subject):
 assert receipt_subject==expected and authority_subject==expected,'Current plan/review subject mismatch'

def validate_authority(record,subject):
 # File bytes alone cannot authenticate a reviewer. This contract must be a
 # genuine operator capture of the named reviewer's direct-session verdict;
 # caller binds its hash and the exact underlying review artifacts. No record
 # is generated here and no arbitrary --review list substitutes for it.
 assert record['type']=='OPERATOR_CAPTURED_DIRECT_REVIEW_CONTRACT'
 assert record['issuer']==REVIEWER and record['owner']==OWNER and record['operator']==OPERATOR,'Review identity'
 assert record['verdict']=='EXACT_INPUT_PROFILE_GO' and record['subject']==subject,'Review subject/verdict'
 evidence=record['directSessionEvidence'];assert evidence['session']==REVIEWER and evidence['origin']=='OPERATOR_OBSERVED_DIRECT_SESSION_MESSAGE','Missing actual direct review provenance'
 bound(WS/evidence['capturePath'],evidence['captureSHA256'])
 assert record['reviewArtifacts'],'Review artifacts missing'
 for row in record['reviewArtifacts']:
  assert row['reviewer']==REVIEWER and row['stage'] in ['SOURCE_GO','EXACT_INPUT_PROFILE_GO']
  bound(WS/row['path'],row['sha256'])

def validate_reconciliation(record,plan_sha,selection_sha):
 assert record['operator']==OPERATOR and record['source']==COLOUR_SOURCE
 assert record['planSHA256']==plan_sha and record['selectionSHA256']==selection_sha
 age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(record['checkedUTC'])).total_seconds()
 assert 0<=age<=300,'Stale normal reconciliation'
 assert record['ownedMatchingToolCells']==[] and record['pendingOrAmbiguousMatchingIntents']==[] and record['submittedMatchingJobs']==[]
 assert record['providerReconciliation']['status']=='CLEAR' and record['providerReconciliation']['scope']=='same selected source/name; normal sole-operator reconciliation, not global census'
 assert record['providerReconciliation']['evidence'],'Retained reconciliation evidence required'
 for row in record['providerReconciliation']['evidence']:bound(WS/row['path'],row['sha256'])

def validate_binding_bundle(bindings,plan,plan_dir):
 required={'payload','resolver','pilot','package','caller','originalPlan','originalRequest','profileBasis','originalD46','submitCaller','inputCollector'};assert set(bindings)==required
 required_paths={'payload':ROOT/'native-payload-mapref-candidate.cjs','resolver':ROOT/'input-manifest-resolver.cjs','pilot':HF/'pilot.py','package':HF/'package.json','caller':Path(__file__).resolve(),'originalPlan':ROOT/'original-case-full-plan.json','originalRequest':ROOT/'original-case-request.json','profileBasis':HF/'native-smithing-95e-after-001/pilot.json','originalD46':HF/'native-payload-failure-seals.cjs','submitCaller':ROOT/'submit-colour-before-v1.py','inputCollector':ROOT/'retain-contiguous-inputs003.py'}
 for key in required:
  entry=bindings[key];assert set(entry)=={'path','sha256'} and (WS/entry['path']).resolve()==required_paths[key]
  bound(required_paths[key],entry['sha256'])
 assert (plan_dir/plan['payloadFile']).resolve()==required_paths['payload']
 return required_paths

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for name in ['plan','mirror','bindings','selection','authority','reconciliation','output']:p.add_argument('--'+name,type=Path,required=True)
 for name in ['plan-sha256','bindings-sha256','selection-sha256','authority-sha256','reconciliation-sha256','source-ref']:p.add_argument('--'+name,required=True)
 a=p.parse_args();output=a.output.resolve();assert output.is_relative_to(ROOT) and not output.exists(),'New isolated receipt output only'
 plan=json.loads(bound(a.plan,a.plan_sha256));assert not plan.get('executionHold'),'Not selected'
 url=reference_url(plan)
 selection=json.loads(bound(a.selection,a.selection_sha256));assert selection['action']=='SELECT_ONCE' and selection['attempts']==1
 assert selection['source']==plan['source'] and selection['planSHA256']==a.plan_sha256 and selection['manifestSHA256']==plan['expectedInputsRef']['sha256'] and selection['count']==plan['expectedInputsRef']['count'] and selection['tests']==plan['tests']
 assert selection['owner']==plan['ownerSelection']['owner']
 bindings=json.loads(bound(a.bindings,a.bindings_sha256))
 required_paths=validate_binding_bundle(bindings,plan,a.plan.parent)
 assert bindings['originalPlan']['sha256']==ORIGINAL_PLAN and bindings['originalRequest']['sha256']==ORIGINAL_REQUEST and bindings['profileBasis']['sha256']==PROFILE_BASIS
 assert bindings['originalD46']['sha256']=='d46b3773c4bb3134920efa29074f9f2e6d9cf06e99b27b28cc909a222aa67620'
 original=read(required_paths['originalPlan']);request=read(required_paths['originalRequest'])
 assert request['source']==COLOUR_SOURCE and request['forkRef']==COLOUR_REF
 assert selection['owner']==OWNER
 subject=build_authority_subject(plan,a.plan_sha256,bindings,a.bindings_sha256,a.selection_sha256,sha(Path(__file__).read_bytes()))
 authority=json.loads(bound(a.authority,a.authority_sha256));validate_authority(authority,subject)
 reconciliation=json.loads(bound(a.reconciliation,a.reconciliation_sha256));validate_reconciliation(reconciliation,a.plan_sha256,a.selection_sha256)
 reviews=authority['reviewArtifacts']
 basis=read(required_paths['profileBasis'])
 for key in ['image','flavor','timeout','attempts','expectedCacheFiles']:assert plan[key]==basis[key],key
 assert plan['timeout']==1800 and plan['attempts']==1
 # Resolve remote and mirror before source fetch/guard; failure has no runtime seals.
 mirror=bound(a.mirror,plan['expectedInputsRef']['sha256']);mirrorResolved=resolve_bytes(plan,mirror)
 validate_lineage(plan,mirrorResolved,original,a.source_ref)
 opener=urllib.request.build_opener(NoRedirect())
 with opener.open(url,timeout=60) as response:
  assert response.status==200 and response.geturl()==url
  remote=response.read(plan['expectedInputsRef']['bytes']+1)
 assert remote==mirror,'Downloaded immutable manifest differs from reviewed mirror'
 resolved=resolve_bytes(plan,remote)
 for file in list(HF.glob('*/submission.json'))+list((WS/'knowledge/tsps/hunt-pipeline-20261106').glob('*/*/submission.json')):
  old=read(file).get('plan',{});assert not(old.get('source')==plan['source'] and set(old.get('tests',[]))&set(plan['tests'])),str(file)
 repo=WS/'repos/tsps';fork=f"https://github.com/{plan['repository']}.git"
 subprocess.run(['git','-C',str(repo),'-c','maintenance.auto=false','-c','gc.auto=0','fetch','--refmap=','--no-write-fetch-head','--no-tags',fork,plan['source']],check=True,capture_output=True)
 remote_ref=subprocess.check_output(['git','ls-remote',fork,a.source_ref]).decode().strip();assert remote_ref.split()[0]==plan['source']
 with urllib.request.urlopen(urllib.request.Request(f"https://codeload.github.com/{plan['repository']}/tar.gz/{plan['source']}",method='HEAD'),timeout=40) as response:assert response.status==200
 rows,blobs=verify_git(plan,resolved)
 rendered=json.loads(subprocess.check_output([str(WS/'.tools/hf-overflow/Scripts/python.exe'),str(HF/'pilot.py'),'--plan',str(a.plan)]))
 assert rendered['plan']==plan
 command=rendered['request']['command'];sizes=[len(x.encode())+1 for x in command];assert all(x<131072 for x in sizes)
 output.mkdir();(output/'downloaded-manifest.json').write_bytes(remote)
 (output/'resolved-maps.json').write_text(json.dumps(resolved,indent=2)+'\n')
 (output/'request-preview.json').write_text(json.dumps(rendered,indent=2)+'\n')
 receipt={'stage':'SELECTED_REFERENCE_PRESTART_CHECKED_NO_JOB_API','source':plan['source'],'manifest':resolved['provenance'],'count':len(rows),'freshInputs':rows,'freshGitBlobs':blobs,'bindings':bindings,'reviews':reviews,'selectionSHA256':a.selection_sha256,'selectionPath':str(a.selection.resolve()),'bindingsPath':str(a.bindings.resolve()),'bindingsSHA256':a.bindings_sha256,'planSHA256':a.plan_sha256,'forkReadback':remote_ref,'codeloadHEAD':200,'localDuplicateScan':'CLEAR','normalReconciliationSHA256':a.reconciliation_sha256,'authoritySHA256':a.authority_sha256,'authoritySubject':subject,'normalReconciliationScope':'Retained operator selected-source/name check only, not global provider census','prestartCallerSHA256':sha(Path(__file__).read_bytes()),'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selectedPlanPath':str(a.plan.resolve()),'argumentBytesInclNUL':sizes,'programSHA256':sha(command[-1].encode()),'noJobAPI':True,'sourceRuntimeSeals':'NOT_AVAILABLE: prestart only, no runtime source/install/test occurred'}
 (output/'prestart-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'stage':receipt['stage'],'count':len(rows),'argumentBytesInclNUL':sizes}))
if __name__=='__main__':main()
