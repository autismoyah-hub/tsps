"""Isolated reference-aware prestart candidate. NEVER submits or changes a plan.
Requires already-selected exact reviewed bytes. Every output is a prestart receipt,
not admission authority. Frozen generic caller/pilot/D46 remain unchanged.
"""
from pathlib import Path
import sys
import argparse,base64,hashlib,json,re,subprocess,urllib.request,datetime
ROOT=Path(__file__).resolve().parent
WS=ROOT.parents[3]
HF=ROOT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def bound(path,digest):
 raw=Path(path).read_bytes();assert re.fullmatch('[a-f0-9]{64}',digest) and sha(raw)==digest,str(path)
 return raw

def reference_url(plan):
 spec=plan['expectedInputsRef']
 assert not plan.get('expectedInputs') and not plan.get('sourceBlobs'),'Mixed modes'
 assert set(spec)=={'schema','repository','artifactCommit','path','sha256','bytes','source','count'}
 assert spec['schema']==1 and spec['repository']==plan['repository'] and re.fullmatch('[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+',spec['repository'])
 assert re.fullmatch('[a-f0-9]{40}',spec['artifactCommit']) and len(set(spec['artifactCommit']))>1,'Prospective/placeholder artifact inadmissible'
 assert spec['source']==plan['source'] and re.fullmatch('[a-f0-9]{40}',plan['source'])
 assert re.fullmatch('[a-f0-9]{64}',spec['sha256']) and type(spec['bytes']) is int and 0<spec['bytes']<=2*1024*1024
 assert type(spec['count']) is int and 0<spec['count']<=10000
 assert re.fullmatch('[A-Za-z0-9_./-]+[.]json',spec['path']) and all(x and x not in ('.','..') for x in spec['path'].split('/'))
 return f"https://raw.githubusercontent.com/{spec['repository']}/{spec['artifactCommit']}/{spec['path']}"

class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):raise ValueError('Manifest redirect refused')

def resolve_bytes(plan,raw):
 spec=plan['expectedInputsRef'];assert len(raw)==spec['bytes'] and sha(raw)==spec['sha256'],'Manifest byte identity'
 # Reuse EXACT tested/embedded JS parser/schema, not a second document interpretation.
 code="""const fs=require('node:fs');const {resolveInputManifest}=require(process.argv[1]);
 const x=JSON.parse(fs.readFileSync(0,'utf8'));const raw=Buffer.from(x.base64,'base64');
 resolveInputManifest(x.plan,async url=>({ok:true,url,body:(async function*(){yield raw})()}))
 .then(x=>console.log(JSON.stringify(x))).catch(e=>{console.error(e.message);process.exitCode=70});"""
 r=subprocess.run(['node','-e',code,str(ROOT/'input-manifest-resolver.cjs')],input=json.dumps({'plan':plan,'base64':base64.b64encode(raw).decode()}).encode(),capture_output=True,check=True)
 return json.loads(r.stdout)

def verify_git(plan,resolved):
 repo=Path('/workspace/repo');rows=resolved['expectedInputs'];blobs=resolved['sourceBlobs']
 assert len(rows)==plan['expectedInputsRef']['count'] and set(rows)==set(blobs)
 tree={}
 for row in subprocess.check_output(['git','-C',str(repo),'ls-tree','-r','-z',plan['source']]).split(b'\0'):
  if row:
   meta,file=row.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[file.decode()]=(kind,oid)
 for file in rows:assert tree[file]==('blob',blobs[file]),file
 names=list(rows);data=subprocess.check_output(['git','-C',str(repo),'cat-file','--batch'],input=('\n'.join(blobs[x] for x in names)+'\n').encode());offset=0;actual={}
 for file in names:
  end=data.index(b'\n',offset);oid,kind,size=data[offset:end].decode().split();offset=end+1;raw=data[offset:offset+int(size)];offset+=int(size)+1
  actual[file]=sha(raw);assert actual[file]==rows[file] and oid==blobs[file] and kind=='blob',file
 assert offset==len(data)
 return actual,blobs

COLOUR_SOURCE='2a58cab282b120dca88f8e3eb005df88d8beac6c'
COLOUR_REF='refs/heads/minnow-exchange-capacity-827f21d7'
OWNER='827f21d7-bd7b-4698-9d4d-e4105ca67d27'
REVIEWER='a4d43058-5882-445b-8c6f-398aaa054265'
OPERATOR='827f21d7-bd7b-4698-9d4d-e4105ca67d27'
ORIGINAL_PLAN='8acd058263adcb9bde8767fc6bf142098d560b48308e908ead4a639f22553420'
ORIGINAL_REQUEST='1ea1519cff5757ce661a2fceac48d2a9a74a3ab0c43c7b63844364dd25a2eb86'
PROFILE_BASIS='8eb0af645befdd9c250e8716ab9adabfeeb65fc2044a33852e0d3eaad2aacb06'

def validate_lineage(plan,resolved,original,source_ref):
 assert source_ref==COLOUR_REF and plan['source']==original['source']==COLOUR_SOURCE,'Reviewed source/ref drift'
 assert plan['expectedInputsRef']['count']==4931
 assert resolved['expectedInputs']==original['expectedInputs'] and resolved['sourceBlobs']==original['sourceBlobs'],'Audited original maps differ'
 allowed={'name','payloadFile','executionHold','ownerSelection','sourceReview','expectedInputsRef','expectedInputs','sourceBlobs'}
 assert set(plan)-set(original)<={'expectedInputsRef','ownerSelection'},'Unsupported plan extension'
 assert set(original)-set(plan)=={'expectedInputs','sourceBlobs'},'Unsupported plan removal'
 for key in set(original)-allowed:assert plan[key]==original[key],f'Unapproved plan delta: {key}'
 assert plan['tests']==['fishing.test.cjs', 'minnow-exchange-capacity.test.cjs']
 assert plan['expectedTestCounts']=={'fishing.test.cjs': 12, 'minnow-exchange-capacity.test.cjs': 4}

PYTHON=Path('/usr/bin/python3.12')
SDK=Path('/workspace/tsps-own-827f21d7/hf-sdk/site-packages')
PYTHON_SHA='c2c20b4745d447551221ec3d4e70f92c270c4609fe3df34fc52ea6dd46e92273'
SDK_MAP_SHA='0984d519ae00e72cbc77507c38eeddea49a74851513763fae1f69bb85339bec1'
EXTRA_PINS={
 'review-capture.py':'a01046085d7850a4782da959d0208a2d0e83e923649b9279b731b7b7084e6e3a',
 'acquire-review.py':'0e89624b1cf8dd29c57a0c2f8e56773be2fa46c43d2864c968f77ecc99541b83',
 'hf-project-access-v4.py':'fab4bc92dc8601143ce61e910f8121774c22a0d19be6d2617bba9449f7131326',
 'authenticated-child-snapshot-command.py':'00ff45d75be1eae3bc8f04995cfb8bcbe2bc5adc28c1162b843cfe88c87024f9',
 'bootstrap-sdk-target.py':'c8a07874c46390e2018ae12bf56497039b9795131dc389c41a2c02801d361d36',
 'collect-author-after.py':'de48aed66b6c4a3eb4ee9be516247786c17eb8c04ce83dfd7bf518a47779f971',
 'reconcile-author-after.py':'3b661f44ac4b4c40183ccb278c37c07f36e0398f4794d4731dcd4faaa30c6491',
 'assemble-reconciliation.py':'f9f2c3c11bb038b0b72dfa06885cade99db5446d5ba29cf00605cf4ec1032115',
 '../frame_transport.py':'f53689d4f2389af93ad8f6a43fe0de94caf8dcaabde3eacbd13b1c957b129a76',
 '../retain-job-result.py':'bdcb7f104ebfa8c26d2aa68c1dd31cf7780f12174eb92d3e98ffb928797a9071',
}
def verify_runtime():
 assert sha(PYTHON.resolve().read_bytes())==PYTHON_SHA
 index=json.loads(bound(ROOT/'sdk-map.json',SDK_MAP_SHA))
 files={str(f.relative_to(SDK)):sha(f.read_bytes()) for f in SDK.rglob('*') if f.is_file()}
 assert files==index,'Private SDK bytes differ from reviewed map'
 for name,digest in EXTRA_PINS.items():bound(ROOT/name,digest)

def build_authority_subject(plan,plan_sha,bindings,bindings_sha,selection_sha,caller_sha):
 return {'executor':OPERATOR,'pythonSHA256':PYTHON_SHA,'sdkMapSHA256':SDK_MAP_SHA,'extraPins':EXTRA_PINS,'source':COLOUR_SOURCE,'sourceRef':COLOUR_REF,'originalPlanSHA256':ORIGINAL_PLAN,'originalRequestSHA256':ORIGINAL_REQUEST,'planSHA256':plan_sha,'manifestSHA256':plan['expectedInputsRef']['sha256'],'count':4931,'tests':plan['tests'],'expectedTestCounts':plan['expectedTestCounts'],'callerSHA256':caller_sha,'submitCallerSHA256':bindings['submitCaller']['sha256'],'payloadSHA256':bindings['payload']['sha256'],'bindingsSHA256':bindings_sha,'profileBasisSHA256':PROFILE_BASIS,'selectionSHA256':selection_sha,'causalBeforeReceiptSHA256':BEFORE_RECEIPT_SHA,'causalBeforePacketSHA256':BEFORE_PACKET_SHA,'causalBeforeJob':BEFORE_JOB}

def verify_subject_pair(expected,receipt_subject,authority_subject):
 assert receipt_subject==expected and authority_subject==expected,'Current plan/review subject mismatch'

def validate_authority(record,subject):
 # File bytes alone cannot authenticate a reviewer. This contract must be a
 # genuine operator capture of the named reviewer's direct-session verdict;
 # caller binds its hash and the exact underlying review artifacts. No record
 # is generated here and no arbitrary --review list substitutes for it.
 assert record['type']=='EXECUTOR_CAPTURED_DIRECT_REVIEW_CONTRACT'
 assert record['issuer']==REVIEWER and record['owner']==OWNER and record['operator']==OPERATOR,'Review identity'
 assert record['verdict']=='EXACT_INPUT_PROFILE_GO' and record['subject']==subject,'Review subject/verdict'
 evidence=record['directSessionEvidence'];assert evidence['session']==REVIEWER and evidence['origin']=='EXECUTOR_OBSERVED_DIRECT_SESSION_MESSAGE','Missing actual direct review provenance'
 captured=bound(WS/evidence['capturePath'],evidence['captureSHA256'])
 reviewer_receipt=record['reviewerReceipt'];bound(WS/reviewer_receipt['path'],reviewer_receipt['sha256'])
 import types
 adapter_path=ROOT/'review-capture.py';adapter_raw=bound(adapter_path,EXTRA_PINS['review-capture.py'])
 adapter=types.ModuleType('verified_review_capture');exec(compile(adapter_raw,str(adapter_path),'exec'),adapter.__dict__)
 retained_turn=adapter.select_turn(captured,subject,reviewer_receipt['sha256'])
 live_raw,live_turn=adapter.acquire(subject,reviewer_receipt['sha256'])
 assert retained_turn==live_turn,'Retained verdict is absent from live reviewer transcript'
 assert evidence['command']==list(adapter.COMMAND) and evidence['selectedTurn']==retained_turn and evidence['acquiredUTC'],'Capture metadata mismatch'
 assert record['reviewArtifacts'],'Review artifacts missing'
 for row in record['reviewArtifacts']:
  assert row['reviewer']==REVIEWER and row['stage'] in ['SOURCE_GO','EXACT_INPUT_PROFILE_GO']
  bound(WS/row['path'],row['sha256'])

def validate_reconciliation(record,plan_sha,selection_sha,plan_name):
 assert record['operator']==OPERATOR and record['source']==COLOUR_SOURCE
 assert record['planSHA256']==plan_sha and record['selectionSHA256']==selection_sha
 age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(record['checkedUTC'])).total_seconds()
 assert 0<=age<=300,'Stale normal reconciliation'
 assert record['ownedMatchingToolCells']==[] and record['pendingOrAmbiguousMatchingIntents']==[] and record['submittedMatchingJobs']==[]
 owned_ref=record['ownedToolEvidence'];owned=json.loads(bound(WS/owned_ref['path'],owned_ref['sha256']))
 assert owned['source']==COLOUR_SOURCE and owned['owner']==OWNER and owned['planSHA256']==plan_sha and owned['selectionSHA256']==selection_sha
 assert owned['scope']=='owner session and workspace only' and owned['ownedMatchingToolCells']==[] and owned['pendingOrAmbiguousMatchingIntents']==[] and owned['submittedMatchingJobs']==[]
 owned_age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(owned['checkedUTC'])).total_seconds();assert 0<=owned_age<=300,'Stale owner evidence'

 assert record['providerReconciliation']['status']=='CLEAR' and record['providerReconciliation']['scope']=='same selected source/name; executor reconciliation, not global census'
 assert record['providerReconciliation']['evidence'],'Retained reconciliation evidence required'
 evidence=record['providerReconciliation']['evidence']
 assert len(evidence)==1,'One actual provider reconciliation receipt required'
 proof=json.loads(bound(WS/evidence[0]['path'],evidence[0]['sha256']))
 assert proof['source']==COLOUR_SOURCE and proof['owner']==OWNER and proof['namespace']=='Autismo-Yah'
 assert proof['planSHA256']==plan_sha and proof['selectionSHA256']==selection_sha
 assert proof['status']=='CLEAR' and proof['sourceJobs']==[] and proof['nameJobs']==[] and proof['noProviderWrite'] is True
 assert proof['sourceQuery']=={'project':'tsps','source':COLOUR_SOURCE} and proof['nameQuery']=={'project':'tsps','name':plan_name}
 assert proof['projectQuery']=={'project':'tsps'} and isinstance(proof['projectJobs'],list)
 for row in proof['projectJobs']:
  assert isinstance(row,dict) and row.get('jobId') and row.get('stage') and isinstance(row.get('labels'),dict)
  assert row['labels'].get('project')=='tsps' and set(row['labels'])<={'project','source','name'}
 legacy=[row for row in proof['projectJobs'] if not row['labels'].get('source')]
 assert proof['legacyUnresolved']==legacy and legacy==[],'Legacy source unknown; hold'
 validate_causal_before()
 assert not [row for row in proof['projectJobs'] if (row['labels'].get('source') in {COLOUR_SOURCE, BEFORE_SOURCE} or row['labels'].get('name') in {plan_name, BEFORE_NAME}) and not accepted_before_project(row)],'Project list contains unmatched paired job'
 proof_age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(proof['checkedUTC'])).total_seconds()
 assert 0<=proof_age<=300,'Stale provider evidence'

BEFORE_SOURCE='85f2568b5dba4e2e7968adb099b0bf8e66e1aae7'
BEFORE_NAME='minnow-capacity-before-held'
BEFORE_JOB='6af087eb0e0338d1bb84bace'
BEFORE_RECEIPT_SHA='37253c747456868172ad0cdca31970aff849370475fc338a5301440e29701b33'
BEFORE_PACKET_SHA='aed6fc1ca70df14bd544599432cd5a99c06b6160bea6353bd0757dc5f9f394ef'
BEFORE_PLAN_SHA='77b46b6e526ffede8356f35ab16469059c4bbc6b15e2b7113aaacb34c70b9b3a'
BEFORE_SELECTION_SHA='d8bec00f935e008e94e6aa4a08cd6eb822849cc5069d477e527a6d1d4fc5c311'
BEFORE_PROGRAM_SHA='2df800532cfb69f31d5d6e057153d7206f52008f29f18ebddff294bb2318db3d'

def validate_causal_before():
 import zipfile,io
 before=HF/'minnow-before'/'selected-before-once'
 receipt=json.loads(bound(before/'causal-before-review.json',BEFORE_RECEIPT_SHA))
 assert receipt['verdict']=='CAUSAL_BEFORE_CONSERVATION_FAILURE_ACCEPTED' and receipt['reviewer']==REVIEWER
 assert receipt['ownerExecutorCollector']==OWNER and receipt['jobId']==BEFORE_JOB
 identity=receipt['identity'];assert identity['source']==BEFORE_SOURCE and identity['planSHA256']==BEFORE_PLAN_SHA
 assert identity['selectionSHA256']==BEFORE_SELECTION_SHA and identity['programSHA256']==BEFORE_PROGRAM_SHA
 assert receipt['packet']['sha256']==BEFORE_PACKET_SHA and receipt['packet']['indexPinsVerified']==12
 packet=bound(before/'terminal-packet.zip',BEFORE_PACKET_SHA)
 with zipfile.ZipFile(io.BytesIO(packet)) as z:
  idx=json.loads(z.read('INDEX.json'));assert len(idx)==12
  for item in idx:
   name=item['path'];raw=z.read(name);assert len(raw)==item['bytes'] and sha(raw)==item['sha256']
   assert (before/name).read_bytes()==raw,'BEFORE retained file differs from independently reviewed packet'
  plan=json.loads(z.read('pilot.json'));selection=json.loads(z.read('selection.json'));submission=json.loads(z.read('submission.json'))
  status=json.loads(z.read('status-20261108T143556Z.json'));result=json.loads(z.read('result.json'))
  assert sha(z.read('pilot.json'))==BEFORE_PLAN_SHA and sha(z.read('selection.json'))==BEFORE_SELECTION_SHA
  assert plan['source']==BEFORE_SOURCE and plan['name']==BEFORE_NAME and selection['owner']==OWNER
  assert submission['job']['id']==status['id']==result['jobId']==BEFORE_JOB and status['status']['stage']=='ERROR'
  command=submission['request']['command'];assert command==submission['job']['command']==status['command']
  assert sha(command[-1].encode())==BEFORE_PROGRAM_SHA and result['platformStatus']['stage']=='ERROR'
 custody=read(before/'mapref-runtime-custody.json')
 assert custody['owner']==OWNER and custody['jobId']==BEFORE_JOB and custody['planSHA256']==BEFORE_PLAN_SHA
 assert custody['stage']=='ADMITTED_AWAITING_MANUAL_SAMEJOB_COLLECTION_OWNED' and custody['noAutomaticRetry'] is True
 assert not (before/'author-collector-active.lock').exists(),'BEFORE collection still active'
 return before.resolve()

def accepted_before_project(row):
 labels=row.get('labels',{})
 return (row.get('jobId')==BEFORE_JOB and row.get('stage')=='ERROR' and labels.get('project')=='tsps'
         and labels.get('source')==BEFORE_SOURCE and labels.get('name') in (None, BEFORE_NAME))

def scan_owned_intents(plan,plan_path):
 # This is only the named executor workspace, not a provider-wide lease.
 selected=Path(plan_path).resolve()
 before=validate_causal_before()
 for file in WS.rglob('pilot.json'):
  if not any(part.startswith('selected') for part in file.relative_to(WS).parts):continue
  if file.resolve()==selected:continue
  if file.resolve()==before/'pilot.json':continue
  try: other=read(file)
  except Exception as exc: raise RuntimeError('Malformed owned selected intent: '+str(file)) from exc
  if not other.get('executionHold') and other.get('ownerSelection') and (other.get('source') in {'85f2568b5dba4e2e7968adb099b0bf8e66e1aae7','2a58cab282b120dca88f8e3eb005df88d8beac6c'} or other.get('name') in {'minnow-capacity-before-held','minnow-capacity-after-held'}):
   raise RuntimeError('Conflicting selected intent: '+str(file))
 for file in WS.rglob('mapref-runtime-custody.json'):
  if file.resolve()==before/'mapref-runtime-custody.json':continue
  try:
   custody=read(file); other=read(file.parent/'pilot.json')
   if not custody.get('stage') or not custody.get('planSHA256'):raise ValueError('Incomplete custody')
  except Exception as exc: raise RuntimeError('Malformed owned custody: '+str(file)) from exc
  if other.get('source') in {'85f2568b5dba4e2e7968adb099b0bf8e66e1aae7','2a58cab282b120dca88f8e3eb005df88d8beac6c'} or other.get('name') in {'minnow-capacity-before-held','minnow-capacity-after-held'}:
   raise RuntimeError('Owned custody requires reconciliation: '+str(file))
 for file in WS.rglob('submission.json'):
  if file.resolve()==before/'submission.json':continue
  try: other=read(file)['plan']
  except Exception as exc: raise RuntimeError('Malformed owned submission: '+str(file)) from exc
  if other.get('source') in {'85f2568b5dba4e2e7968adb099b0bf8e66e1aae7','2a58cab282b120dca88f8e3eb005df88d8beac6c'} or other.get('name') in {'minnow-capacity-before-held','minnow-capacity-after-held'}:
   raise RuntimeError('Owned submission requires reconciliation: '+str(file))

def validate_binding_bundle(bindings,plan,plan_dir):
 required={'payload','resolver','pilot','package','caller','originalPlan','originalRequest','profileBasis','originalD46','submitCaller','inputCollector'};assert set(bindings)==required
 required_paths={'payload':ROOT/'native-payload-602.cjs','resolver':ROOT/'input-manifest-resolver.cjs','pilot':HF/'pilot.py','package':HF/'package.json','caller':Path(__file__).resolve(),'originalPlan':ROOT/'original-case-full-plan.json','originalRequest':ROOT/'original-case-request.json','profileBasis':HF/'native-smithing-95e-after-001/pilot.json','originalD46':HF/'native-payload-failure-seals.cjs','submitCaller':ROOT/'submit-colour-before-v1.py','inputCollector':ROOT/'retain-contiguous-inputs003.py'}
 for key in required:
  entry=bindings[key];assert set(entry)=={'path','sha256'} and (WS/entry['path']).resolve()==required_paths[key]
  bound(required_paths[key],entry['sha256'])
 assert (plan_dir/plan['payloadFile']).resolve()==required_paths['payload']
 return required_paths

def main():
 if not sys.dont_write_bytecode: raise RuntimeError('Invoke Python with -B')
 p=argparse.ArgumentParser(description=__doc__)
 for name in ['plan','mirror','bindings','selection','authority','reconciliation','output']:p.add_argument('--'+name,type=Path,required=True)
 for name in ['plan-sha256','bindings-sha256','selection-sha256','authority-sha256','reconciliation-sha256','source-ref']:p.add_argument('--'+name,required=True)
 a=p.parse_args();output=a.output.resolve();assert output.is_relative_to(ROOT) and not output.exists(),'New isolated receipt output only'
 verify_runtime()
 plan=json.loads(bound(a.plan,a.plan_sha256));assert not plan.get('executionHold'),'Not selected'
 url=reference_url(plan)
 selection=json.loads(bound(a.selection,a.selection_sha256));assert selection['action']=='SELECT_ONCE' and selection['attempts']==1
 assert selection['source']==plan['source'] and selection['planSHA256']==a.plan_sha256 and selection['manifestSHA256']==plan['expectedInputsRef']['sha256'] and selection['count']==plan['expectedInputsRef']['count'] and selection['tests']==plan['tests']
 assert selection['owner']==plan['ownerSelection']['owner']
 bindings=json.loads(bound(a.bindings,a.bindings_sha256))
 required_paths=validate_binding_bundle(bindings,plan,a.plan.parent)
 assert bindings['originalPlan']['sha256']==ORIGINAL_PLAN and bindings['originalRequest']['sha256']==ORIGINAL_REQUEST and bindings['profileBasis']['sha256']==PROFILE_BASIS
 assert bindings['originalD46']['sha256']=='d46b3773c4bb3134920efa29074f9f2e6d9cf06e99b27b28cc909a222aa67620'
 original=read(required_paths['originalPlan']);request=read(required_paths['originalRequest'])
 assert request['source']==COLOUR_SOURCE and request['forkRef']==COLOUR_REF
 assert selection['owner']==OWNER
 subject=build_authority_subject(plan,a.plan_sha256,bindings,a.bindings_sha256,a.selection_sha256,sha(Path(__file__).read_bytes()))
 authority=json.loads(bound(a.authority,a.authority_sha256));validate_authority(authority,subject)
 reconciliation=json.loads(bound(a.reconciliation,a.reconciliation_sha256));validate_reconciliation(reconciliation,a.plan_sha256,a.selection_sha256,plan['name'])
 reviews=authority['reviewArtifacts']
 basis=read(required_paths['profileBasis'])
 for key in ['image','flavor','timeout','attempts','expectedCacheFiles']:assert plan[key]==basis[key],key
 assert plan['timeout']==1800 and plan['attempts']==1
 # Resolve remote and mirror before source fetch/guard; failure has no runtime seals.
 mirror=bound(a.mirror,plan['expectedInputsRef']['sha256']);mirrorResolved=resolve_bytes(plan,mirror)
 validate_lineage(plan,mirrorResolved,original,a.source_ref)
 opener=urllib.request.build_opener(NoRedirect())
 with opener.open(url,timeout=60) as response:
  assert response.status==200 and response.geturl()==url
  remote=response.read(plan['expectedInputsRef']['bytes']+1)
 assert remote==mirror,'Downloaded immutable manifest differs from reviewed mirror'
 resolved=resolve_bytes(plan,remote)
 scan_owned_intents(plan,a.plan)
 repo=Path('/workspace/repo');fork=f"https://github.com/{plan['repository']}.git"
 subprocess.run(['git','-C',str(repo),'-c','maintenance.auto=false','-c','gc.auto=0','fetch','--refmap=','--no-write-fetch-head','--no-tags',fork,plan['source']],check=True,capture_output=True)
 remote_ref=subprocess.check_output(['git','ls-remote',fork,a.source_ref]).decode().strip();assert remote_ref.split()[0]==plan['source']
 with urllib.request.urlopen(urllib.request.Request(f"https://codeload.github.com/{plan['repository']}/tar.gz/{plan['source']}",method='HEAD'),timeout=40) as response:assert response.status==200
 rows,blobs=verify_git(plan,resolved)
 rendered=json.loads(subprocess.check_output(['/usr/bin/python3.12','-B',str(HF/'pilot.py'),'--plan',str(a.plan)]))
 assert rendered['plan']==plan
 command=rendered['request']['command'];sizes=[len(x.encode())+1 for x in command];assert all(x<131072 for x in sizes)
 output.mkdir();(output/'downloaded-manifest.json').write_bytes(remote)
 (output/'resolved-maps.json').write_text(json.dumps(resolved,indent=2)+'\n')
 (output/'request-preview.json').write_text(json.dumps(rendered,indent=2)+'\n')
 receipt={'stage':'SELECTED_REFERENCE_PRESTART_CHECKED_NO_JOB_API','source':plan['source'],'manifest':resolved['provenance'],'count':len(rows),'freshInputs':rows,'freshGitBlobs':blobs,'bindings':bindings,'reviews':reviews,'selectionSHA256':a.selection_sha256,'selectionPath':str(a.selection.resolve()),'bindingsPath':str(a.bindings.resolve()),'bindingsSHA256':a.bindings_sha256,'planSHA256':a.plan_sha256,'forkReadback':remote_ref,'codeloadHEAD':200,'localDuplicateScan':'CLEAR','normalReconciliationSHA256':a.reconciliation_sha256,'authoritySHA256':a.authority_sha256,'authoritySubject':subject,'normalReconciliationScope':'Retained executor selected-source/name check only, not global provider census','prestartCallerSHA256':sha(Path(__file__).read_bytes()),'createdUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selectedPlanPath':str(a.plan.resolve()),'argumentBytesInclNUL':sizes,'programSHA256':sha(command[-1].encode()),'noJobAPI':True,'sourceRuntimeSeals':'NOT_AVAILABLE: prestart only, no runtime source/install/test occurred'}
 (output/'prestart-readback.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'stage':receipt['stage'],'count':len(rows),'argumentBytesInclNUL':sizes}))
if __name__=='__main__':main()
