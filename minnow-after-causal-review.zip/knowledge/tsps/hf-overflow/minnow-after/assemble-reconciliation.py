"""DRAFT: bind actual provider and owner-captured tool-cell evidence, never fabricate CLEAR."""
from pathlib import Path
import argparse, datetime, hashlib, json, sys, types
ROOT=Path(__file__).resolve().parent
WS=ROOT.parents[3]
OWNER='827f21d7-bd7b-4698-9d4d-e4105ca67d27'
SOURCE='2a58cab282b120dca88f8e3eb005df88d8beac6c'

def sha(raw): return hashlib.sha256(raw).hexdigest()
def fresh(value):
    age=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(value)).total_seconds()
    if not 0<=age<=300: raise RuntimeError('Evidence is stale')
def main():
    if not sys.dont_write_bytecode: raise RuntimeError('Invoke Python with -B')
    p=argparse.ArgumentParser()
    for name in ('plan','selection','provider','owned-tool-evidence','output'):p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();plan_raw=a.plan.read_bytes();selection_raw=a.selection.read_bytes();plan=json.loads(plan_raw);selection=json.loads(selection_raw)
    ps=sha(plan_raw);ss=sha(selection_raw)
    if plan['source']!=SOURCE or selection['source']!=SOURCE or selection['owner']!=OWNER or selection['planSHA256']!=ps or selection['action']!='SELECT_ONCE' or selection['attempts']!=1:raise RuntimeError('Selection mismatch')
    if plan.get('executionHold') is not False or (plan.get('ownerSelection') or {}).get('owner')!=OWNER:raise RuntimeError('Plan is not owner-selected')
    if selection.get('manifestSHA256')!=plan['expectedInputsRef']['sha256'] or selection.get('count')!=plan['expectedInputsRef']['count'] or selection.get('tests')!=plan['tests']:raise RuntimeError('Selection inputs mismatch')
    provider_raw=a.provider.read_bytes();provider=json.loads(provider_raw);owned_raw=a.owned_tool_evidence.read_bytes();owned=json.loads(owned_raw)
    for row in (provider,owned):
        if row['source']!=SOURCE or row['owner']!=OWNER or row['planSHA256']!=ps or row['selectionSHA256']!=ss:raise RuntimeError('Evidence binding mismatch')
        fresh(row['checkedUTC'])
    if provider['namespace']!='Autismo-Yah' or provider['status']!='CLEAR' or provider['sourceJobs'] or provider['nameJobs'] or provider['legacyUnresolved'] or provider['noProviderWrite'] is not True:raise RuntimeError('Provider match or invalid evidence')
    if provider['sourceQuery']!={'project':'tsps','source':SOURCE} or provider['nameQuery']!={'project':'tsps','name':plan['name']} or provider['projectQuery']!={'project':'tsps'}:raise RuntimeError('Provider query mismatch')
    bindings=json.loads((ROOT/'bindings.json').read_bytes());caller_path=ROOT/'prestart-colour-before-v1.py'
    caller_raw=caller_path.read_bytes()
    if sha(caller_raw)!=bindings['caller']['sha256']:raise RuntimeError('Prestart caller binding mismatch')
    caller=types.ModuleType('verified_owner_scanner');caller.__file__=str(caller_path)
    exec(compile(caller_raw,str(caller_path),'exec'),caller.__dict__);caller.WS=WS
    caller.validate_causal_before()
    for row in provider['projectJobs']:
        labels=row['labels']
        if not row.get('jobId') or not row.get('stage') or labels.get('project')!='tsps' or not labels.get('source') or ((labels.get('source') in {SOURCE,caller.BEFORE_SOURCE} or labels.get('name') in {plan['name'],caller.BEFORE_NAME}) and not caller.accepted_before_project(row)):raise RuntimeError('Ambiguous project job')
    if owned['scope']!='owner session and workspace only' or owned['ownedMatchingToolCells'] or owned['pendingOrAmbiguousMatchingIntents'] or owned['submittedMatchingJobs']:raise RuntimeError('Owner work or intent not clear')
    # Reuse the exact bound prestart scanner for sibling selection/custody/submission.
    bindings=json.loads((ROOT/'bindings.json').read_bytes());caller_path=ROOT/'prestart-colour-before-v1.py'
    caller_raw=caller_path.read_bytes()
    if sha(caller_raw)!=bindings['caller']['sha256']:raise RuntimeError('Prestart caller binding mismatch')
    caller=types.ModuleType('verified_owner_scanner');caller.__file__=str(caller_path)
    exec(compile(caller_raw,str(caller_path),'exec'),caller.__dict__)
    caller.WS=WS
    caller.scan_owned_intents(plan,a.plan)
    def ref(path,raw): return {'path':str(path.resolve().relative_to(WS)), 'sha256':sha(raw)}
    record={'operator':OWNER,'source':SOURCE,'planSHA256':ps,'selectionSHA256':ss,
            'checkedUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'ownedMatchingToolCells':[],'pendingOrAmbiguousMatchingIntents':[],'submittedMatchingJobs':[],
            'ownedToolEvidence':ref(a.owned_tool_evidence,owned_raw),
            'providerReconciliation':{'status':'CLEAR','scope':'same selected source/name; executor reconciliation, not global census','evidence':[ref(a.provider,provider_raw)]}}
    with a.output.open('x',encoding='utf-8') as out: json.dump(record,out,indent=2)
    print(json.dumps({'stage':'OWNED_RECONCILIATION_ASSEMBLED','scope':'owner workspace and exact provider source/name; not atomic global lease'}))
if __name__=='__main__':main()
