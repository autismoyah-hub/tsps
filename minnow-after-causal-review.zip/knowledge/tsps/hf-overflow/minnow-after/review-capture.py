"""Acquire a reviewer-session verdict through the supported Cuttle CLI.

The Cuttle connection is the trust boundary, not a portable signature. Retained
JSON is evidence only when its matching turn is also found in a live acquisition.
"""
import json, subprocess
REVIEWER='a4d43058-5882-445b-8c6f-398aaa054265'
EXECUTOR='827f21d7-bd7b-4698-9d4d-e4105ca67d27'
COMMAND=('cuttle','--json','sessions','read',REVIEWER,'--turns','1000')

def select_turn(raw, subject, receipt_sha):
    obj=json.loads(raw)
    if not isinstance(obj,dict) or not isinstance(obj.get('turns'),list): raise ValueError('invalid transcript')
    expected={'type':'TSPS_DIRECT_REVIEW','verdict':'EXACT_INPUT_PROFILE_GO',
              'reviewer':REVIEWER,'executor':EXECUTOR,'subject':subject,'receiptSHA256':receipt_sha}
    matches=[]
    for turn in obj['turns']:
        if not isinstance(turn,dict) or turn.get('role')!='assistant' or turn.get('kind')!='text': continue
        try: content=json.loads(turn.get('text',''))
        except (TypeError,ValueError): continue
        if content==expected and isinstance(turn.get('ts'),str) and turn['ts']: matches.append(turn)
    if len(matches)!=1: raise ValueError('exact reviewer verdict absent or ambiguous')
    return matches[0]

def acquire(subject, receipt_sha, run=subprocess.run):
    result=run(list(COMMAND),capture_output=True,check=True,timeout=60)
    raw=result.stdout
    return raw,select_turn(raw,subject,receipt_sha)
