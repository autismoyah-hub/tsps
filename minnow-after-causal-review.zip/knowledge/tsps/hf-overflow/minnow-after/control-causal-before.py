"""Offline actual evidence-loader/scanner controls, no provider or game."""
import pathlib,json,importlib.util,tempfile,shutil,zipfile
c=pathlib.Path(__file__).resolve().parent;sp=importlib.util.spec_from_file_location('case',c/'prestart-colour-before-v1.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
actual=c.parent/'minnow-before'/'selected-before-once';plan=json.loads((c/'held-001/pilot.json').read_text())
with tempfile.TemporaryDirectory() as t:
 ws=pathlib.Path(t);hf=ws/'knowledge/tsps/hf-overflow';before=hf/'minnow-before/selected-before-once';before.mkdir(parents=True);m.WS=ws;m.HF=hf
 for name in ('terminal-packet.zip','causal-before-review.json','mapref-runtime-custody.json'):shutil.copyfile(actual/name,before/name)
 with zipfile.ZipFile(before/'terminal-packet.zip') as z:
  for name in z.namelist():
   if name=='INDEX.json':continue
   out=before/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(z.read(name))
 current=hf/'minnow-after/selected-after-once/pilot.json';current.parent.mkdir(parents=True);current.write_text(json.dumps(plan));m.scan_owned_intents(plan,current)
 def denied():
  try:m.scan_owned_intents(plan,current)
  except (AssertionError,ValueError,RuntimeError,KeyError,FileNotFoundError):return
  raise AssertionError('unsafe evidence admitted')
 # A self-consistent fabricated receipt remains untrusted because independent receipt bytes are pinned.
 receipt=before/'causal-before-review.json';real=receipt.read_bytes();fake=json.loads(real);fake['jobId']='fabricated';receipt.write_text(json.dumps(fake));denied();receipt.write_bytes(real)
 # Even with recognized BEFORE, an unrelated ambiguous sibling cannot be ignored.
 other=hf/'other/selected-ambiguous/pilot.json';other.parent.mkdir(parents=True);other.write_text(json.dumps({'source':m.BEFORE_SOURCE,'name':'another','ownerSelection':{'owner':'someone'},'executionHold':False}));denied();other.unlink()
 status=before/'status-20261108T143556Z.json';real=status.read_bytes();bad=json.loads(real);bad['id']='different';status.write_text(json.dumps(bad));denied();status.write_bytes(real)
 lock=before/'author-collector-active.lock';lock.write_text('{}');denied();lock.unlink()
 custody=before/'mapref-runtime-custody.json';real=custody.read_bytes();bad=json.loads(real);bad['stage']='AMBIGUOUS_INTENT_OWNED_RECONCILIATION_REQUIRED';custody.write_text(json.dumps(bad));denied();custody.write_bytes(real)
 assert m.accepted_before_project({'jobId':m.BEFORE_JOB,'stage':'ERROR','labels':{'project':'tsps','source':m.BEFORE_SOURCE}})
 for row in [{'jobId':'other','stage':'ERROR','labels':{'project':'tsps','source':m.BEFORE_SOURCE}},{'jobId':m.BEFORE_JOB,'stage':'RUNNING','labels':{'project':'tsps','source':m.BEFORE_SOURCE}},{'jobId':m.BEFORE_JOB,'stage':'ERROR','labels':{'project':'tsps','source':m.BEFORE_SOURCE,'name':'minnow-capacity-after-held'}}]:assert not m.accepted_before_project(row)
print('CAUSAL_BEFORE_CONTROLS_PASS exact predecessor accepted; fabricated receipt, other sibling, wrong terminal, active lock, ambiguous custody and 3 provider mismatches refused; synthetic workspace/no provider')
