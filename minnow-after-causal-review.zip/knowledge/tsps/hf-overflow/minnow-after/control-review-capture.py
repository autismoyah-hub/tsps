"""Synthetic review parser boundary controls; no Cuttle/provider access."""
import importlib.util,json,pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('capture',root/'review-capture.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
subject={'case':'synthetic','source':'abc'};receipt='a'*64
verdict={'type':'TSPS_DIRECT_REVIEW','verdict':'EXACT_INPUT_PROFILE_GO','reviewer':m.REVIEWER,'executor':m.EXECUTOR,'subject':subject,'receiptSHA256':receipt}
def doc(turn):return json.dumps({'turns':[turn]}).encode()
def turn(v=verdict,**kw):return {'role':'assistant','kind':'text','ts':'2026-01-01T00:00:00Z','text':json.dumps(v),**kw}
def fake(raw):
 def run(cmd,**kw):
  assert cmd==list(m.COMMAND) and m.REVIEWER in cmd and kw['check'] and kw['timeout']==60
  return subprocess.CompletedProcess(cmd,0,stdout=raw,stderr=b'')
 return run
raw=doc(turn());_,selected=m.acquire(subject,receipt,run=fake(raw));assert selected==turn()
cases=[doc(turn(role='user')),doc(turn(kind='tool')),doc(turn(kind='thinking')),doc(turn(text='quoted '+json.dumps(verdict))),doc(turn({**verdict,'reviewer':'wrong'})),doc(turn({**verdict,'executor':'wrong'})),doc(turn({**verdict,'subject':{'case':'other'}})),doc(turn({**verdict,'receiptSHA256':'b'*64})),json.dumps({'turns':[turn(),turn()]}).encode(),b'{}']
for raw in cases:
 try:m.acquire(subject,receipt,run=fake(raw))
 except (ValueError,KeyError,TypeError):pass
 else:raise AssertionError('invalid capture accepted')
def denial(cmd,**kw):raise subprocess.CalledProcessError(403,cmd)
try:m.acquire(subject,receipt,run=denial)
except subprocess.CalledProcessError:pass
else:raise AssertionError('denial accepted')
print('REVIEW_CAPTURE_CONTROLS_PASS 1 accepted and 11 rejected; synthetic subprocess only')
