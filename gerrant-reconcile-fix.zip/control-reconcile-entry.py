"""Execute the reconciliation entrypoint with a synthetic read-only provider."""
import importlib.util, pathlib, tempfile, sys, types, json
root=pathlib.Path(__file__).resolve().parent
path=root/'reconcile-author-after.py';spec=importlib.util.spec_from_file_location('reconcile',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class API:
 def whoami(self): return {'name':'Autismo-Yah'}
 def list_jobs(self,**kwargs): return []
sys.modules['huggingface_hub']=types.SimpleNamespace(HfApi=API)
with tempfile.TemporaryDirectory() as d:
 out=pathlib.Path(d)/'result.json'; plan=root/'selected-001/pilot.json';selection=root/'selected-001/selection.json'
 sys.argv=[str(path),'--plan',str(plan),'--selection',str(selection),'--output',str(out)]
 m.main(); result=json.loads(out.read_bytes());assert result['status']=='CLEAR' and result['noProviderWrite'] is True
print('SYNTHETIC_RECONCILE_ENTRY_PASS actual main, actual baseline validation, fake read-only provider; no real provider')
